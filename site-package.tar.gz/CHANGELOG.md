
## Karten-Reparatur

- fehleranfällige Karten-URL durch exakte Koordinaten und eine kompatible Google-Maps-Einbettung ersetzt
- Satelliten- und Straßenansicht umschaltbar
- Lade-, Fehler-, Wiederholen- und Ausblenden-Zustände ergänzt
- mobile Kartenbedienung und Toolbar vollständig neu aufgebaut
- Route verwendet nun die exakten Standortkoordinaten
- Service-Worker-Cache aktualisiert
# Änderungsprotokoll

## Interaktive Produktionsversion

- Live Öffnungsstatus in der Navigation und auf der Startseite
- Scrollfortschritt ohne störende Animationen
- Besuchsplaner mit dynamischem Sonntagstermin und ICS Export
- Speisekartenfilter nach Kategorien
- unverbindlicher Preisrechner mit lokaler Speicherung, Kopieren und Teilen
- Web Share API mit sauberem Zwischenablage Fallback
- optionale PWA Installation bei unterstützten Browsern
- Online und Offline Rückmeldung
- FAQ Bereiche schließen andere Antworten automatisch
- bestehende Karte, Galerie, Sprachwahl und mobile Navigation integriert

# Änderungsprotokoll

## Speisekarte und Standort aktualisiert · 17. Juli 2026

- aktuelle Öffnungszeit auf Sonntag 10:00 bis 20:00 Uhr geändert
- Goldschmitt Techmobil als Standortbezeichnung ergänzt
- bestätigte Preise für 5, 7 und 10 Cevapcici eingetragen
- Hamburger, Salat, Pommes und Hamburger-Menü mit Preisen ergänzt
- Salatzutaten aus der vorliegenden Speisekarte übernommen
- Pljeskavica-Bezeichnung entfernt und durch die bestätigte Bezeichnung Hamburger ersetzt
- Startseiten-Karussell auf drei ruhige Bilder ohne Video und ohne Play-/Pause-Logik umgestellt
- echtes Foodtruck-Foto sowie neue Cevapcici- und Hamburger-Motive integriert
- deutsche, englische und albanische Texte aktualisiert
- HTML, CSS und JavaScript erneut vollständig auditiert

## First-Class Produktionsbasis · 16. Juli 2026

- öffentliche Hauptseiten redaktionell und ohne Textüberlagerungen auf großen Bildern neu aufgebaut
- Karussell ausschließlich auf der Startseite belassen
- automatischen Bildwechsel sowie sichtbare Play-/Pause-Steuerung entfernt
- kurzer, stummer Markenfilm ohne Personenmotive eingebunden
- wechselnde oder widersprüchliche Personendarstellungen entfernt
- öffentliche Texte auf überprüfbare Aussagen reduziert
- seitenübergreifend eigenständige Bildausschnitte erstellt
- externe Designbibliotheken und dekorative Vorlageneffekte entfernt
- Kontraste, Touch-Ziele, Tastatursteuerung und reduzierte Bewegung optimiert
- mobile Schnellaktionen erst nach dem Scrollen eingeblendet
- Geschäftsdaten zentral in `assets/data/business.json` gebündelt
- statische Synchronisierung bestätigter Preise, Kontakte und JSON-LD ergänzt
- Domain-Konfiguration automatisiert
- Service Worker auf Netzwerkpriorität für veränderliche Geschäftsdaten umgestellt
- Qualitätsaudit um Karussellregeln, Bildwiederholungen und Dateiprüfungen erweitert
- Release-Sperre für fehlende Preise, Bildrechte, Rechtsangaben und Produktionsdomain ergänzt
- veraltete Projekt- und Karusselldokumentation entfernt

## HTML/CSS/JavaScript-Abstimmung

- Öffnungszeiten und Adresse werden im JavaScript jetzt direkt aus `assets/data/business.json` gelesen.
- Der Kopierbutton verwendet dieselbe zentrale Adresse wie die übrige Website.
- Nicht aktive Karussellinhalte werden mit `inert` aus der Tastaturreihenfolge entfernt.
- Inline-Styling der 404-Seite wurde in das zentrale Stylesheet verschoben.
- Neue automatische Harmonieprüfung für Script-Reihenfolge, CSS-Verträge, JavaScript-Hooks und vollständige Übersetzungen.
- `npm run audit` prüft jetzt sowohl Struktur als auch das Zusammenspiel von HTML, CSS und JavaScript.

## 2026-07-25 – Zeitlich begrenzte Sonntagsaktion

- Instagram-Ankündigung für Sonntag, 26.07.2026, als professionellen Aktionsbereich ergänzt.
- Aktionspreise: 5 Cevapcici 5,00 €, 7 Cevapcici 7,00 €, 10 Cevapcici 10,00 €, Hamburger 5,00 €.
- Reguläre Speisekartenpreise bleiben unverändert und werden nach Ablauf wieder allein angezeigt.
- Aktionsbereich wird nach dem 26.07.2026 um 20:00 Uhr automatisch ausgeblendet.
- Deutsch, Englisch und Albanisch vollständig ergänzt.
## 2026-07-25 – Interaktive Satellitenkarte

- Satellitenkarte auf Startseite und Standortseite direkt bei den Öffnungszeiten ergänzt.
- Datenschutzfreundliche Zwei-Klick-Lösung: Google Maps wird erst nach aktiver Auswahl geladen.
- Karte ist verschiebbar, zoombar und in großer Ansicht öffnbar.
- Einwilligung gilt nur für die aktuelle Browser-Sitzung und kann mit „Karte ausblenden“ widerrufen werden.
- Deutsche, englische und albanische Beschriftungen ergänzt.
- Datenschutztext, zentrale Geschäftsdaten und Service-Worker-Cache aktualisiert.


## Satellitenkarte ohne Textüberlagerung
- Alle sichtbaren Titel, Beschreibungen, Adressen und Fehlermeldungen aus der Kartenfläche entfernt.
- Einwilligung und Bedienung in eine getrennte Leiste unterhalb der Karte verschoben.
- Ebenenwahl und Quellenhinweise ebenfalls außerhalb der Kartenfläche platziert.
- Kartenfläche enthält nur Kartenkacheln, Standortmarker und symbolische Zoomsteuerung.
- Cache-Version auf native-map-v12 aktualisiert.

## 26.07.2026 – Satellitenkarte sofort geladen

- bisherige individuelle Kartenlogik vollständig durch Leaflet ersetzt
- Satellitenansicht wird sofort beim Seitenaufruf initialisiert
- direkter Wechsel zwischen Satellit und Straße
- keine Titel- oder Textüberlagerung auf der Kartenfläche
- Kartenbedienung für Touch, Maus und Tastatur optimiert
- Service-Worker-Cache auf Version v13 angehoben


## 2026-07-26 – Vollständige Abschlussprüfung
- Cache-Versionen auf allen Seiten vereinheitlicht.
- Alte Karten-CSS-Implementierung vollständig entfernt.
- Leaflet-Ladevorgang entkoppelt und mit Zeitüberschreitung/Fallback vorbereitet.
- Kartenstatus, Filterbereich, Lightbox und Preisrechner bereinigt.
- Netlify-Sicherheitsheader ergänzt.
