(() => {
  'use strict';
  const translations = {
  "de": {
    "meta": {
      "title": "Alba’s Streetfood | Cevapcici in Leutkirch",
      "description": "Alba’s Streetfood in Leutkirch: Cevapcici, Hamburger, Salat, Pommes und Getränke. Jeden Sonntag von 10:00 bis 20:00 Uhr bei Goldschmitt Techmobil."
    },
    "skip": "Zum Inhalt springen",
    "navAria": "Hauptnavigation",
    "brandHome": "Alba’s Streetfood Startseite",
    "factsAria": "Wichtige Informationen",
    "brandSubtitle": "Durim Gashi",
    "menuToggle": "Navigation öffnen",
    "menuClose": "Navigation schließen",
    "carousel": {
      "aria": "Medienkarussell",
      "previous": "Vorheriger Inhalt",
      "next": "Nächster Inhalt",
      "select": "Inhalt auswählen",
      "goTo": "Inhalt {number} anzeigen",
      "status": "Inhalt {current} von {total}"
    },
    "nav": {
      "menu": "Speisekarte",
      "about": "Über uns",
      "location": "Standort",
      "gallery": "Galerie",
      "instagram": "Instagram",
      "home": "Startseite",
      "contact": "Kontakt"
    },
    "language": {
      "label": "Sprache auswählen"
    },
    "hero": {
      "defaultStatus": "Jeden Sonntag geöffnet",
      "hours": "10:00–20:00 Uhr",
      "eyebrow": "Cevapcici · Leutkirch · Sonntag",
      "title": "Cevapcici vom Grill.<br>Sonntags in Leutkirch.",
      "lead": "Alba’s Streetfood steht jeden Sonntag von 10:00 bis 20:00 Uhr bei Goldschmitt Techmobil, Kemptener Str. 54. Cevapcici gibt es in mehreren Portionsgrößen sowie im Brot oder auf dem Teller.",
      "route": "Route planen",
      "food": "Speisekarte",
      "cardLabel": "Dein Sonntags-Stopp",
      "cardAria": "Öffnungszeiten und Standort",
      "when": "Wann",
      "everySunday": "Jeden Sonntag",
      "where": "Wo",
      "who": "Wer",
      "calendar": "Termin im Kalender speichern",
      "scroll": "Zur Speisekarte scrollen"
    },
    "status": {
      "open": "Jetzt geöffnet · bis 20:00 Uhr",
      "today": "Heute geöffnet · 10:00–20:00 Uhr",
      "closedToday": "Heute bereits geschlossen",
      "next": "Nächster Sonntag: {date} · 10:00–20:00 Uhr"
    },
    "promotion": {
      "eyebrow": "Sonntagsaktion",
      "title": "Sonderpreise am 26. Juli.",
      "text": "Aufgrund der hohen Nachfrage ist Alba’s Streetfood am Sonntag wieder an der gewohnten Adresse. Für diesen Verkaufstag gelten reduzierte Preise.",
      "dateLine": "Sonntag, {date} · 10:00–20:00 Uhr",
      "locationLine": "Kemptener Str. 54 · Leutkirch",
      "note": "Die Aktionspreise gelten ausschließlich am {date}. Danach gelten wieder die regulären Preise.",
      "menuButton": "Speisekarte ansehen",
      "instagramButton": "Aktuelles auf Instagram",
      "metaAria": "Aktionszeitraum und Standort",
      "pricesAria": "Aktionspreise",
      "regularPrice": "Regulär {price}",
      "specialPrice": "Aktionspreis {price}",
      "items": {
        "cevapcici5": "5 Cevapcici",
        "cevapcici7": "7 Cevapcici",
        "cevapcici10": "10 Cevapcici",
        "hamburger": "Hamburger"
      }
    },
    "facts": {
      "oneTitle": "Vom Grill",
      "oneText": "Zubereitung am Verkaufstag",
      "twoTitle": "Balkan-Geschmack",
      "twoText": "Cevapcici und Streetfood",
      "threeTitle": "Jeden Sonntag",
      "threeText": "10:00 bis 20:00 Uhr",
      "fourTitle": "Leutkirch",
      "fourText": "Kemptener Straße 54"
    },
    "menu": {
      "eyebrow": "Das Herzstück",
      "title": "Aktuelle Speisekarte und Preise.",
      "intro": "Cevapcici in drei Portionsgrößen, Hamburger, Salat, Pommes und ein Hamburger-Menü. Albanische Getränke und bekannte Softdrinks ergänzen die Auswahl.",
      "openImage": "Bild öffnen",
      "bestseller": "Bestseller",
      "filling": "Sattmacher",
      "sharing": "Zum Teilen",
      "itemOne": "Cevapcici",
      "itemOneText": "Wahlweise im Brot oder ohne Brot auf dem Teller. Erhältlich mit 5, 7 oder 10 Stück.",
      "itemTwo": "Hamburger",
      "itemTwoText": "Hamburger einzeln oder als Menü mit Pommes und Getränk.",
      "itemThree": "Salat & Pommes",
      "itemThreeText": "Salat mit Gurken, Tomaten, Oliven, Zwiebeln und Weißkäse sowie Pommes als Beilage.",
      "additionalEyebrow": "Weitere Auswahl",
      "additionalTitle": "Hamburger, Beilagen & Getränke.",
      "additionalIntro": "Die bekannten Preise stehen direkt auf der Speisekarte. Getränkesorten und einzelne Verfügbarkeiten können wechseln.",
      "itemFour": "Hamburger",
      "itemFourText": "Hamburger vom Foodtruck. Zutaten und Allergene bitte vor Ort erfragen.",
      "itemFive": "Salat & Pommes",
      "itemFiveText": "Salat und Pommes können einzeln bestellt werden.",
      "itemSix": "Albanische Getränke & Softdrinks",
      "itemSixText": "Albanische Erfrischungsgetränke und bekannte Softdrinks. Sorten und Preise nach Verfügbarkeit.",
      "variantsOnSite": "Varianten vor Ort",
      "changingSelection": "Wechselnde Auswahl",
      "varietiesOnSite": "Sorten vor Ort",
      "pricesOnSite": "Preise vor Ort",
      "confirmationNote": "Preise laut aktuell vorliegender Speisekarte. Produktbilder sind teilweise Visualisierungen. Zutaten, Allergene, Getränkesorten und kurzfristige Änderungen bitte vor Ort oder über Instagram prüfen.",
      "priceOnSite": "Preis vor Ort",
      "selectionOnSite": "Auswahl vor Ort",
      "note": "Die gezeigten Speisen stehen für die Ausrichtung. Verbindlich sind die vor Ort bestätigten Angaben.",
      "instagram": "Aktuelles auf Instagram"
    },
    "story": {
      "eyebrow": "Über Alba’s Streetfood",
      "title": "Alba’s Streetfood in Leutkirch.",
      "text": "Alba’s Streetfood wird von Durim Gashi betrieben. Der Foodtruck steht jeden Sonntag von 10:00 bis 20:00 Uhr bei Goldschmitt Techmobil in der Kemptener Str. 54 in Leutkirch.",
      "ownerLabel": "Inhaber",
      "owner": "Inhaber · Alba’s Streetfood",
      "instagram": "@albas_streetfood auf Instagram",
      "textTwo": "Im Mittelpunkt stehen Cevapcici in mehreren Portionsgrößen, Hamburger, Pommes, Salat und Getränke."
    },
    "location": {
      "eyebrow": "Hier findest du uns",
      "title": "Jeden Sonntag bei Goldschmitt Techmobil.",
      "text": "Geöffnet von 10:00 bis 20:00 Uhr in der Kemptener Str. 54. Für kurzfristige Änderungen lohnt sich ein Blick auf Instagram.",
      "maps": "In Google Maps öffnen",
      "copy": "Adresse kopieren",
      "copied": "Adresse kopiert",
      "label": "Standortübersicht",
      "routeHint": "Route direkt öffnen",
      "calendarShort": "Kalender",
      "calendarHint": "Termin dauerhaft speichern",
      "instagramHint": "Änderungen kurzfristig prüfen"
    },
    "gallery": {
      "eyebrow": "Eindrücke",
      "title": "Foodtruck und Auswahl.",
      "intro": "Foodtruck, Gerichte und Details in einer ruhigen Auswahl.",
      "truck": "Foodtruck & Atmosphäre",
      "owner": "Foodtruck im Detail",
      "classic": "Der Klassiker",
      "plate": "Herzhaft serviert",
      "grill": "Direkt am Grill",
      "platter": "Grill & Beilagen"
    },
    "faq": {
      "eyebrow": "Kurz beantwortet",
      "title": "Wichtige Fragen vor dem Besuch.",
      "q1": "Wann ist Alba’s Streetfood geöffnet?",
      "a1": "Jeden Sonntag von 10:00 bis 20:00 Uhr.",
      "q2": "Wo steht der Foodtruck?",
      "a2": "Bei Goldschmitt Techmobil, Kemptener Str. 54, 88299 Leutkirch im Allgäu.",
      "q3": "Was gibt es zu essen?",
      "a3": "Cevapcici mit 5, 7 oder 10 Stück, Hamburger, Salat, Pommes, ein Hamburger-Menü sowie albanische Getränke und Softdrinks.",
      "q4": "Wo gibt es aktuelle Hinweise?",
      "a4": "Aktuelle Informationen, Bilder und mögliche Änderungen werden über Instagram geteilt."
    },
    "cta": {
      "eyebrow": "Dein Plan für Sonntag",
      "title": "Cevapcici, Route, Öffnungszeiten.",
      "line": "Sonntag, 10:00 bis 20:00 Uhr · Goldschmitt Techmobil · Kemptener Str. 54",
      "route": "Route planen",
      "follow": "Instagram folgen"
    },
    "footer": {
      "claim": "Cevapcici und Streetfood in Leutkirch",
      "visit": "Besuch",
      "contact": "Kontakt",
      "website": "Website",
      "everySunday": "Jeden Sonntag",
      "legal": "Impressum",
      "privacy": "Datenschutz",
      "accessibility": "Barrierefreiheit",
      "top": "Nach oben",
      "final": "Sonntags in Leutkirch."
    },
    "metaPages": {
      "home": {
        "title": "Alba’s Streetfood | Cevapcici in Leutkirch",
        "description": "Cevapcici, Hamburger, Pommes, Salat und Getränke in Leutkirch. Jeden Sonntag von 10:00 bis 20:00 Uhr bei Goldschmitt Techmobil."
      },
      "menu": {
        "title": "Speisekarte | Alba’s Streetfood Leutkirch",
        "description": "Aktuelle Preise für Cevapcici, Hamburger, Salat, Pommes und Hamburger-Menü bei Alba’s Streetfood in Leutkirch."
      },
      "about": {
        "title": "Über uns | Alba’s Streetfood & Durim Gashi",
        "description": "Informationen über Durim Gashi, Alba’s Streetfood und die festen Verkaufszeiten in Leutkirch."
      },
      "location": {
        "title": "Standort & Öffnungszeiten | Alba’s Streetfood",
        "description": "Alba’s Streetfood findest du jeden Sonntag von 10:00 bis 20:00 Uhr bei Goldschmitt Techmobil, Kemptener Str. 54 in Leutkirch."
      },
      "gallery": {
        "title": "Galerie | Alba’s Streetfood Leutkirch",
        "description": "Ausgewählte Bilder vom Foodtruck und den gezeigten Streetfood-Gerichten bei Alba’s Streetfood."
      },
      "contact": {
        "title": "Kontakt | Alba’s Streetfood Leutkirch",
        "description": "Kontakt, Instagram, Route und Kalendertermin für Alba’s Streetfood in Leutkirch im Allgäu."
      }
    },
    "pages": {
      "menu": {
        "eyebrow": "Speisekarte",
        "title": "Speisekarte",
        "lead": "Aktuelle Gerichte, Portionsgrößen und bekannte Preise auf einen Blick."
      },
      "about": {
        "eyebrow": "Über uns",
        "title": "Über Alba’s Streetfood",
        "lead": "Betreiber, Angebot und feste Eckdaten des Foodtrucks."
      },
      "location": {
        "eyebrow": "Standort & Öffnungszeiten",
        "title": "Standort &amp; Öffnungszeiten",
        "lead": "Adresse, Route, Öffnungsstatus und Sonntagstermin."
      },
      "gallery": {
        "eyebrow": "Galerie",
        "title": "Galerie",
        "lead": "Ausgewählte Motive zu Foodtruck und Speisen."
      },
      "contact": {
        "eyebrow": "Kontakt",
        "title": "Kontakt",
        "lead": "Aktuelle Hinweise, direkte Route und Sonntagstermin."
      }
    },
    "home": {
      "eyebrow": "Alles für deinen Besuch",
      "title": "Essen, Standort und aktuelle Infos auf einen Blick.",
      "intro": "Sieh dir die typische Auswahl an, öffne direkt die Route und prüfe vor deinem Besuch aktuelle Hinweise auf Instagram.",
      "menuEyebrow": "Speisekarte",
      "menuTitle": "Was auf den Grill kommt.",
      "menuText": "Aktuelle Gerichte, Portionsgrößen und bekannte Preise.",
      "menuLink": "Zur Speisekarte",
      "aboutEyebrow": "Über uns",
      "aboutTitle": "Der Mensch hinter dem Grill.",
      "aboutText": "Lerne Durim Gashi und den persönlichen Charakter von Alba’s Streetfood kennen.",
      "aboutLink": "Mehr über Durim",
      "locationEyebrow": "Standort",
      "locationTitle": "Jeden Sonntag in Leutkirch.",
      "locationText": "Adresse, Öffnungsstatus, Route und Kalendertermin für deinen Sonntag.",
      "locationLink": "Standort ansehen"
    },
    "values": {
      "eyebrow": "Dafür steht Alba’s",
      "title": "Die festen Eckdaten auf einen Blick.",
      "intro": "Betreiber, Angebot, Standort und Öffnungszeiten werden klar und nachvollziehbar dargestellt.",
      "freshTitle": "Betreiber",
      "freshText": "Alba’s Streetfood wird von Durim Gashi betrieben.",
      "simpleTitle": "Angebot",
      "simpleText": "Cevapcici, Hamburger, Salat, Pommes und Getränke.",
      "currentTitle": "Aktuelle Auswahl",
      "currentText": "Die bekannten Preise sind veröffentlicht. Getränkesorten und Änderungen werden vor Ort oder über Instagram bestätigt.",
      "hospitalityTitle": "Standort",
      "hospitalityText": "Kemptener Str. 54 in Leutkirch im Allgäu.",
      "sundayTitle": "Fester Sonntag",
      "sundayText": "Jeden Sonntag von 10:00 bis 20:00 Uhr."
    },
    "contact": {
      "eyebrow": "Kontakt & aktuelle Hinweise",
      "title": "Schnell zur richtigen Information.",
      "intro": "Aktuelle Hinweise und direkte Nachrichten laufen derzeit über Instagram. Route und Sonntagstermin kannst du hier direkt öffnen.",
      "instagramTitle": "Instagram",
      "instagramText": "Direkte Nachrichten, aktuelle Bilder und kurzfristige Hinweise zur Sonntagsauswahl.",
      "routeTitle": "Anfahrt",
      "routeButton": "Route öffnen",
      "calendarTitle": "Sonntag speichern",
      "calendarText": "Den wiederkehrenden Termin direkt in den persönlichen Kalender übernehmen.",
      "calendarButton": "Kalenderdatei laden"
    },
    "visitFlow": {
      "eyebrow": "Einfach vorbeikommen",
      "title": "So wird aus Hunger ein Plan.",
      "intro": "Drei Schritte, keine Umwege: Auswahl ansehen, Route öffnen und den Sonntag genießen.",
      "stepOneTitle": "Auswahl ansehen",
      "stepOneText": "Verschaffe dir einen Eindruck von den typischen Gerichten bei Alba’s Streetfood.",
      "stepTwoTitle": "Aktuelles prüfen",
      "stepTwoText": "Kurzfristige Änderungen und die aktuelle Auswahl werden über Instagram geteilt.",
      "stepThreeTitle": "Route öffnen",
      "stepThreeText": "Kemptener Str. 54 in Leutkirch. Jeden Sonntag von 10:00 bis 20:00 Uhr.",
      "menuLink": "Zur Speisekarte",
      "instagramLink": "Instagram öffnen",
      "routeLink": "Route planen"
    },
    "menuInfo": {
      "currentTitle": "Aktuelle Speisekarte",
      "currentText": "Die bekannten Preise sind eingetragen. Getränkesorten und kurzfristige Änderungen werden vor Ort oder über Instagram bestätigt.",
      "allergenTitle": "Zutaten & Allergene",
      "allergenText": "Bei Allergien oder Unverträglichkeiten bitte vor der Bestellung nach den verbindlichen Angaben fragen.",
      "availabilityTitle": "Verfügbarkeit",
      "availabilityText": "Getränkesorten und einzelne Angebote können je nach Verfügbarkeit variieren."
    },
    "mobile": {
      "menu": "Speisekarte",
      "route": "Route",
      "instagram": "Instagram",
      "aria": "Schnellaktionen"
    },
    "lightbox": {
      "close": "Bild schließen",
      "previous": "Vorheriger Inhalt",
      "next": "Nächster Inhalt",
      "aria": "Bildansicht"
    },
    "legalStatus": {
      "title": "Vorschau",
      "text": "Preise und Öffnungszeiten sind aktualisiert. Kontakt-, Zutaten-, Allergie- und Rechtsangaben werden noch ergänzt."
    },
    "media": {
      "visualizationNotice": "Einzelne Bilddarstellungen sind Visualisierungen. Die tatsächliche Zubereitung und Darstellung kann abweichen."
    },
    "serviceWorker": {
      "updated": "Eine neue Version ist verfügbar. Seite neu laden."
    },
    "menuPrices": {
      "pieces5": "5 Stück",
      "pieces7": "7 Stück",
      "pieces10": "10 Stück",
      "burgerSingle": "Hamburger",
      "burgerMenu": "Hamburger + Pommes + Getränk",
      "salad": "Salat",
      "fries": "Pommes",
      "serveChoice": "Wahlweise im Brot oder auf dem Teller",
      "saladIngredients": "Gurken · Tomaten · Oliven · Zwiebeln · Weißkäse",
      "drinksSelection": "Albanische Getränke und Softdrinks · Sorten und Preise vor Ort",
      "verifiedDate": "Stand der Preise: {{date}}"
    },
    "map": {
      "regionAria": "Hartë satelitore interaktive për vendndodhjen e Alba’s Streetfood",
      "route": "Hap udhëzimet",
      "large": "Hap hartën e madhe",
      "satellite": "Satelit",
      "roadmap": "Rrugë",
      "layerAria": "Zgjidh pamjen e hartës",
      "loading": "Harta po ngarkohet …",
      "readySatellite": "Harta satelitore aktive",
      "readyRoadmap": "Harta rrugore aktive",
      "satelliteFallback": "Pamjet satelitore nuk janë të disponueshme. Harta rrugore është aktive.",
      "degraded": "Të dhënat e hartës nuk janë të disponueshme",
      "recenter": "Qendro vendndodhjen",
      "panHint": "Hartë interaktive. Tërhiqe për ta lëvizur dhe përdor plus ose minus për zmadhim."
    },
    "interaction": {
      "share": "Website teilen",
      "install": "Als App speichern",
      "shareTitle": "Weitergeben",
      "shareText": "Website, Speisekarte und Standort direkt mit anderen teilen.",
      "shared": "Geteilt",
      "copied": "Link kopiert",
      "installed": "App wurde installiert",
      "online": "Verbindung wiederhergestellt",
      "offline": "Du bist offline. Gespeicherte Seiten bleiben verfügbar."
    },
    "live": {
      "closesIn": "Noch {time} geöffnet",
      "opensIn": "Öffnet in {time}",
      "daysUntil": "Nächster Verkauf in {count} Tagen",
      "tomorrow": "Nächster Verkauf morgen",
      "todayLater": "Öffnet heute in {time}"
    },
    "visitPlanner": {
      "eyebrow": "Besuch planen",
      "title": "Deinen Sonntag in wenigen Schritten vorbereiten.",
      "intro": "Wähle eine ungefähre Uhrzeit, merke dir den Termin und öffne bei Bedarf direkt die Route. Das ist keine Reservierung.",
      "benefitsAria": "Vorteile der Besuchsplanung",
      "benefitOne": "Nächster geöffneter Sonntag wird automatisch eingesetzt.",
      "benefitTwo": "Kalendereintrag wird direkt auf dem Gerät erstellt.",
      "benefitThree": "Auswahl bleibt auf diesem Gerät gespeichert.",
      "date": "Datum",
      "time": "Uhrzeit",
      "guests": "Personen",
      "summaryLabel": "Geplant",
      "summary": "{date} um {time} Uhr · {guests} Personen",
      "calendar": "Kalendereintrag erstellen",
      "note": "Die Planung ist nur eine persönliche Erinnerung und keine Bestellung oder Platzreservierung.",
      "calendarSaved": "Kalendereintrag wurde erstellt",
      "eventTitle": "Alba’s Streetfood besuchen",
      "eventDescription": "Besuch bei Alba’s Streetfood. Aktuelle Hinweise vor der Anfahrt auf Instagram prüfen."
    },
    "menuFilter": {
      "aria": "Speisekarte filtern",
      "all": "Alle",
      "cevapcici": "Cevapcici",
      "burger": "Hamburger",
      "sides": "Beilagen",
      "drinks": "Getränke"
    },
    "menuPlanner": {
      "eyebrow": "Preisrechner",
      "title": "Auswahl zusammenstellen und Preis überblicken.",
      "intro": "Stelle unverbindlich zusammen, was dich interessiert. Der Rechner dient nur zur Orientierung und sendet keine Bestellung ab.",
      "total": "Gesamtsumme",
      "empty": "Noch nichts ausgewählt",
      "count": "{count} Artikel ausgewählt",
      "copy": "Auswahl kopieren",
      "share": "Auswahl teilen",
      "reset": "Zurücksetzen",
      "note": "Keine Onlinebestellung. Verfügbarkeit, Zutaten und Allergene bitte vor Ort prüfen.",
      "itemsAria": "Produkte auswählen",
      "minus": "Einmal {item} entfernen",
      "plus": "Einmal {item} hinzufügen",
      "quantity": "Anzahl {item}",
      "copied": "Auswahl wurde kopiert",
      "resetDone": "Auswahl wurde zurückgesetzt",
      "shareTitle": "Meine Auswahl bei Alba’s Streetfood",
      "summaryTitle": "Unverbindliche Auswahl",
      "totalLine": "Gesamtsumme: {total}",
      "items": {
        "cevapcici-5": "5 Stück Cevapcici",
        "cevapcici-7": "7 Stück Cevapcici",
        "cevapcici-10": "10 Stück Cevapcici",
        "hamburger": "Hamburger",
        "salat": "Salat",
        "pommes": "Pommes",
        "hamburger-menu": "Hamburger + Pommes + Getränk"
      }
    }
  },
  "en": {
    "meta": {
      "title": "Alba’s Streetfood | Cevapcici in Leutkirch",
      "description": "Alba’s Streetfood in Leutkirch: cevapcici, hamburgers, salad, fries and drinks. Every Sunday from 10:00 to 20:00 at Goldschmitt Techmobil."
    },
    "skip": "Skip to content",
    "navAria": "Main navigation",
    "brandHome": "Alba’s Streetfood homepage",
    "factsAria": "Important information",
    "brandSubtitle": "Durim Gashi",
    "menuToggle": "Open navigation",
    "menuClose": "Close navigation",
    "carousel": {
      "aria": "Media carousel",
      "previous": "Previous item",
      "next": "Next item",
      "select": "Select item",
      "goTo": "Show item {number}",
      "status": "Item {current} of {total}"
    },
    "nav": {
      "menu": "Menu",
      "about": "About us",
      "location": "Location",
      "gallery": "Gallery",
      "instagram": "Instagram",
      "home": "Home",
      "contact": "Contact"
    },
    "language": {
      "label": "Choose language"
    },
    "hero": {
      "defaultStatus": "Open every Sunday",
      "hours": "10:00–20:00",
      "eyebrow": "Cevapcici · Leutkirch · Sunday",
      "title": "Cevapcici from the grill.<br>Sundays in Leutkirch.",
      "lead": "Alba’s Streetfood is open every Sunday from 10:00 to 20:00 at Goldschmitt Techmobil, Kemptener Str. 54. Cevapcici are available in several portion sizes, in bread or on a plate.",
      "route": "Get directions",
      "food": "Menu",
      "cardLabel": "Your Sunday stop",
      "cardAria": "Opening hours and location",
      "when": "When",
      "everySunday": "Every Sunday",
      "where": "Where",
      "who": "Who",
      "calendar": "Save to calendar",
      "scroll": "Scroll to the menu"
    },
    "status": {
      "open": "Open now · until 20:00",
      "today": "Open today · 10:00–20:00",
      "closedToday": "Closed for today",
      "next": "Next Sunday: {date} · 10:00–20:00"
    },
    "promotion": {
      "eyebrow": "Sunday special",
      "title": "Special prices on 26 July.",
      "text": "Due to high demand, Alba’s Streetfood will be back at the usual address on Sunday. Reduced prices apply for this service day.",
      "dateLine": "Sunday, {date} · 10:00–20:00",
      "locationLine": "Kemptener Str. 54 · Leutkirch",
      "note": "These special prices apply only on {date}. Regular prices apply afterwards.",
      "menuButton": "View the menu",
      "instagramButton": "Latest on Instagram",
      "metaAria": "Promotion date and location",
      "pricesAria": "Special prices",
      "regularPrice": "Regular {price}",
      "specialPrice": "Special price {price}",
      "items": {
        "cevapcici5": "5 Cevapcici",
        "cevapcici7": "7 Cevapcici",
        "cevapcici10": "10 Cevapcici",
        "hamburger": "Hamburger"
      }
    },
    "facts": {
      "oneTitle": "From the grill",
      "oneText": "Prepared on the day of sale",
      "twoTitle": "Balkan flavour",
      "twoText": "Cevapcici and street food",
      "threeTitle": "Every Sunday",
      "threeText": "10:00 to 20:00",
      "fourTitle": "Leutkirch",
      "fourText": "Kemptener Straße 54"
    },
    "menu": {
      "eyebrow": "The centrepiece",
      "title": "Current menu and prices.",
      "intro": "Cevapcici in three portion sizes, hamburgers, salad, fries and a hamburger meal. Albanian drinks and familiar soft drinks complete the selection.",
      "openImage": "Open image",
      "bestseller": "Bestseller",
      "filling": "Full meal",
      "sharing": "To share",
      "itemOne": "Cevapcici",
      "itemOneText": "Served in bread or without bread on a plate. Available with 5, 7 or 10 pieces.",
      "itemTwo": "Hamburger",
      "itemTwoText": "Hamburger on its own or as a meal with fries and a drink.",
      "itemThree": "Salad & fries",
      "itemThreeText": "Salad with cucumber, tomatoes, olives, onions and white cheese, plus fries as a side.",
      "additionalEyebrow": "More choices",
      "additionalTitle": "Hamburgers, sides & drinks.",
      "additionalIntro": "Known prices are listed directly. Drink varieties and individual availability may change.",
      "itemFour": "Hamburger",
      "itemFourText": "Foodtruck hamburger. Please ask about ingredients and allergens before ordering.",
      "itemFive": "Salad & fries",
      "itemFiveText": "Salad and fries can be ordered separately.",
      "itemSix": "Albanian drinks & soft drinks",
      "itemSixText": "Albanian refreshments and familiar soft drinks. Varieties and prices depend on availability.",
      "variantsOnSite": "Variants on site",
      "changingSelection": "Changing selection",
      "varietiesOnSite": "Varieties on site",
      "pricesOnSite": "Prices on site",
      "confirmationNote": "Prices according to the currently available menu. Some product images are visualisations. Please check ingredients, allergens, drink varieties and short-notice changes on site or Instagram.",
      "priceOnSite": "Current price on site",
      "selectionOnSite": "Current selection on site",
      "note": "The dishes shown represent the typical direction. Check Instagram for the current Sunday selection before visiting.",
      "instagram": "Latest on Instagram"
    },
    "story": {
      "eyebrow": "Street food made with heart",
      "title": "Alba’s Streetfood in Leutkirch.",
      "text": "Alba’s Streetfood is operated by Durim Gashi. The foodtruck is at Goldschmitt Techmobil, Kemptener Str. 54 in Leutkirch every Sunday from 10:00 to 20:00.",
      "ownerLabel": "Owner",
      "owner": "Owner · Alba’s Streetfood",
      "instagram": "@albas_streetfood on Instagram",
      "textTwo": "The menu focuses on cevapcici in several portion sizes, hamburgers, fries, salad and drinks."
    },
    "location": {
      "eyebrow": "Where to find us",
      "title": "Every Sunday at Goldschmitt Techmobil.",
      "text": "Open from 10:00 to 20:00 at Kemptener Str. 54. Check Instagram for short-notice changes.",
      "maps": "Open in Google Maps",
      "copy": "Copy address",
      "copied": "Address copied",
      "label": "Location overview",
      "routeHint": "Open directions directly",
      "calendarShort": "Calendar",
      "calendarHint": "Save the recurring event",
      "instagramHint": "Check short-notice changes"
    },
    "gallery": {
      "eyebrow": "A look behind the grill",
      "title": "Food truck and selection.",
      "intro": "Food truck, dishes and details in a calm, focused selection.",
      "truck": "Food truck & atmosphere",
      "owner": "Food truck detail",
      "classic": "The classic",
      "plate": "Hearty and served fresh",
      "grill": "Straight from the grill",
      "platter": "Grill & sides"
    },
    "faq": {
      "eyebrow": "Quick answers",
      "title": "Important questions before your visit.",
      "q1": "When is Alba’s Streetfood open?",
      "a1": "Every Sunday from 10:00 to 20:00.",
      "q2": "Where is the food truck?",
      "a2": "At Goldschmitt Techmobil, Kemptener Str. 54, 88299 Leutkirch im Allgäu.",
      "q3": "What food is available?",
      "a3": "Cevapcici with 5, 7 or 10 pieces, hamburgers, salad, fries, a hamburger meal, Albanian drinks and soft drinks.",
      "q4": "Where can I find current updates?",
      "a4": "Current information, photos and possible changes are shared on Instagram."
    },
    "cta": {
      "eyebrow": "Your Sunday plan",
      "title": "Cevapcici, route and opening hours.",
      "line": "Sunday, 10:00 to 20:00 · Goldschmitt Techmobil · Kemptener Str. 54",
      "route": "Get directions",
      "follow": "Follow on Instagram"
    },
    "footer": {
      "claim": "Cevapcici and street food in Leutkirch",
      "visit": "Visit",
      "contact": "Contact",
      "website": "Website",
      "everySunday": "Every Sunday",
      "legal": "Legal notice",
      "privacy": "Privacy",
      "accessibility": "Accessibility",
      "top": "Back to top",
      "final": "Fresh from the grill in Leutkirch."
    },
    "metaPages": {
      "home": {
        "title": "Alba’s Streetfood | Cevapcici in Leutkirch",
        "description": "Freshly grilled cevapcici and Balkan street food made with heart. Every Sunday from 11 am to 7 pm at Kemptener Str. 54 in Leutkirch."
      },
      "menu": {
        "title": "Menu | Alba’s Streetfood Leutkirch",
        "description": "Typical dishes and current Sunday information for Alba’s Streetfood in Leutkirch."
      },
      "about": {
        "title": "About us | Alba’s Streetfood & Durim Gashi",
        "description": "Information about Durim Gashi, Alba’s Streetfood and the regular Sunday opening hours in Leutkirch."
      },
      "location": {
        "title": "Location & opening hours | Alba’s Streetfood",
        "description": "Find Alba’s Streetfood every Sunday from 11 am to 7 pm at Kemptener Str. 54, 88299 Leutkirch im Allgäu."
      },
      "gallery": {
        "title": "Gallery | Alba’s Streetfood Leutkirch",
        "description": "Selected images of the food truck and the street food dishes shown by Alba’s Streetfood."
      },
      "contact": {
        "title": "Contact | Alba’s Streetfood Leutkirch",
        "description": "Contact, Instagram, directions and calendar event for Alba’s Streetfood in Leutkirch im Allgäu."
      }
    },
    "pages": {
      "menu": {
        "eyebrow": "Menu",
        "title": "Menu",
        "lead": "Current dishes, portion sizes and known prices at a glance."
      },
      "about": {
        "eyebrow": "About us",
        "title": "About Alba’s Streetfood",
        "lead": "Operator, food and confirmed key details."
      },
      "location": {
        "eyebrow": "Location & opening hours",
        "title": "Location &amp; opening hours",
        "lead": "Address, route, opening status and calendar date."
      },
      "gallery": {
        "eyebrow": "Gallery",
        "title": "Gallery",
        "lead": "Selected food truck and food images."
      },
      "contact": {
        "eyebrow": "Contact",
        "title": "Contact",
        "lead": "Current information, direct route and Sunday date."
      }
    },
    "home": {
      "eyebrow": "Everything for your visit",
      "title": "Food, location and current information at a glance.",
      "intro": "Explore the typical selection, open the route directly and check Instagram for current information before visiting.",
      "menuEyebrow": "Menu",
      "menuTitle": "What goes on the grill.",
      "menuText": "Current dishes, portion sizes and known prices.",
      "menuLink": "View the menu",
      "aboutEyebrow": "About us",
      "aboutTitle": "The person behind the grill.",
      "aboutText": "Meet Durim Gashi and discover the personal character of Alba’s Streetfood.",
      "aboutLink": "Meet Durim",
      "locationEyebrow": "Location",
      "locationTitle": "Every Sunday in Leutkirch.",
      "locationText": "Address, opening status, route and calendar entry for your Sunday.",
      "locationLink": "View location"
    },
    "values": {
      "eyebrow": "What Alba’s stands for",
      "title": "The confirmed key details at a glance.",
      "intro": "Operator, food, location and opening hours are presented clearly and separately.",
      "freshTitle": "Operator",
      "freshText": "Alba’s Streetfood is operated by Durim Gashi.",
      "simpleTitle": "Food",
      "simpleText": "Cevapcici, hamburgers, salad, fries and drinks.",
      "currentTitle": "Current selection",
      "currentText": "Known prices are published. Drink varieties and changes are confirmed on site or Instagram.",
      "hospitalityTitle": "Location",
      "hospitalityText": "Kemptener Str. 54 in Leutkirch im Allgäu.",
      "sundayTitle": "A fixed Sunday",
      "sundayText": "Every Sunday from 10:00 to 20:00."
    },
    "contact": {
      "eyebrow": "Contact & current information",
      "title": "Get the right information quickly.",
      "intro": "Current updates and direct messages are currently handled through Instagram. The route and Sunday calendar entry can be opened here.",
      "instagramTitle": "Instagram",
      "instagramText": "Direct messages, current photos and short-notice updates about the Sunday selection.",
      "routeTitle": "Directions",
      "routeButton": "Open directions",
      "calendarTitle": "Save Sunday",
      "calendarText": "Add the recurring event directly to your personal calendar.",
      "calendarButton": "Download calendar file"
    },
    "visitFlow": {
      "eyebrow": "Simply stop by",
      "title": "Turn hunger into a plan.",
      "intro": "Three steps, no detours: view the selection, open the route and enjoy Sunday.",
      "stepOneTitle": "View the selection",
      "stepOneText": "Get an impression of the typical dishes at Alba’s Streetfood.",
      "stepTwoTitle": "Check updates",
      "stepTwoText": "Short-notice changes and the current selection are shared on Instagram.",
      "stepThreeTitle": "Open the route",
      "stepThreeText": "Kemptener Str. 54 in Leutkirch. Every Sunday from 10:00 to 20:00.",
      "menuLink": "View menu",
      "instagramLink": "Open Instagram",
      "routeLink": "Plan route"
    },
    "menuInfo": {
      "currentTitle": "Current menu",
      "currentText": "Known prices are listed. Drink varieties and short-notice changes are confirmed on site or Instagram.",
      "allergenTitle": "Ingredients & allergens",
      "allergenText": "If you have allergies or intolerances, please ask for the binding information before ordering.",
      "availabilityTitle": "Availability",
      "availabilityText": "Drink varieties and individual items may vary depending on availability."
    },
    "mobile": {
      "menu": "Menu",
      "route": "Route",
      "instagram": "Instagram",
      "aria": "Quick actions"
    },
    "lightbox": {
      "close": "Close image",
      "previous": "Previous item",
      "next": "Next item",
      "aria": "Image viewer"
    },
    "legalStatus": {
      "title": "Preview",
      "text": "Prices and opening hours are updated. Contact, ingredient, allergen and legal details are still being completed."
    },
    "media": {
      "visualizationNotice": "Some images are visualisations. Actual preparation and presentation may differ."
    },
    "serviceWorker": {
      "updated": "A new version is available. Reload the page."
    },
    "menuPrices": {
      "pieces5": "5 pieces",
      "pieces7": "7 pieces",
      "pieces10": "10 pieces",
      "burgerSingle": "Hamburger",
      "burgerMenu": "Hamburger + fries + drink",
      "salad": "Salad",
      "fries": "Fries",
      "serveChoice": "Served in bread or on a plate",
      "saladIngredients": "Cucumber · tomatoes · olives · onions · white cheese",
      "drinksSelection": "Albanian drinks and soft drinks · varieties and prices on site",
      "verifiedDate": "Prices last verified: {{date}}"
    },
    "map": {
      "regionAria": "Interactive satellite map for the Alba’s Streetfood location",
      "eyebrow": "Satellite view",
      "title": "Explore the location interactively.",
      "description": "The map shows the Goldschmitt Techmobil location. After loading, you can pan, zoom and switch between satellite and street view.",
      "load": "Load satellite map",
      "route": "Open directions",
      "consent": "External map tiles are loaded only after your selection. Satellite imagery is provided by Esri and street data by OpenStreetMap.",
      "loaded": "Satellite map loaded",
      "large": "Open large map",
      "unload": "Hide map",
      "iframeTitle": "Interactive satellite map of Alba’s Streetfood at Goldschmitt Techmobil",
      "satellite": "Satellite",
      "roadmap": "Road map",
      "layerAria": "Choose map view",
      "loading": "Loading map …",
      "loadingHint": "One moment, please.",
      "errorTitle": "The map could not be loaded.",
      "errorText": "Check the internet connection or open the location directly in Google Maps.",
      "retry": "Try again",
      "readySatellite": "Satellite map active",
      "readyRoadmap": "Street map active",
      "satelliteFallback": "Satellite imagery is unavailable. Street map active.",
      "degraded": "Map data is currently unavailable",
      "degradedText": "The location remains marked. Open directions for navigation.",
      "zoomIn": "Zoom in",
      "zoomOut": "Zoom out",
      "recenter": "Centre location",
      "controlsAria": "Map controls",
      "panHint": "Interactive map. Drag to move and use plus or minus to zoom."
    },
    "interaction": {
      "share": "Share website",
      "install": "Save as app",
      "shareTitle": "Share",
      "shareText": "Share the website, menu and location directly with others.",
      "shared": "Shared",
      "copied": "Link copied",
      "installed": "App installed",
      "online": "Connection restored",
      "offline": "You are offline. Saved pages remain available."
    },
    "live": {
      "closesIn": "Open for another {time}",
      "opensIn": "Opens in {time}",
      "daysUntil": "Next service in {count} days",
      "tomorrow": "Next service tomorrow",
      "todayLater": "Opens today in {time}"
    },
    "visitPlanner": {
      "eyebrow": "Plan your visit",
      "title": "Prepare your Sunday visit in a few steps.",
      "intro": "Choose an approximate time, save the date and open directions when needed. This is not a reservation.",
      "benefitsAria": "Benefits of visit planning",
      "benefitOne": "The next open Sunday is inserted automatically.",
      "benefitTwo": "A calendar entry is created directly on your device.",
      "benefitThree": "Your selection stays saved on this device.",
      "date": "Date",
      "time": "Time",
      "guests": "People",
      "summaryLabel": "Planned",
      "summary": "{date} at {time} · {guests} people",
      "calendar": "Create calendar entry",
      "note": "This plan is only a personal reminder and not an order or table reservation.",
      "calendarSaved": "Calendar entry created",
      "eventTitle": "Visit Alba’s Streetfood",
      "eventDescription": "Visit Alba’s Streetfood. Check Instagram for current information before travelling."
    },
    "menuFilter": {
      "aria": "Filter menu",
      "all": "All",
      "cevapcici": "Cevapcici",
      "burger": "Burger",
      "sides": "Sides",
      "drinks": "Drinks"
    },
    "menuPlanner": {
      "eyebrow": "Price calculator",
      "title": "Build a selection and see the price.",
      "intro": "Create a non-binding selection of what interests you. The calculator is for guidance only and does not submit an order.",
      "total": "Total",
      "empty": "Nothing selected yet",
      "count": "{count} items selected",
      "copy": "Copy selection",
      "share": "Share selection",
      "reset": "Reset",
      "note": "No online ordering. Please check availability, ingredients and allergens on site.",
      "itemsAria": "Select products",
      "minus": "Remove one {item}",
      "plus": "Add one {item}",
      "quantity": "Quantity of {item}",
      "copied": "Selection copied",
      "resetDone": "Selection reset",
      "shareTitle": "My selection at Alba’s Streetfood",
      "summaryTitle": "Non-binding selection",
      "totalLine": "Total: {total}",
      "items": {
        "cevapcici-5": "5 Cevapcici",
        "cevapcici-7": "7 Cevapcici",
        "cevapcici-10": "10 Cevapcici",
        "hamburger": "Hamburger",
        "salat": "Salad",
        "pommes": "Fries",
        "hamburger-menu": "Burger + fries + drink"
      }
    }
  },
  "sq": {
    "meta": {
      "title": "Alba’s Streetfood | Cevapcici në Leutkirch",
      "description": "Alba’s Streetfood në Leutkirch: qebapa, hamburger, sallatë, patate dhe pije. Çdo të diel nga ora 10:00 deri në 20:00 te Goldschmitt Techmobil."
    },
    "skip": "Kalo te përmbajtja",
    "navAria": "Navigimi kryesor",
    "brandHome": "Faqja kryesore e Alba’s Streetfood",
    "factsAria": "Informacione të rëndësishme",
    "brandSubtitle": "Durim Gashi",
    "menuToggle": "Hap navigimin",
    "menuClose": "Mbyll navigimin",
    "carousel": {
      "aria": "Karuseli i fotografive",
      "previous": "Fotografia e mëparshme",
      "next": "Fotografia tjetër",
      "select": "Zgjidh fotografinë",
      "goTo": "Shfaq fotografinë {number}",
      "status": "Fotografia {current} nga {total}"
    },
    "nav": {
      "menu": "Menuja",
      "about": "Rreth nesh",
      "location": "Vendndodhja",
      "gallery": "Galeria",
      "instagram": "Instagram",
      "home": "Ballina",
      "contact": "Kontakt"
    },
    "language": {
      "label": "Zgjidh gjuhën"
    },
    "hero": {
      "defaultStatus": "Hapur çdo të diel",
      "hours": "10:00–20:00",
      "eyebrow": "Cevapcici · Leutkirch · E diel",
      "title": "Cevapcici nga skara.<br>Të dielave në Leutkirch.",
      "lead": "Alba’s Streetfood është çdo të diel nga ora 10:00 deri në 20:00 te Goldschmitt Techmobil, Kemptener Str. 54. Qebapat ofrohen në disa porcione, në bukë ose në pjatë.",
      "route": "Planifiko rrugën",
      "food": "Menuja",
      "cardLabel": "Ndalesa jote e së dielës",
      "cardAria": "Orari i hapjes dhe vendndodhja",
      "when": "Kur",
      "everySunday": "Çdo të diel",
      "where": "Ku",
      "who": "Kush",
      "calendar": "Ruaje në kalendar",
      "scroll": "Shko te menuja"
    },
    "status": {
      "open": "Hapur tani · deri në 20:00",
      "today": "Hapur sot · 10:00–20:00",
      "closedToday": "Mbyllur për sot",
      "next": "E diela tjetër: {date} · 10:00–20:00"
    },
    "promotion": {
      "eyebrow": "Aksion i së dielës",
      "title": "Çmime speciale më 26 korrik.",
      "text": "Për shkak të kërkesës së lartë, Alba’s Streetfood do të jetë përsëri të dielën në adresën e zakonshme. Për këtë ditë vlejnë çmime të reduktuara.",
      "dateLine": "E diel, {date} · 10:00–20:00",
      "locationLine": "Kemptener Str. 54 · Leutkirch",
      "note": "Çmimet speciale vlejnë vetëm më {date}. Më pas vlejnë përsëri çmimet e rregullta.",
      "menuButton": "Shiko menunë",
      "instagramButton": "Të rejat në Instagram",
      "metaAria": "Data dhe vendndodhja e aksionit",
      "pricesAria": "Çmimet speciale",
      "regularPrice": "Normalisht {price}",
      "specialPrice": "Çmimi special {price}",
      "items": {
        "cevapcici5": "5 qebapa",
        "cevapcici7": "7 qebapa",
        "cevapcici10": "10 qebapa",
        "hamburger": "Hamburger"
      }
    },
    "facts": {
      "oneTitle": "E pjekur freskët",
      "oneText": "Përgatitet direkt në vend",
      "twoTitle": "Shije ballkanike",
      "twoText": "Cevapcici dhe street food",
      "threeTitle": "Çdo të diel",
      "threeText": "10:00 deri 20:00",
      "fourTitle": "Leutkirch",
      "fourText": "Kemptener Straße 54"
    },
    "menu": {
      "eyebrow": "Zemra e ofertës",
      "title": "Menyja dhe çmimet aktuale.",
      "intro": "Qebapa në tri madhësi, hamburger, sallatë, patate dhe menu hamburgeri. Oferta plotësohet me pije shqiptare dhe pije të zakonshme freskuese.",
      "openImage": "Hap fotografinë",
      "bestseller": "Më e kërkuara",
      "filling": "Pjatë e plotë",
      "sharing": "Për ta ndarë",
      "itemOne": "Qebapa",
      "itemOneText": "Në bukë ose pa bukë në pjatë. Në dispozicion me 5, 7 ose 10 copë.",
      "itemTwo": "Hamburger",
      "itemTwoText": "Hamburger veçmas ose si menu me patate dhe pije.",
      "itemThree": "Sallatë & patate",
      "itemThreeText": "Sallatë me kastravec, domate, ullinj, qepë dhe djathë të bardhë, si dhe patate.",
      "additionalEyebrow": "Zgjedhje të tjera",
      "additionalTitle": "Hamburger, shtesa & pije.",
      "additionalIntro": "Çmimet e njohura janë të shënuara. Llojet e pijeve dhe disponueshmëria mund të ndryshojnë.",
      "itemFour": "Hamburger",
      "itemFourText": "Hamburger nga foodtruck-u. Për përbërësit dhe alergjenët pyesni para porosisë.",
      "itemFive": "Sallatë & patate",
      "itemFiveText": "Sallata dhe patatet mund të porositen veçmas.",
      "itemSix": "Pije shqiptare & pije freskuese",
      "itemSixText": "Pije shqiptare dhe pije të njohura freskuese. Llojet dhe çmimet varen nga disponueshmëria.",
      "variantsOnSite": "Variantet në vend",
      "changingSelection": "Ofertë që ndryshon",
      "varietiesOnSite": "Llojet në vend",
      "pricesOnSite": "Çmimet në vend",
      "confirmationNote": "Çmimet sipas menysë aktuale. Disa imazhe të produkteve janë vizualizime. Përbërësit, alergjenët, llojet e pijeve dhe ndryshimet e fundit kontrollohen në vend ose në Instagram.",
      "priceOnSite": "Çmimi aktual në vend",
      "selectionOnSite": "Oferta aktuale në vend",
      "note": "Ushqimet e paraqitura tregojnë drejtimin tipik. Kontrollo Instagramin për ofertën aktuale të së dielës para vizitës.",
      "instagram": "Të rejat në Instagram"
    },
    "story": {
      "eyebrow": "Street food me zemër",
      "title": "Alba’s Streetfood në Leutkirch.",
      "text": "Alba’s Streetfood drejtohet nga Durim Gashi. Foodtruck-u është çdo të diel nga ora 10:00 deri në 20:00 te Goldschmitt Techmobil, Kemptener Str. 54 në Leutkirch.",
      "ownerLabel": "Pronar",
      "owner": "Pronar · Alba’s Streetfood",
      "instagram": "@albas_streetfood në Instagram",
      "textTwo": "Në qendër janë qebapat në disa porcione, hamburgerët, patatet, sallata dhe pijet."
    },
    "location": {
      "eyebrow": "Këtu na gjeni",
      "title": "Çdo të diel te Goldschmitt Techmobil.",
      "text": "Hapur nga ora 10:00 deri në 20:00 në Kemptener Str. 54. Për ndryshime të shpejta kontrolloni Instagramin.",
      "maps": "Hape në Google Maps",
      "copy": "Kopjo adresën",
      "copied": "Adresa u kopjua",
      "label": "Përmbledhje e vendndodhjes",
      "routeHint": "Hap rrugën direkt",
      "calendarShort": "Kalendari",
      "calendarHint": "Ruaj termin e përsëritur",
      "instagramHint": "Kontrollo ndryshimet e fundit"
    },
    "gallery": {
      "eyebrow": "Një vështrim pas skarës",
      "title": "Foodtruck-u dhe oferta.",
      "intro": "Foodtruck-u, ushqimet dhe detajet në një përzgjedhje të qetë dhe të fokusuar.",
      "truck": "Foodtruck & atmosferë",
      "owner": "Detaj i foodtruck-ut",
      "classic": "Klasikja",
      "plate": "E bollshme dhe e freskët",
      "grill": "Direkt nga skara",
      "platter": "Skarë & shoqërime"
    },
    "faq": {
      "eyebrow": "Përgjigje të shkurtra",
      "title": "Pyetjet kryesore para vizitës.",
      "q1": "Kur është hapur Alba’s Streetfood?",
      "a1": "Çdo të diel nga ora 10:00 deri në 20:00.",
      "q2": "Ku ndodhet foodtruck-u?",
      "a2": "Te Goldschmitt Techmobil, Kemptener Str. 54, 88299 Leutkirch im Allgäu.",
      "q3": "Çfarë ushqimi ofrohet?",
      "a3": "Qebapa me 5, 7 ose 10 copë, hamburger, sallatë, patate, menu hamburgeri, pije shqiptare dhe pije freskuese.",
      "q4": "Ku publikohen informacionet aktuale?",
      "a4": "Informacionet aktuale, fotografitë dhe ndryshimet e mundshme publikohen në Instagram."
    },
    "cta": {
      "eyebrow": "Plani yt për të dielën",
      "title": "Cevapcici, rruga dhe orari.",
      "line": "E diel, 10:00 deri 20:00 · Goldschmitt Techmobil · Kemptener Str. 54",
      "route": "Planifiko rrugën",
      "follow": "Ndiq në Instagram"
    },
    "footer": {
      "claim": "Cevapcici dhe street food në Leutkirch",
      "visit": "Vizita",
      "contact": "Kontakti",
      "website": "Faqja",
      "everySunday": "Çdo të diel",
      "legal": "Impressum",
      "privacy": "Privatësia",
      "accessibility": "Qasshmëria",
      "top": "Kthehu lart",
      "final": "E freskët nga skara në Leutkirch."
    },
    "metaPages": {
      "home": {
        "title": "Alba’s Streetfood | Cevapcici në Leutkirch",
        "description": "Cevapcici dhe street food ballkanik në Leutkirch. Çdo të diel nga 10:00 deri në 20:00 në Kemptener Str. 54."
      },
      "menu": {
        "title": "Menuja | Alba’s Streetfood Leutkirch",
        "description": "Ushqime tipike dhe informacione për ofertën e së dielës te Alba’s Streetfood në Leutkirch."
      },
      "about": {
        "title": "Rreth nesh | Alba’s Streetfood & Durim Gashi",
        "description": "Informacione për Durim Gashin, Alba’s Streetfood dhe orarin e rregullt të së dielës në Leutkirch."
      },
      "location": {
        "title": "Vendndodhja & orari | Alba’s Streetfood",
        "description": "Alba’s Streetfood çdo të diel nga 10:00 deri në 20:00 në Kemptener Str. 54, 88299 Leutkirch im Allgäu."
      },
      "gallery": {
        "title": "Galeria | Alba’s Streetfood Leutkirch",
        "description": "Fotografi të zgjedhura të foodtruck-ut dhe ushqimeve të paraqitura nga Alba’s Streetfood."
      },
      "contact": {
        "title": "Kontakt | Alba’s Streetfood Leutkirch",
        "description": "Kontakt, Instagram, rruga dhe termini në kalendar për Alba’s Streetfood në Leutkirch im Allgäu."
      }
    },
    "pages": {
      "menu": {
        "eyebrow": "Menuja",
        "title": "Menuja",
        "lead": "Gatimet, porcionet dhe çmimet e njohura në një pamje."
      },
      "about": {
        "eyebrow": "Rreth nesh",
        "title": "Rreth Alba’s Streetfood",
        "lead": "Pronari, oferta dhe të dhënat kryesore të konfirmuara."
      },
      "location": {
        "eyebrow": "Vendndodhja & orari",
        "title": "Vendndodhja &amp; orari",
        "lead": "Adresa, rruga, statusi dhe kalendari."
      },
      "gallery": {
        "eyebrow": "Galeria",
        "title": "Galeria",
        "lead": "Pamje të zgjedhura të foodtruck-ut dhe ushqimit."
      },
      "contact": {
        "eyebrow": "Kontakt",
        "title": "Kontakti",
        "lead": "Informacione aktuale, rruga dhe termini i së dielës."
      }
    },
    "home": {
      "eyebrow": "Gjithçka për vizitën tënde",
      "title": "Ushqimi, vendndodhja dhe informacionet aktuale në një vend.",
      "intro": "Shiko ofertën tipike, hap rrugën direkt dhe kontrollo Instagramin për informacionet aktuale para vizitës.",
      "menuEyebrow": "Menuja",
      "menuTitle": "Çfarë vendoset në skarë.",
      "menuText": "Gatimet, porcionet dhe çmimet e njohura aktuale.",
      "menuLink": "Te menuja",
      "aboutEyebrow": "Rreth nesh",
      "aboutTitle": "Njeriu pas skarës.",
      "aboutText": "Njihu me Durim Gashin dhe karakterin personal të Alba’s Streetfood.",
      "aboutLink": "Më shumë për Durimin",
      "locationEyebrow": "Vendndodhja",
      "locationTitle": "Çdo të diel në Leutkirch.",
      "locationText": "Adresa, statusi i hapjes, rruga dhe termini në kalendar për të dielën.",
      "locationLink": "Shiko vendndodhjen"
    },
    "values": {
      "eyebrow": "Çfarë përfaqëson Alba’s",
      "title": "Të dhënat kryesore në një vend.",
      "intro": "Pronari, oferta, vendndodhja dhe orari paraqiten qartë dhe veçmas.",
      "freshTitle": "Pronari",
      "freshText": "Alba’s Streetfood drejtohet nga Durim Gashi.",
      "simpleTitle": "Oferta",
      "simpleText": "Qebapa, hamburger, sallatë, patate dhe pije.",
      "currentTitle": "Oferta aktuale",
      "currentText": "Çmimet e njohura janë publikuar. Llojet e pijeve dhe ndryshimet konfirmohen në vend ose në Instagram.",
      "hospitalityTitle": "Vendndodhja",
      "hospitalityText": "Kemptener Str. 54 në Leutkirch im Allgäu.",
      "sundayTitle": "E diel fikse",
      "sundayText": "Çdo të diel nga ora 10:00 deri në 20:00."
    },
    "contact": {
      "eyebrow": "Kontakt & informacione aktuale",
      "title": "Gjej shpejt informacionin e duhur.",
      "intro": "Informacionet aktuale dhe mesazhet direkte aktualisht kalojnë përmes Instagramit. Rrugën dhe termin e së dielës mund t’i hapësh këtu.",
      "instagramTitle": "Instagram",
      "instagramText": "Mesazhe direkte, fotografi aktuale dhe njoftime të shpejta për ofertën e së dielës.",
      "routeTitle": "Rruga",
      "routeButton": "Hap rrugën",
      "calendarTitle": "Ruaj të dielën",
      "calendarText": "Shto termin e përsëritur direkt në kalendarin personal.",
      "calendarButton": "Shkarko kalendarin"
    },
    "visitFlow": {
      "eyebrow": "Thjesht eja",
      "title": "Ktheje urinë në plan.",
      "intro": "Tre hapa pa komplikime: shiko ofertën, hap rrugën dhe shijoje të dielën.",
      "stepOneTitle": "Shiko ofertën",
      "stepOneText": "Krijo një përshtypje për ushqimet tipike te Alba’s Streetfood.",
      "stepTwoTitle": "Kontrollo të rejat",
      "stepTwoText": "Ndryshimet e shpejta dhe oferta aktuale publikohen në Instagram.",
      "stepThreeTitle": "Hap rrugën",
      "stepThreeText": "Kemptener Str. 54 në Leutkirch. Çdo të diel nga 10:00 deri në 20:00.",
      "menuLink": "Te menuja",
      "instagramLink": "Hap Instagramin",
      "routeLink": "Planifiko rrugën"
    },
    "menuInfo": {
      "currentTitle": "Menyja aktuale",
      "currentText": "Çmimet e njohura janë shënuar. Llojet e pijeve dhe ndryshimet e fundit konfirmohen në vend ose në Instagram.",
      "allergenTitle": "Përbërësit & alergjenët",
      "allergenText": "Në rast alergjish ose intolerance, pyesni për të dhënat përfundimtare para porosisë.",
      "availabilityTitle": "Disponueshmëria",
      "availabilityText": "Llojet e pijeve dhe disa produkte mund të ndryshojnë sipas disponueshmërisë."
    },
    "mobile": {
      "menu": "Menuja",
      "route": "Rruga",
      "instagram": "Instagram",
      "aria": "Veprime të shpejta"
    },
    "lightbox": {
      "close": "Mbyll fotografinë",
      "previous": "Fotografia e mëparshme",
      "next": "Fotografia tjetër",
      "aria": "Shikuesi i fotografive"
    },
    "legalStatus": {
      "title": "Parapamje",
      "text": "Çmimet dhe orari janë përditësuar. Kontaktet, përbërësit, alergjenët dhe të dhënat ligjore po plotësohen."
    },
    "media": {
      "visualizationNotice": "Disa imazhe janë vizualizime. Përgatitja dhe paraqitja reale mund të ndryshojnë."
    },
    "serviceWorker": {
      "updated": "Një version i ri është në dispozicion. Ringarko faqen."
    },
    "menuPrices": {
      "pieces5": "5 copë",
      "pieces7": "7 copë",
      "pieces10": "10 copë",
      "burgerSingle": "Hamburger",
      "burgerMenu": "Hamburger + patate + pije",
      "salad": "Sallatë",
      "fries": "Patate",
      "serveChoice": "Në bukë ose në pjatë",
      "saladIngredients": "Kastravec · domate · ullinj · qepë · djathë i bardhë",
      "drinksSelection": "Pije shqiptare dhe freskuese · llojet dhe çmimet në vend",
      "verifiedDate": "Çmimet e verifikuara më: {{date}}"
    },
    "map": {
      "regionAria": "Hartë satelitore interaktive për vendndodhjen e Alba’s Streetfood",
      "eyebrow": "Pamje satelitore",
      "title": "Eksploro vendndodhjen në mënyrë interaktive.",
      "description": "Harta tregon vendndodhjen te Goldschmitt Techmobil. Pas ngarkimit mund ta lëvizësh, zmadhosh dhe të kalosh mes pamjes satelitore dhe rrugore.",
      "load": "Ngarko hartën satelitore",
      "route": "Hap udhëzimet",
      "consent": "Pllakat e jashtme të hartës ngarkohen vetëm pas zgjedhjes tënde. Pamja satelitore vjen nga Esri dhe harta rrugore nga OpenStreetMap.",
      "loaded": "Harta satelitore u ngarkua",
      "large": "Hap hartën e madhe",
      "unload": "Fshih hartën",
      "iframeTitle": "Hartë satelitore interaktive e Alba’s Streetfood te Goldschmitt Techmobil",
      "satellite": "Satelit",
      "roadmap": "Rrugë",
      "layerAria": "Zgjidh pamjen e hartës",
      "loading": "Harta po ngarkohet …",
      "loadingHint": "Ju lutemi prisni një moment.",
      "errorTitle": "Harta nuk mund të ngarkohej.",
      "errorText": "Kontrollo lidhjen me internetin ose hape vendndodhjen drejtpërdrejt në Google Maps.",
      "retry": "Provo përsëri",
      "readySatellite": "Harta satelitore aktive",
      "readyRoadmap": "Harta rrugore aktive",
      "satelliteFallback": "Pamjet satelitore nuk janë të disponueshme. Harta rrugore është aktive.",
      "degraded": "Të dhënat e hartës nuk janë të disponueshme",
      "degradedText": "Vendndodhja mbetet e shënuar. Hap udhëzimet për navigim.",
      "zoomIn": "Zmadho",
      "zoomOut": "Zvogëlo",
      "recenter": "Qendro vendndodhjen",
      "controlsAria": "Kontrollet e hartës",
      "panHint": "Hartë interaktive. Tërhiqe për ta lëvizur dhe përdor plus ose minus për zmadhim."
    },
    "interaction": {
      "share": "Ndaje faqen",
      "install": "Ruaje si aplikacion",
      "shareTitle": "Ndaje",
      "shareText": "Ndaje faqen, menunë dhe vendndodhjen drejtpërdrejt me të tjerët.",
      "shared": "U nda",
      "copied": "Lidhja u kopjua",
      "installed": "Aplikacioni u instalua",
      "online": "Lidhja u rikthye",
      "offline": "Je jashtë linje. Faqet e ruajtura mbeten të disponueshme."
    },
    "live": {
      "closesIn": "Hapur edhe {time}",
      "opensIn": "Hapet pas {time}",
      "daysUntil": "Shërbimi i ardhshëm pas {count} ditësh",
      "tomorrow": "Shërbimi i ardhshëm nesër",
      "todayLater": "Hapet sot pas {time}"
    },
    "visitPlanner": {
      "eyebrow": "Planifiko vizitën",
      "title": "Përgatite vizitën e së dielës në pak hapa.",
      "intro": "Zgjidh një orë të përafërt, ruaje termin dhe hap rrugën kur të duhet. Kjo nuk është rezervim.",
      "benefitsAria": "Përfitimet e planifikimit të vizitës",
      "benefitOne": "E diela e ardhshme e hapur vendoset automatikisht.",
      "benefitTwo": "Termini krijohet drejtpërdrejt në pajisjen tënde.",
      "benefitThree": "Zgjedhja ruhet në këtë pajisje.",
      "date": "Data",
      "time": "Ora",
      "guests": "Persona",
      "summaryLabel": "Planifikuar",
      "summary": "{date} në orën {time} · {guests} persona",
      "calendar": "Krijo termin në kalendar",
      "note": "Ky plan është vetëm kujtesë personale dhe jo porosi apo rezervim vendi.",
      "calendarSaved": "Termini u krijua",
      "eventTitle": "Vizitë te Alba’s Streetfood",
      "eventDescription": "Vizitë te Alba’s Streetfood. Kontrollo Instagramin para nisjes për njoftimet aktuale."
    },
    "menuFilter": {
      "aria": "Filtro menunë",
      "all": "Të gjitha",
      "cevapcici": "Qebapa",
      "burger": "Hamburger",
      "sides": "Shtesa",
      "drinks": "Pije"
    },
    "menuPlanner": {
      "eyebrow": "Llogaritësi i çmimit",
      "title": "Përgatit zgjedhjen dhe shiko çmimin.",
      "intro": "Përgatit pa detyrim atë që të intereson. Llogaritësi shërben vetëm për orientim dhe nuk dërgon porosi.",
      "total": "Shuma totale",
      "empty": "Ende asgjë e zgjedhur",
      "count": "{count} artikuj të zgjedhur",
      "copy": "Kopjo zgjedhjen",
      "share": "Ndaje zgjedhjen",
      "reset": "Rivendos",
      "note": "Nuk ka porosi online. Disponueshmërinë, përbërësit dhe alergjenët kontrolloji në vend.",
      "itemsAria": "Zgjidh produktet",
      "minus": "Hiq një {item}",
      "plus": "Shto një {item}",
      "quantity": "Sasia e {item}",
      "copied": "Zgjedhja u kopjua",
      "resetDone": "Zgjedhja u rivendos",
      "shareTitle": "Zgjedhja ime te Alba’s Streetfood",
      "summaryTitle": "Zgjedhje pa detyrim",
      "totalLine": "Shuma totale: {total}",
      "items": {
        "cevapcici-5": "5 qebapa",
        "cevapcici-7": "7 qebapa",
        "cevapcici-10": "10 qebapa",
        "hamburger": "Hamburger",
        "salat": "Sallatë",
        "pommes": "Patate",
        "hamburger-menu": "Hamburger + patate + pije"
      }
    }
  }
};
  const supported = ['de', 'en', 'sq'];
  const storage = {
    get(key) { try { return localStorage.getItem(key); } catch { return null; } },
    set(key, value) { try { localStorage.setItem(key, value); } catch { /* ignore */ } }
  };
  const getNested = (object, path) => path.split('.').reduce((value, key) => value?.[key], object);
  const localeMap = { de: 'de_DE', en: 'en_GB', sq: 'sq_AL' };

  class AlbaI18n {
    constructor() {
      const saved = storage.get('albas-language');
      const browser = (navigator.language || 'de').toLowerCase();
      this.language = supported.includes(saved) ? saved : browser.startsWith('sq') ? 'sq' : browser.startsWith('en') ? 'en' : 'de';
    }
    t(key, variables = {}) {
      let value = getNested(translations[this.language], key) ?? getNested(translations.de, key) ?? key;
      if (typeof value !== 'string') return key;
      for (const [name, replacement] of Object.entries(variables)) value = value.replaceAll(`{${name}}`, String(replacement));
      return value;
    }
    setLanguage(language) {
      if (!supported.includes(language)) return;
      this.language = language;
      storage.set('albas-language', language);
      this.apply();
      window.dispatchEvent(new CustomEvent('albas:languagechange', { detail: { language } }));
    }
    apply() {
      document.documentElement.lang = this.language;
      const page = document.body?.dataset.page || 'home';
      const metaTitle = this.t(`metaPages.${page}.title`);
      const metaDescription = this.t(`metaPages.${page}.description`);
      if (!metaTitle.startsWith('metaPages.')) document.title = metaTitle;
      if (!metaDescription.startsWith('metaPages.')) {
        document.querySelector('meta[name="description"]')?.setAttribute('content', metaDescription);
        document.querySelector('meta[property="og:description"]')?.setAttribute('content', metaDescription);
        document.querySelector('meta[name="twitter:description"]')?.setAttribute('content', metaDescription);
      }
      if (!metaTitle.startsWith('metaPages.')) {
        document.querySelector('meta[property="og:title"]')?.setAttribute('content', metaTitle);
        document.querySelector('meta[name="twitter:title"]')?.setAttribute('content', metaTitle);
      }
      document.querySelector('meta[property="og:locale"]')?.setAttribute('content', localeMap[this.language] || 'de_DE');
      document.querySelectorAll('[data-i18n]').forEach((element) => { element.textContent = this.t(element.dataset.i18n); });
      document.querySelectorAll('[data-i18n-html]').forEach((element) => { element.innerHTML = this.t(element.dataset.i18nHtml); });
      document.querySelectorAll('[data-i18n-attr]').forEach((element) => {
        element.dataset.i18nAttr.split(';').forEach((pair) => {
          const [attribute, key] = pair.split(':').map((part) => part.trim());
          if (attribute && key) element.setAttribute(attribute, this.t(key));
        });
      });
      document.querySelectorAll('[data-lang]').forEach((button) => {
        const active = button.dataset.lang === this.language;
        button.classList.toggle('active', active);
        button.setAttribute('aria-pressed', String(active));
      });
    }
  }
  window.AlbasI18n = new AlbaI18n();
})();
