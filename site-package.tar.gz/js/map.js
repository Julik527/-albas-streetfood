(() => {
  'use strict';

  const DEFAULTS = {
    latitude: 47.8225,
    longitude: 10.03821,
    zoom: 18,
    layer: 'satellite'
  };

  const LEAFLET_SCRIPTS = [
    'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js',
    'https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/leaflet.js'
  ];
  const ASSET_TIMEOUT = 3500;
  const TILE_TIMEOUT = 8000;
  const i18n = window.AlbasI18n;
  const instances = [];

  const t = (key, fallback, vars) => {
    const value = i18n?.t?.(key, vars);
    return value && value !== key ? value : fallback;
  };

  const withTimeout = (promise, milliseconds, label) => new Promise((resolve, reject) => {
    const timer = window.setTimeout(() => reject(new Error(`${label} timed out`)), milliseconds);
    promise.then((value) => {
      window.clearTimeout(timer);
      resolve(value);
    }, (error) => {
      window.clearTimeout(timer);
      reject(error);
    });
  });

  const loadStylesheet = (href) => withTimeout(new Promise((resolve, reject) => {
    const absolute = new URL(href, document.baseURI).href;
    const existing = [...document.querySelectorAll('link[rel="stylesheet"]')]
      .find((link) => link.href === absolute);

    if (existing?.sheet) {
      resolve(existing);
      return;
    }

    const link = existing || document.createElement('link');
    const cleanup = () => {
      link.removeEventListener('load', handleLoad);
      link.removeEventListener('error', handleError);
    };
    const handleLoad = () => { cleanup(); resolve(link); };
    const handleError = () => { cleanup(); if (!existing) link.remove(); reject(new Error(`Stylesheet failed: ${href}`)); };

    link.addEventListener('load', handleLoad, { once: true });
    link.addEventListener('error', handleError, { once: true });
    if (!existing) {
      link.rel = 'stylesheet';
      link.href = href;
      link.crossOrigin = 'anonymous';
      document.head.append(link);
    }
  }), ASSET_TIMEOUT, `Leaflet CSS ${href}`);

  const loadScript = (src) => withTimeout(new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = src;
    script.async = true;
    script.crossOrigin = 'anonymous';
    script.addEventListener('load', () => resolve(script), { once: true });
    script.addEventListener('error', () => {
      script.remove();
      reject(new Error(`Script failed: ${src}`));
    }, { once: true });
    document.head.append(script);
  }), ASSET_TIMEOUT, `Leaflet JS ${src}`);

  const loadFirstAvailable = async (sources, loader) => {
    let lastError;
    for (const source of sources) {
      try {
        return await loader(source);
      } catch (error) {
        lastError = error;
      }
    }
    throw lastError || new Error('No external source available');
  };

  const ensureLeaflet = async () => {
    if (window.L?.map) return window.L;
    await loadFirstAvailable(LEAFLET_SCRIPTS, loadScript);
    if (!window.L?.map) throw new Error('Leaflet could not be initialized');
    return window.L;
  };

  const loadConfig = async () => {
    try {
      const response = await fetch('assets/data/business.json', { cache: 'no-store' });
      if (!response.ok) throw new Error('configuration unavailable');
      const data = await response.json();
      return {
        latitude: Number(data?.map?.latitude) || DEFAULTS.latitude,
        longitude: Number(data?.map?.longitude) || DEFAULTS.longitude,
        zoom: Math.min(20, Math.max(14, Number(data?.map?.zoom) || DEFAULTS.zoom)),
        layer: ['map', 'street'].includes(data?.map?.layer) ? 'street' : 'satellite'
      };
    } catch {
      return { ...DEFAULTS };
    }
  };

  class LiveMap {
    constructor(container, config, L) {
      this.container = container;
      this.config = config;
      this.L = L;
      this.canvas = container.querySelector('[data-map-canvas]');
      this.status = container.querySelector('[data-map-status]');
      this.attribution = container.querySelector('[data-map-attribution]');
      this.layerButtons = [...container.querySelectorAll('[data-map-layer]')];
      this.recenterButton = container.querySelector('[data-map-recenter]');
      this.largeLink = container.querySelector('[data-map-large]');
      this.routeLink = container.querySelector('[data-map-route]');
      this.currentLayerName = config.layer;
      this.statusState = 'loading';
      this.fallbackActive = false;
      this.tileStats = {
        satellite: { loaded: 0, errors: 0 },
        street: { loaded: 0, errors: 0 }
      };
      this.layerTimeout = null;
      this.resizeObserver = null;
      this.init();
    }

    init() {
      const { latitude, longitude, zoom } = this.config;
      const L = this.L;

      this.container.classList.add('is-map-initializing');
      this.setStatus('loading');

      this.map = L.map(this.canvas, {
        center: [latitude, longitude],
        zoom,
        zoomControl: true,
        attributionControl: false,
        scrollWheelZoom: false,
        doubleClickZoom: true,
        touchZoom: true,
        dragging: true,
        boxZoom: false,
        keyboard: true,
        zoomAnimation: !window.matchMedia('(prefers-reduced-motion: reduce)').matches,
        fadeAnimation: true,
        markerZoomAnimation: true,
        bounceAtZoomLimits: false,
        preferCanvas: true
      });

      this.layers = {
        satellite: L.tileLayer(
          'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
          {
            minZoom: 3,
            maxZoom: 20,
            maxNativeZoom: 19,
            tileSize: 256,
            detectRetina: false,
            updateWhenIdle: true,
            updateWhenZooming: false,
            keepBuffer: 1,
            className: 'satellite-tiles'
          }
        ),
        street: L.tileLayer(
          'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
          {
            minZoom: 3,
            maxZoom: 20,
            maxNativeZoom: 19,
            tileSize: 256,
            detectRetina: false,
            updateWhenIdle: true,
            updateWhenZooming: false,
            keepBuffer: 1,
            className: 'street-tiles'
          }
        )
      };

      const markerIcon = L.divIcon({
        className: 'albas-map-marker-shell',
        html: '<span class="albas-map-marker" aria-hidden="true"><i></i></span>',
        iconSize: [42, 52],
        iconAnchor: [21, 50]
      });
      this.marker = L.marker([latitude, longitude], {
        icon: markerIcon,
        keyboard: false,
        interactive: false,
        riseOnHover: false
      }).addTo(this.map);

      this.bindLayerEvents();
      this.bindControls();
      this.activateLayer(this.currentLayerName);
      this.updateControls();
      this.updateLinks();
      this.refreshLabels();

      this.map.whenReady(() => {
        this.container.classList.remove('is-map-initializing');
        this.invalidateSize();
      });
      requestAnimationFrame(() => this.invalidateSize());
      window.setTimeout(() => this.invalidateSize(), 240);
      window.setTimeout(() => this.invalidateSize(), 900);

      if ('ResizeObserver' in window) {
        this.resizeObserver = new ResizeObserver(() => this.invalidateSize());
        this.resizeObserver.observe(this.canvas);
      }
    }

    invalidateSize() {
      if (!this.map) return;
      this.map.invalidateSize({ animate: false, pan: false });
    }

    bindLayerEvents() {
      Object.entries(this.layers).forEach(([name, layer]) => {
        layer.on('loading', () => {
          if (this.currentLayerName === name) this.setStatus('loading');
        });
        layer.on('tileload', () => {
          this.tileStats[name].loaded += 1;
          if (this.currentLayerName !== name) return;
          this.clearLayerTimeout();
          this.container.classList.add('is-map-ready');
          this.setStatus(name === 'satellite' ? 'satellite' : (this.fallbackActive ? 'satelliteFallback' : 'street'));
        });
        layer.on('tileerror', () => {
          this.tileStats[name].errors += 1;
          if (this.currentLayerName !== name || this.tileStats[name].loaded > 0) return;
          if (name === 'satellite' && this.tileStats[name].errors >= 5) this.fallbackToStreet();
          if (name === 'street' && this.tileStats[name].errors >= 5) this.setStatus('streetError');
        });
        layer.on('load', () => {
          if (this.currentLayerName !== name) return;
          this.clearLayerTimeout();
          this.container.classList.add('is-map-ready');
          this.setStatus(name === 'satellite' ? 'satellite' : (this.fallbackActive ? 'satelliteFallback' : 'street'));
        });
      });
    }

    bindControls() {
      this.layerButtons.forEach((button) => {
        button.addEventListener('click', () => this.switchLayer(button.dataset.mapLayer));
      });
      this.recenterButton?.addEventListener('click', () => this.recenter());
      this.map.on('focus', () => this.canvas.classList.add('is-focused'));
      this.map.on('blur', () => this.canvas.classList.remove('is-focused'));
    }

    activateLayer(name) {
      this.clearLayerTimeout();
      this.tileStats[name] = { loaded: 0, errors: 0 };
      this.setStatus('loading');
      this.layers[name].addTo(this.map);
      this.layerTimeout = window.setTimeout(() => {
        if (this.currentLayerName !== name || this.tileStats[name].loaded > 0) return;
        if (name === 'satellite') this.fallbackToStreet();
        else this.setStatus('streetError');
      }, TILE_TIMEOUT);
    }

    clearLayerTimeout() {
      if (this.layerTimeout) window.clearTimeout(this.layerTimeout);
      this.layerTimeout = null;
    }

    switchLayer(nextLayer, { fallback = false } = {}) {
      if (!this.layers[nextLayer]) return;
      if (nextLayer === this.currentLayerName) {
        this.updateControls();
        return;
      }
      this.clearLayerTimeout();
      this.map.removeLayer(this.layers[this.currentLayerName]);
      this.currentLayerName = nextLayer;
      this.fallbackActive = fallback;
      this.container.classList.remove('is-map-ready');
      this.activateLayer(nextLayer);
      this.updateControls();
      this.updateLinks();
      this.refreshAttribution();
    }

    fallbackToStreet() {
      if (this.currentLayerName !== 'satellite') return;
      this.switchLayer('street', { fallback: true });
    }

    recenter() {
      this.map.flyTo([this.config.latitude, this.config.longitude], this.config.zoom, {
        animate: !window.matchMedia('(prefers-reduced-motion: reduce)').matches,
        duration: 0.55
      });
    }

    updateControls() {
      this.layerButtons.forEach((button) => {
        const active = button.dataset.mapLayer === this.currentLayerName;
        button.classList.toggle('active', active);
        button.setAttribute('aria-pressed', String(active));
      });
    }

    updateLinks() {
      const { latitude, longitude, zoom } = this.config;
      const satelliteCode = this.currentLayerName === 'satellite' ? '3' : '1';
      if (this.largeLink) {
        this.largeLink.href = `https://www.google.com/maps/@${latitude},${longitude},${zoom}z/data=!3m1!1e${satelliteCode}`;
      }
      if (this.routeLink) {
        this.routeLink.href = `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(`${latitude},${longitude}`)}`;
      }
    }

    statusMessage(state) {
      const messages = {
        loading: t('map.loading', 'Karte wird geladen …'),
        satellite: t('map.readySatellite', 'Satellitenansicht aktiv'),
        street: t('map.readyRoadmap', 'Straßenkarte aktiv'),
        satelliteFallback: t('map.satelliteFallback', 'Satellitenbilder nicht erreichbar. Straßenkarte aktiv.'),
        satelliteError: t('map.degraded', 'Satellitenbilder konnten nicht geladen werden.'),
        streetError: t('map.degraded', 'Kartendaten konnten nicht vollständig geladen werden.')
      };
      return messages[state] || messages.loading;
    }

    setStatus(state) {
      this.statusState = state;
      if (!this.status) return;
      this.status.textContent = this.statusMessage(state);
      this.status.dataset.state = state;
    }

    refreshAttribution() {
      if (!this.attribution) return;
      this.attribution.innerHTML = this.currentLayerName === 'satellite'
        ? 'Bilddaten © Esri, Vantor, Earthstar Geographics und GIS User Community'
        : 'Kartendaten © <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap-Mitwirkende</a>';
    }

    refreshLabels() {
      this.container.setAttribute('aria-label', t('map.regionAria', 'Interaktive Satellitenkarte zum Standort von Alba’s Streetfood'));
      this.canvas.setAttribute('aria-label', t('map.panHint', 'Interaktive Karte. Mit Ziehen verschieben und mit Plus oder Minus zoomen.'));
      this.layerButtons.forEach((button) => {
        button.textContent = button.dataset.mapLayer === 'satellite'
          ? t('map.satellite', 'Satellit')
          : t('map.roadmap', 'Straße');
      });
      if (this.recenterButton) this.recenterButton.textContent = t('map.recenter', 'Standort zentrieren');
      if (this.largeLink) this.largeLink.textContent = t('map.large', 'Große Karte öffnen');
      if (this.routeLink) this.routeLink.textContent = t('map.route', 'Route direkt öffnen');
      this.refreshAttribution();
      this.setStatus(this.statusState);
    }
  }

  const init = async () => {
    const containers = [...document.querySelectorAll('[data-live-map]')];
    if (!containers.length) return;

    containers.forEach((container) => container.classList.add('is-map-initializing'));
    try {
      const [L, config] = await Promise.all([ensureLeaflet(), loadConfig()]);
      containers.forEach((container) => instances.push(new LiveMap(container, config, L)));
      window.addEventListener('albas:languagechange', () => instances.forEach((instance) => instance.refreshLabels()));
      document.addEventListener('visibilitychange', () => {
        if (!document.hidden) instances.forEach((instance) => instance.invalidateSize());
      });
    } catch (error) {
      containers.forEach((container) => {
        container.classList.remove('is-map-initializing');
        container.classList.add('map-library-error');
        const status = container.querySelector('[data-map-status]');
        if (status) {
          status.dataset.state = 'streetError';
          status.textContent = t('map.degraded', 'Karte konnte nicht geladen werden. Route direkt öffnen.');
        }
      });
      console.error('[Alba’s map]', error);
    }
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init, { once: true });
  } else {
    init();
  }
})();
