# Fotoaustausch für eine vollständig authentische Veröffentlichung

Die Website ist so aufgebaut, dass echte Fotos ohne Layoutumbau eingesetzt werden können. Für den endgültigen Unternehmensauftritt sollten die aktuellen Konzeptmotive durch reale Aufnahmen ersetzt werden.

## Benötigte Aufnahmen

1. **Foodtruck im Querformat**
   - Außenansicht am tatsächlichen Standort
   - Logo und Verkaufsfenster gut sichtbar
   - keine fremden Personen ohne Einwilligung
   - Ziel: mindestens 2400 × 1600 Pixel

2. **Cevapcici im Fladenbrot**
   - tatsächliche Verkaufsportion
   - natürliches Seitenlicht
   - neutraler Hintergrund
   - Ziel: mindestens 1800 × 1350 Pixel

3. **Cevapcici-Teller**
   - komplette Portion mit realen Beilagen
   - Aufnahme leicht von oben
   - Ziel: mindestens 1800 × 1350 Pixel

4. **Grill und Zubereitung**
   - Nahaufnahme des realen Grills
   - Hände nur mit Einwilligung und hygienisch korrekt dargestellt
   - Ziel: mindestens 1800 × 1350 Pixel

5. **Abend- oder Sonntagssituation**
   - Foodtruck in der tatsächlichen Umgebung
   - natürliche Besucheratmosphäre
   - Personen nur mit dokumentierter Einwilligung
   - Ziel: mindestens 2400 × 1600 Pixel

6. **Optional: Betreiberporträt**
   - Durim Gashi am realen Foodtruck
   - ruhige, natürliche Haltung
   - kein künstlicher Studiolook
   - Ziel: mindestens 1600 × 2000 Pixel

## Aufnahmehinweise

- Smartphone-Hauptkamera oder echte Kamera verwenden, keinen Digitalzoom.
- Linse vorher reinigen.
- Tageslicht oder vorhandenes warmes Licht nutzen.
- Keine Beauty-Filter, KI-Filter oder künstlichen Hintergründe.
- Portionsgrößen und Zutaten müssen dem tatsächlichen Verkauf entsprechen.
- Mehrere horizontale und vertikale Varianten aufnehmen.
- Originaldateien unverändert sichern.

## Austausch

Die Website verwendet responsive Varianten mit 1200, 800 und 480 Pixel Breite. Nach Auswahl der Originalfotos werden daraus optimierte WebP-Dateien erzeugt. Die Dateizuordnung und Rechtefreigabe müssen anschließend in `CREDITS.md`, `RELEASE_CHECKLIST.md` und `assets/data/business.json` dokumentiert werden.
