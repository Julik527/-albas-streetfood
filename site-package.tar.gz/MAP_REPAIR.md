# Interaktive Karte – finale Architektur

Die früheren iframe-, Zwei-Klick- und Eigenbau-Karten wurden vollständig entfernt.

## Aktuelle Umsetzung

- Leaflet 1.9.4 als bewährte Kartenengine
- lokale Leaflet-Kernstyles, damit die Kartendarstellung nicht von einem externen Stylesheet abhängt
- JavaScript-Lader mit Zeitüberschreitung sowie unpkg- und jsDelivr-Fallback
- Satellitenkacheln von Esri World Imagery
- Straßenkartenkacheln von OpenStreetMap
- Satellitenansicht wird unmittelbar angefordert
- automatische Straßenkarten-Rückfallebene, wenn Satellitenkacheln nicht erreichbar sind
- exakter Standortmarker, Zoom, Verschieben, Zentrieren und Ebenenwechsel
- keine Titel- oder Beschreibungstexte auf der Kartenfläche
- Status, Quellen und Routenaktionen ausschließlich unterhalb der Karte

Die Karte ist auf `index.html` und `standort.html` eingebunden.
