# Technische Abnahme

## Struktur

- 11 HTML-Seiten
- zentrales Stylesheet
- zentrale JavaScript-Dateien für Übersetzung, Interaktion und Karte
- zentrale Geschäftsdaten in `assets/data/business.json`
- Service Worker, Manifest, Offline-Seite und Netlify-Header

## Karte

- Satellitenansicht als Startansicht
- Straßenkarten-Umschaltung
- lokale Leaflet-Kernstyles
- JavaScript-CDN-Fallback mit Zeitüberschreitung
- keine iframe- oder Zwei-Klick-Logik
- keine Textüberlagerung auf der Kartenfläche

## Bedienung

- responsive Navigation
- Tastaturfokus und Fokusbegrenzung im Mobilmenü
- manuelles Karussell
- zugänglicher Bilderdialog
- Besuchsplaner und Preisrechner
- reduzierte Bewegung wird berücksichtigt

## Veröffentlichung

Die technische Struktur ist fertig. Die öffentliche Freigabe bleibt bis zur Bestätigung der Betreiber-, Medien- und Rechtsangaben gesperrt.
