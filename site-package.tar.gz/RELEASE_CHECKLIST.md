# Finale Abnahme vor Veröffentlichung

## Inhalt

- [ ] Preise und Speisekarte stimmen mit dem realen Angebot überein.
- [ ] Zutaten, Allergene und Zusatzstoffe sind vollständig geprüft.
- [ ] Öffnungszeiten und Ausnahmeregelungen sind bestätigt.
- [ ] Telefonnummer, E-Mail und weitere Kontaktwege funktionieren.
- [ ] Adresse und Google-Maps-Ziel wurden vor Ort geprüft.
- [ ] Alle Texte wurden vom Inhaber gelesen und freigegeben.

## Bilder

- [ ] Gezeigte Speisen entsprechen dem tatsächlichen Angebot.
- [ ] Foodtruck und Branding entsprechen dem realen Zustand.
- [ ] Für jedes Bild und Logo liegen ausreichende Nutzungsrechte vor.
- [ ] Künstliche Konzeptbilder wurden durch echte Betriebsaufnahmen ersetzt oder eindeutig freigegeben.
- [ ] Keine Person wird ohne Einwilligung veröffentlicht.

## Recht und Datenschutz

- [ ] Impressum ist vollständig.
- [ ] Datenschutzerklärung entspricht dem tatsächlichen Hosting und allen eingesetzten Diensten.
- [ ] Hosting-Anbieter und verantwortliche Kontaktadresse sind eingetragen.
- [ ] Rechtliche Abschlussprüfung wurde dokumentiert.

## Technik

- [ ] Bestätigte Daten wurden mit `npm run sync:business` in die HTML-Dateien übernommen.
- [ ] Endgültige Domain wurde mit `npm run configure:domain -- https://domain/` eingetragen.
- [ ] `npm run audit` besteht ohne Fehler.
- [ ] `npm run release:check` besteht ohne Fehler.
- [ ] Test auf iPhone Safari, Android Chrome, Firefox und Desktop Chrome bestanden.
- [ ] Lighthouse und ein Barrierefreiheitstest wurden auf der Live-Domain durchgeführt.
- [ ] Social-Media-Vorschau und Google-Suchergebnis wurden kontrolliert.
