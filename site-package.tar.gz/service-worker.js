const CACHE_NAME='albas-streetfood-github-pages-v15';
const CORE=[
  './','./index.html','./speisekarte.html','./ueber-uns.html','./standort.html','./galerie.html','./kontakt.html',
  './offline.html','./barrierefreiheit.html','./404.html','./css/style.css?v=20260726-final2','./vendor/leaflet/leaflet-core.css?v=20260726-final2','./js/i18n.js?v=20260726-final2','./js/map.js?v=20260726-final2','./js/main.js?v=20260726-final2','./site.webmanifest',
  './assets/images/logo-albas-streetfood.webp','./assets/images/foodtruck-brand-detail-800.webp','./assets/images/cevapcici-preisteller-800.webp','./assets/images/hamburger-menu-800.webp',
  './assets/images/home-grill-detail-800.webp','./assets/images/foodtruck-night-detail-800.webp','./assets/icons/favicon-32.png','./assets/icons/icon-192.png'
];
self.addEventListener('install',(event)=>{event.waitUntil(caches.open(CACHE_NAME).then((cache)=>cache.addAll(CORE)));self.skipWaiting();});
self.addEventListener('activate',(event)=>{event.waitUntil(caches.keys().then((keys)=>Promise.all(keys.filter((key)=>key!==CACHE_NAME).map((key)=>caches.delete(key)))));self.clients.claim();});
self.addEventListener('fetch',(event)=>{
  const request=event.request;
  if(request.method!=='GET') return;
  const url=new URL(request.url);
  if(url.origin!==self.location.origin) return;

  if(url.pathname.endsWith('/assets/data/business.json')){
    event.respondWith((async()=>{
      try{
        const response=await fetch(request,{cache:'no-store'});
        if(response.ok){const cache=await caches.open(CACHE_NAME);cache.put(request,response.clone());}
        return response;
      }catch{
        return (await caches.match(request)) || Response.error();
      }
    })());
    return;
  }

  if(request.destination==='video' || request.headers.has('range')){
    event.respondWith(fetch(request));
    return;
  }

  if(request.mode==='navigate'){
    event.respondWith((async()=>{
      try{
        const response=await fetch(request);
        if(response.ok){const cache=await caches.open(CACHE_NAME);cache.put(request,response.clone());}
        return response;
      }catch{
        return (await caches.match(request)) || (await caches.match('./offline.html'));
      }
    })());
    return;
  }

  event.respondWith((async()=>{
    const cached=await caches.match(request);
    const network=fetch(request).then(async(response)=>{
      if(response.ok){const cache=await caches.open(CACHE_NAME);cache.put(request,response.clone());}
      return response;
    }).catch(()=>null);
    return cached || (await network) || Response.error();
  })());
});
