# Herkunft und Rechte

## Marke

- Website: Alba’s Streetfood
- Betreiber: Durim Gashi
- Logo: vom Auftraggeber bereitgestellt

## Bilder

Ein Teil der enthaltenen Food- und Atmosphärenbilder sind Visualisierungen auf Grundlage der bereitgestellten Informationen und Referenzbilder. Sie dürfen nicht als verbindliche Darstellung von Portionen, Zutaten, Personen oder konkreten Verkaufssituationen verstanden werden. Vor der endgültigen Unternehmensveröffentlichung sollen bestätigte Originalfotos eingesetzt und die Bildrechte dokumentiert werden.

Die Freigabe wird in `assets/data/business.json` dokumentiert:

```json
"media": {
  "realBusinessPhotosConfirmed": true,
  "imageRightsConfirmed": true
}
```

## Karte

- Kartenbibliothek: Leaflet 1.9.4, BSD-2-Clause
- Satellitenbilder: Esri World Imagery, mit Quellenangabe direkt unter der Karte
- Straßenkarte: OpenStreetMap-Mitwirkende, ODbL
- Leaflet-Kernstyles werden lokal ausgeliefert. Das Leaflet-JavaScript wird mit Zeitüberschreitung und einem zweiten CDN-Fallback geladen.

## Technik

Navigation, Karussell, Bilderdialog, Übersetzungen, Öffnungsstatus, Besuchsplaner, Preisrechner und Geschäftsdaten-Anbindung sind im Projekt selbst umgesetzt. Es werden keine Analyse- oder Werbetracker verwendet.
