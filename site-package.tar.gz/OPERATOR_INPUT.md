# Noch benötigte Angaben des Inhabers

Die technische Website ist vorbereitet. Für eine belastbare Veröffentlichung müssen ausschließlich echte und bestätigte Betriebsangaben eingesetzt werden.


## Bereits eingetragen und bestätigt

- Standort: Goldschmitt Techmobil, Kemptener Str. 54, 88299 Leutkirch im Allgäu
- Öffnungszeit laut aktuellem Instagram-Hinweis: Sonntag, 10:00 bis 20:00 Uhr
- 5 Stück Cevapcici: 7,00 €
- 7 Stück Cevapcici: 8,50 €
- 10 Stück Cevapcici: 10,00 €
- Hamburger: 7,00 €
- Salat: 4,50 €
- Pommes: 4,00 €
- Hamburger + Pommes + Getränk: 12,00 €
- Salatzutaten laut Karte: Gurken, Tomaten, Oliven, Zwiebeln und Weißkäse
- Cevapcici können im Brot oder auf dem Teller bestellt werden

## Pflichtangaben

- geschäftliche E-Mail-Adresse
- Bestätigung der ladungsfähigen Anschrift
- Zutaten, Allergene und gegebenenfalls Zusatzstoffe
- akzeptierte Zahlungsarten
- Regelung für Feiertage, Urlaub und schlechtes Wetter
- endgültiger Hosting-Anbieter und Domain
- Nutzungsrechte für Logo und Bilder
- Bestätigung, welche Bilder den realen Betrieb und reale Speisen zeigen
- finale Prüfung von Impressum und Datenschutz

## Sinnvolle Ergänzungen

- Telefonnummer oder WhatsApp Business
- Möglichkeit und Ablauf von Vorbestellungen
- Parkmöglichkeiten
- Sitzmöglichkeiten
- barrierefreier Zugang
- Bedeutung des Namens Alba’s
- kurze, echte Entstehungsgeschichte
- Link zum Google-Unternehmensprofil

## Eintragen

Die Daten werden in `assets/data/business.json` gepflegt. Erst nach vollständiger Bestätigung:

```json
"publishReady": true
```

Danach ausführen:

```bash
npm run release:check
```


## Ergänzung: neue Speisen und Getränke bestätigen

Bitte zusätzlich beim Inhaber abfragen:

- Welche Zutaten und Allergene enthält der Hamburger?
- Welche albanischen Getränke und Softdrinks sind aktuell erhältlich?
- Welche Beilagen gehören jeweils dazu?
- Welche weiteren Grillgerichte werden angeboten?
- Welche albanischen Getränke gibt es genau?
- Welche normalen Softdrinks gibt es genau?
- Welche Flaschengrößen oder Dosen gibt es?
