# Hosting mit GitHub Pages

## Vor dem ersten öffentlichen Deployment

1. Echte Betreiberangaben in `assets/data/business.json` eintragen.
2. Bilder und Nutzungsrechte bestätigen.
3. Impressum und Datenschutz final prüfen.
4. Endgültige Domain eintragen:

```bash
npm run configure:domain -- https://www.deine-domain.de/
```

5. Bestätigte Geschäftsdaten statisch übernehmen:

```bash
npm run sync:business
```

6. Vollständige Freigabeprüfung ausführen:

```bash
npm run release:check
```

## GitHub Pages aktivieren

1. Repository `albas-streetfood` erstellen.
2. Dateien auf den Branch `main` hochladen.
3. In GitHub `Settings → Pages` öffnen.
4. Als Quelle `GitHub Actions` auswählen.
5. Unter `Actions` den Workflow `Deploy production website to GitHub Pages` prüfen.

Der Workflow veröffentlicht nur, wenn Synchronisierung, Qualitätsaudit und Release-Check erfolgreich sind.

## Nur zum Testen

Für eine nicht endgültige Vorschau kann der Ordner auch per Netlify Drop oder Cloudflare Pages Direct Upload bereitgestellt werden. Der Link ist öffentlich. Solange `publishReady` auf `false` steht, zeigt die Website deshalb einen Vorschauhinweis.
