import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const read = (file) => fs.readFileSync(path.join(root, file), 'utf8');
const errors = [];
const ok = (condition, message) => { if (!condition) errors.push(message); };

const business = JSON.parse(read('assets/data/business.json'));
const map = business.map || {};
ok(Number.isFinite(Number(map.latitude)), 'business.json: latitude fehlt oder ist ungültig');
ok(Number.isFinite(Number(map.longitude)), 'business.json: longitude fehlt oder ist ungültig');
ok(Number(map.zoom) >= 14 && Number(map.zoom) <= 20, 'business.json: Zoomstufe außerhalb 14–20');
ok(map.layer === 'satellite' || map.layer === 'street' || map.layer === 'map', 'business.json: Kartenebene muss satellite oder street sein');
ok(map.consentMode === 'immediate', 'business.json: Karte muss sofort laden');

const mapJs = read('js/map.js');
ok(mapJs.includes('L.map('), 'map.js: Leaflet-Initialisierung fehlt');
ok(mapJs.includes('server.arcgisonline.com/ArcGIS/rest/services/World_Imagery'), 'map.js: Esri-Satellitenkacheln fehlen');
ok(mapJs.includes('tile.openstreetmap.org'), 'map.js: OpenStreetMap-Straßenkacheln fehlen');
ok(mapJs.includes('switchLayer'), 'map.js: Ebenenumschaltung fehlt');
ok(mapJs.includes('invalidateSize'), 'map.js: responsive Größenkorrektur fehlt');
ok(mapJs.includes('detectRetina: false'), 'map.js: mobile Kacheloptimierung fehlt');
ok(!mapJs.includes('CONSENT_KEY'), 'map.js: alte Zwei-Klick-Logik ist noch vorhanden');
ok(!mapJs.includes('<iframe'), 'map.js: iframe darf nicht verwendet werden');

for (const file of ['index.html', 'standort.html']) {
  const html = read(file);
  ok(html.includes('data-live-map'), `${file}: Live-Kartencontainer fehlt`);
  ok(html.includes('data-map-canvas'), `${file}: Kartenfläche fehlt`);
  ok(html.includes('data-map-layer="satellite"') && html.includes('data-map-layer="street"'), `${file}: Ebenenumschaltung fehlt`);
  ok(!html.includes('leaflet@1.9.4/dist/leaflet.js'), `${file}: blockierendes externes Leaflet-Script darf nicht im HTML stehen`);
  ok(html.includes('js/map.js'), `${file}: Karten-Loader fehlt`);
  ok(html.includes('vendor/leaflet/leaflet-core.css'), `${file}: lokale Leaflet-Styles fehlen`);
  ok(!html.includes('data-map-load'), `${file}: veraltete Laden-Schaltfläche darf nicht vorhanden sein`);
  ok(!html.includes('data-map-unload'), `${file}: veraltete Ausblenden-Schaltfläche darf nicht vorhanden sein`);
  ok(!html.includes('data-map-placeholder'), `${file}: veralteter Platzhalter darf nicht vorhanden sein`);
}

const css = read('css/style.css');
for (const selector of ['.live-map-stage', '.live-map-canvas', '.live-map-panel', '.albas-map-marker', '.leaflet-control-zoom']) {
  ok(css.includes(selector), `style.css: Kartenregel ${selector} fehlt`);
}

const sw = read('service-worker.js');
ok(sw.includes('vendor/leaflet/leaflet-core.css'), 'service-worker.js: lokale Leaflet-Styles fehlen im Offline-Kern');
ok(sw.includes('github-pages-v15'), 'service-worker.js: GitHub-Pages-Cache-Version fehlt');
ok(sw.includes("'./js/map.js?v=20260726-final2'"), 'service-worker.js: aktuelle map.js fehlt im Offline-Kern');

if (errors.length) {
  console.error('\nALBA’S STREETFOOD – KARTENPRÜFUNG\n');
  errors.forEach((error) => console.error(`✗ ${error}`));
  process.exit(1);
}

console.log('\nALBA’S STREETFOOD – KARTENPRÜFUNG\n');
console.log('✓ Satellitenkarte lädt unmittelbar.');
console.log('✓ Umschaltung Satellit / Straße vorhanden.');
console.log('✓ Leaflet ersetzt die fehleranfällige Eigenentwicklung.');
console.log('✓ Mobile Kachel- und Größenoptimierung aktiv.');
console.log('✓ Keine iframe- oder Zwei-Klick-Logik mehr.');
console.log('✓ Startseite und Standortseite korrekt verbunden.');
