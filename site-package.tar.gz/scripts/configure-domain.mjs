#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const raw = process.argv[2];
if (!raw) {
  console.error('Aufruf: npm run configure:domain -- https://www.beispiel-domain.de/');
  process.exit(1);
}

let base;
try {
  const url = new URL(raw);
  if (url.protocol !== 'https:') throw new Error('HTTPS ist erforderlich.');
  url.hash = '';
  url.search = '';
  base = url.href.endsWith('/') ? url.href : `${url.href}/`;
} catch (error) {
  console.error(`Ungültige Produktionsadresse: ${error.message}`);
  process.exit(1);
}

const indexPath = path.join(root, 'index.html');
const index = fs.readFileSync(indexPath, 'utf8');
const current = index.match(/<link[^>]+rel=["']canonical["'][^>]+href=["']([^"']+)["']/i)?.[1];
if (!current) {
  console.error('Canonical-URL in index.html nicht gefunden.');
  process.exit(1);
}
const oldBase = current.endsWith('/') ? current : current.replace(/[^/]*$/, '');

const replaceIn = (file, transform) => {
  const full = path.join(root, file);
  const source = fs.readFileSync(full, 'utf8');
  fs.writeFileSync(full, transform(source));
};

for (const file of fs.readdirSync(root).filter((name) => name.endsWith('.html'))) {
  replaceIn(file, (source) => source.split(oldBase).join(base));
}
replaceIn('sitemap.xml', (source) => source.split(oldBase).join(base));
replaceIn('robots.txt', (source) => /^Sitemap:/m.test(source)
  ? source.replace(/^Sitemap:.*$/m, `Sitemap: ${base}sitemap.xml`)
  : `${source.trimEnd()}\n\nSitemap: ${base}sitemap.xml\n`);

const businessPath = path.join(root, 'assets/data/business.json');
const business = JSON.parse(fs.readFileSync(businessPath, 'utf8'));
business.site ??= {};
business.site.productionUrl = base;
fs.writeFileSync(businessPath, `${JSON.stringify(business, null, 2)}\n`);

console.log(`Produktionsadresse gesetzt: ${base}`);
console.log('Canonical-URLs, Social-Media-URLs, JSON-LD, Sitemap, robots.txt und business.json wurden aktualisiert.');
