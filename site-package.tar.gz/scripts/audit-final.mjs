#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const errors = [];
const need = (condition, message) => { if (!condition) errors.push(message); };
const read = (file) => fs.readFileSync(path.join(root, file), 'utf8');
const htmlFiles = fs.readdirSync(root).filter((file) => file.endsWith('.html'));

const versions = new Set();
for (const file of htmlFiles) {
  const html = read(file);
  for (const match of html.matchAll(/(?:css\/style\.css|js\/(?:i18n|main|map)\.js|vendor\/leaflet\/leaflet-core\.css)\?v=([^"']+)/g)) versions.add(match[1]);
  need(!/<img\b[^>]*\bsrc=["']\s*["']/i.test(html), `${file}: leere Bildquelle`);
  need(!/leaflet@1\.9\.4\/dist\/leaflet\.js/i.test(html), `${file}: blockierendes Leaflet-Script im HTML`);
}
need(versions.size === 1, `Uneinheitliche Asset-Versionen: ${[...versions].join(', ')}`);

for (const file of ['js/main.js', 'js/i18n.js', 'js/map.js', 'service-worker.js']) {
  const result = spawnSync(process.execPath, ['--check', path.join(root, file)], { encoding: 'utf8' });
  need(result.status === 0, `${file}: JavaScript-Syntaxfehler ${result.stderr.trim()}`);
}

const sw = read('service-worker.js');
const coreMatch = sw.match(/const CORE=\[([\s\S]*?)\];/);
need(Boolean(coreMatch), 'service-worker.js: CORE-Liste fehlt');
if (coreMatch) {
  for (const match of coreMatch[1].matchAll(/["']\.\/([^"']+)["']/g)) {
    const target = match[1].split('?')[0];
    need(fs.existsSync(path.join(root, target)), `service-worker.js: fehlende CORE-Datei ${target}`);
  }
}

const css = read('css/style.css');
need(css.split('{').length === css.split('}').length, 'style.css: unausgeglichene Klammern');
need(!/(?:\.slippy-map|\.map-placeholder|\.map-consent-panel|\.map-toolbar)\b/.test(css), 'style.css: alte Kartenimplementierung vorhanden');
need(fs.existsSync(path.join(root, 'vendor/leaflet/leaflet-core.css')), 'Lokale Leaflet-Kernstyles fehlen');
need(fs.existsSync(path.join(root, 'LICENSE-LEAFLET.txt')), 'Leaflet-Lizenzhinweis fehlt');

if (errors.length) {
  console.error('\nALBA’S STREETFOOD – FINALE ABNAHME\n');
  errors.forEach((error) => console.error(`✗ ${error}`));
  process.exit(1);
}
console.log('\nALBA’S STREETFOOD – FINALE ABNAHME\n');
console.log(`✓ ${htmlFiles.length} HTML-Seiten geprüft.`);
console.log('✓ Cache-Versionen sind projektweit einheitlich.');
console.log('✓ JavaScript-Syntax und Service-Worker-Dateien sind gültig.');
console.log('✓ Alte Karten- und Video-Altlasten sind entfernt.');
console.log('✓ Leaflet-Kernstyles und Lizenz liegen lokal vor.');
console.log('✓ Finale technische Abnahme bestanden.');
