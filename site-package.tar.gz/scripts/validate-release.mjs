#!/usr/bin/env node
import fs from 'node:fs';
const strict = process.argv.includes('--strict');
const data = JSON.parse(fs.readFileSync(new URL('../assets/data/business.json', import.meta.url), 'utf8'));
const errors=[];
const need=(condition,message)=>{ if(!condition) errors.push(message); };
need(data.publishReady === true, 'publishReady muss auf true gesetzt werden.');
need(/^https:\/\//.test(data.site?.productionUrl || ''), 'Endgültige HTTPS-Produktionsdomain fehlt.');
need(/^\d{4}-\d{2}-\d{2}$/.test(data.lastVerified || ''), 'Datum der letzten inhaltlichen Prüfung fehlt.');
need(data.address?.legalServiceAddressConfirmed === true, 'Ladungsfähige Anschrift muss bestätigt werden.');
need(/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.contact?.email || data.legal?.businessEmail || ''), 'Geschäftliche E-Mail-Adresse fehlt.');
need((data.operations?.paymentMethods || []).length > 0, 'Zahlungsarten fehlen.');
need(data.openingHours?.exceptionsConfirmed === true, 'Feiertags-, Urlaubs- und Ausnahmeregelung muss bestätigt werden.');
need(data.legal?.hostingProviderConfirmed === true, 'Hosting-Anbieter muss bestätigt werden.');
need(data.legal?.legalReviewConfirmed === true, 'Abschließende rechtliche Prüfung muss bestätigt werden.');
need(data.media?.realBusinessPhotosConfirmed === true, 'Echte Betriebsfotos müssen bestätigt oder eingesetzt werden.');
need(data.media?.imageRightsConfirmed === true, 'Bildrechte müssen bestätigt werden.');
for (const item of data.menu || []) {
  need(item.confirmed === true, `Gericht nicht bestätigt: ${item.name}`);
  need(Number.isFinite(item.price) && item.price > 0, `Preis fehlt: ${item.name}`);
  need(item.ingredientsConfirmed === true, `Zutaten/Allergene nicht bestätigt: ${item.name}`);
}
const impressum = fs.readFileSync(new URL('../impressum.html', import.meta.url), 'utf8');
const privacy = fs.readFileSync(new URL('../datenschutz.html', import.meta.url), 'utf8');
const menuHtml = fs.readFileSync(new URL('../speisekarte.html', import.meta.url), 'utf8');
need(!/legal-pending|Noch nicht zur Veröffentlichung freigegeben/i.test(impressum), 'Impressum enthält noch Freigabe-Platzhalter.');
need(!/legal-pending|Noch nicht zur Veröffentlichung freigegeben/i.test(privacy), 'Datenschutz enthält noch Freigabe-Platzhalter.');
need(!/data-menu-price=["'][^"']+["'][^>]*>(?:Preis vor Ort|Auswahl vor Ort)</i.test(menuHtml), 'Sichtbare Speisekarte enthält noch keine verbindlichen Preise.');
if (errors.length) {
  console.error('\nRELEASE-CHECK NICHT BESTANDEN\n');
  errors.forEach((e,i)=>console.error(`${i+1}. ${e}`));
  console.error('\nDetails in OPERATOR_INPUT.md und assets/data/business.json.\n');
  if (strict) process.exit(1);
} else console.log('Release-Check bestanden: Website ist inhaltlich zur Veröffentlichung freigegeben.');
