param(
  [string]$RepoName = "albas-streetfood"
)

$ErrorActionPreference = "Stop"

function Require-Command($Name) {
  if (-not (Get-Command $Name -ErrorAction SilentlyContinue)) {
    throw "'$Name' wurde nicht gefunden. Bitte zuerst installieren."
  }
}

Require-Command "git"
Require-Command "gh"

gh auth status | Out-Host
$Owner = gh api user --jq .login
$Repo = "$Owner/$RepoName"

if (-not (Test-Path ".git")) {
  git init
  git branch -M main
}

git add .
$Changes = git status --porcelain
if ($Changes) {
  git commit -m "Initiale Alba's Streetfood Website"
}

$Existing = gh repo view $Repo 2>$null
if ($LASTEXITCODE -ne 0) {
  gh repo create $Repo --public --description "Offizielle Website von Alba's Streetfood in Leutkirch" --source . --remote origin --push
} else {
  if (-not (git remote get-url origin 2>$null)) {
    git remote add origin "https://github.com/$Repo.git"
  }
  git push -u origin main
}

try {
  gh api -X POST "repos/$Repo/pages" -f build_type=workflow | Out-Null
} catch {
  Write-Host "GitHub Pages war vermutlich bereits aktiviert."
}

Write-Host "Fertig. Das Repository ist: https://github.com/$Repo"
Write-Host "Nach dem Workflow ist die Website voraussichtlich hier erreichbar: https://$Owner.github.io/$RepoName/"
