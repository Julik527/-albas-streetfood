#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const data=JSON.parse(fs.readFileSync(path.join(root,'assets/data/business.json'),'utf8'));
const htmlFiles=fs.readdirSync(root).filter((name)=>name.endsWith('.html'));
const escapeHtml=(value)=>String(value).replace(/[&<>"']/g,(char)=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[char]));
const formatPrice=(item)=>Number.isFinite(item?.price)&&item.price>0
  ? new Intl.NumberFormat('de-DE',{style:'currency',currency:item.currency||'EUR'}).format(item.price)
  : item?.id==='grill-sides'?'Auswahl vor Ort':'Preis vor Ort';
const contactLink=(type,value)=>{
  if(!value) return '';
  const label={phone:'Telefon',email:'E-Mail',whatsapp:'WhatsApp'}[type];
  const href=type==='email'?`mailto:${value}`:type==='phone'?`tel:${String(value).replace(/[^+\d]/g,'')}`:`https://wa.me/${String(value).replace(/\D/g,'')}`;
  const external=type==='whatsapp'?' target="_blank" rel="noopener noreferrer"':'';
  return `<a href="${escapeHtml(href)}"${external}>${label}: ${escapeHtml(value)}</a>`;
};
const contacts=['phone','email','whatsapp'].map((type)=>{
  const value=data.contact?.[type]||(type==='email'?data.legal?.businessEmail:'');
  return contactLink(type,value);
}).filter(Boolean).join('');

const updateJsonLd=(source,file)=>source.replace(/<script([^>]+type=["']application\/ld\+json["'][^>]*)>([\s\S]*?)<\/script>/gi,(full,attrs,raw)=>{
  try{
    const structured=JSON.parse(raw);
    const types=Array.isArray(structured['@type'])?structured['@type']:[structured['@type']];
    if(!types.includes('FoodEstablishment')&&!types.includes('LocalBusiness')) return full;
    const base=/^https:\/\//.test(data.site?.productionUrl||'')?data.site.productionUrl:null;
    const pageUrl=base?(file==='index.html'?base:new URL(file,base).href):null;
    const email=data.contact?.email||data.legal?.businessEmail||'';
    const phone=data.contact?.phone||'';
    const prices=(data.menu||[]).filter((item)=>item.confirmed&&Number.isFinite(item.price)&&item.price>0).map((item)=>item.price);
    structured.name=data.name||structured.name;
    if(pageUrl) structured.url=pageUrl; else delete structured.url;
    if(base) structured.image=new URL('assets/images/og-cover.jpg',base).href;
    structured.founder={'@type':'Person',name:data.owner||'Durim Gashi'};
    structured.address={'@type':'PostalAddress',streetAddress:data.address?.street||'',postalCode:data.address?.postalCode||'',addressLocality:data.address?.city||'',addressCountry:data.address?.country==='Deutschland'?'DE':data.address?.country||'DE'};
    structured.openingHoursSpecification=[{'@type':'OpeningHoursSpecification',dayOfWeek:'https://schema.org/Sunday',opens:data.openingHours?.opens||'10:00',closes:data.openingHours?.closes||'20:00'}];
    structured.sameAs=[data.contact?.instagram].filter(Boolean);
    if(base) structured.menu=new URL('speisekarte.html',base).href; else delete structured.menu;
    if(email) structured.email=email; else delete structured.email;
    if(phone) structured.telephone=phone; else delete structured.telephone;
    if((data.operations?.paymentMethods||[]).length) structured.paymentAccepted=data.operations.paymentMethods.join(', '); else delete structured.paymentAccepted;
    if(prices.length){const min=Math.min(...prices),max=Math.max(...prices);structured.priceRange=min===max?`${min.toFixed(2)} EUR`:`${min.toFixed(2)}–${max.toFixed(2)} EUR`;}else delete structured.priceRange;
    return `<script${attrs}>${JSON.stringify(structured)}</script>`;
  }catch{return full;}
});

for(const file of htmlFiles){
  const full=path.join(root,file);
  let source=fs.readFileSync(full,'utf8');
  for(const item of data.menu||[]){
    const value=item.confirmed?formatPrice(item):(item.id==='grill-sides'?'Auswahl vor Ort':'Preis vor Ort');
    const re=new RegExp(`(<([a-z0-9]+)\\b[^>]*data-menu-price=["']${item.id}["'][^>]*>)[\\s\\S]*?(<\\/\\2>)`,'gi');
    source=source.replace(re,`$1${escapeHtml(value)}$3`);
  }
  source=source.replace(/<div([^>]*data-business-contact-links[^>]*)>[\s\S]*?<\/div>/gi,(full,attrs)=>{
    const clean=attrs.replace(/\s+hidden(?:=["'][^"']*["'])?/gi,'');
    return contacts?`<div${clean}>${contacts}</div>`:`<div${clean} hidden></div>`;
  });
  source=updateJsonLd(source,file);
  const publicPage=!['404.html','offline.html','impressum.html','datenschutz.html'].includes(file);
  const ready=data.publishReady===true && /^https:\/\//.test(data.site?.productionUrl||'');
  if(publicPage){
    const robots=ready?'index, follow':'noindex, nofollow';
    source=source.replace(/<meta([^>]+name=["']robots["'][^>]+content=["'])[^"']*(["'][^>]*>)/i,`<meta$1${robots}$2`)
      .replace(/<meta([^>]+content=["'])[^"']*(["'][^>]+name=["']robots["'][^>]*>)/i,`<meta$1${robots}$2`);
  }
  fs.writeFileSync(full,source);
}
console.log('Bestätigte Geschäftsdaten wurden in die statischen HTML-Dateien synchronisiert.');
