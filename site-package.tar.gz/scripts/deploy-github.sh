#!/usr/bin/env bash
set -euo pipefail

REPO_NAME="${1:-albas-streetfood}"
command -v git >/dev/null || { echo "git fehlt"; exit 1; }
command -v gh >/dev/null || { echo "GitHub CLI (gh) fehlt"; exit 1; }

gh auth status
OWNER="$(gh api user --jq .login)"
REPO="$OWNER/$REPO_NAME"

if [ ! -d .git ]; then
  git init
  git branch -M main
fi

git add .
if ! git diff --cached --quiet; then
  git commit -m "Initiale Alba's Streetfood Website"
fi

if gh repo view "$REPO" >/dev/null 2>&1; then
  git remote get-url origin >/dev/null 2>&1 || git remote add origin "https://github.com/$REPO.git"
  git push -u origin main
else
  gh repo create "$REPO" --public --description "Offizielle Website von Alba's Streetfood in Leutkirch" --source . --remote origin --push
fi

gh api -X POST "repos/$REPO/pages" -f build_type=workflow >/dev/null 2>&1 || true

echo "Repository: https://github.com/$REPO"
echo "Website: https://$OWNER.github.io/$REPO_NAME/"
