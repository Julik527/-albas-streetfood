# Finale technische Abnahme

Diese Fassung wurde als zusammenhängendes HTML-, CSS- und JavaScript-System bereinigt und geprüft.

## Repariert

- einheitliche Cache-Version auf allen elf HTML-Seiten
- alte Eigenbau-, iframe- und Zwei-Klick-Kartenlogik vollständig entfernt
- lokale Leaflet-Kernstyles statt eines externen render-blockierenden Karten-Stylesheets
- Leaflet-JavaScript mit Zeitüberschreitung und zweitem CDN-Fallback
- korrekter Kartenstatus: „geladen“ wird erst nach tatsächlich geladenen Kacheln angezeigt
- automatische Straßenkarten-Rückfallebene bei nicht erreichbaren Satellitenkacheln
- alte, ungenutzte CSS-Regeln für frühere Menü-, Video- und Kartenlayouts entfernt
- leere `src`-Attribute aus den Bilderdialogen entfernt
- Menüfilter auf den zugehörigen Speisekartenbereich begrenzt
- Preisrechner verhindert Kopieren und Teilen bei leerer Auswahl
- Preisstand wird aus `business.json` angezeigt
- Visualisierungshinweis steht unter Bildern und niemals auf der Titel- oder Kartenfläche
- Netlify-Sicherheitsheader ergänzt
- Testversion bleibt über `noindex, nofollow` aus Suchmaschinen heraus, bis die Freigabedaten vollständig sind

## Bewusste Entscheidung

Es wurden keine weiteren Show-Effekte eingebaut. Die Website besitzt bereits Bildkarussell, Öffnungsstatus, Besuchsplaner, Satellitenkarte, Speisekartenfilter, Preisrechner, Galerie, FAQ, Sprachwechsel, Teilen, Offline-Fallback und mobile Schnellaktionen. Mehr Funktionen würden die Bedienung eher überladen.

## Offene Inhaberdaten

Der technische Stand ist abgeschlossen. Die Freigabeprüfung bleibt nur wegen realer Betreiber-, Zutaten-, Allergie-, Medien- und Rechtsangaben gesperrt.
