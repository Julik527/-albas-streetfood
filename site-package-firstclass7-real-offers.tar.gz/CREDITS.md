# Herkunft und Rechte

## Marke

- Website: Alba’s Streetfood
- Betreiber: Durim Gashi
- Logo: vom Auftraggeber bereitgestellt

## Bilder

Ein Teil der enthaltenen Food- und Atmosphärenbilder sind Visualisierungen auf Grundlage der bereitgestellten Informationen und Referenzbilder. Sie dürfen nicht als verbindliche Darstellung von Portionen, Zutaten, Personen oder konkreten Verkaufssituationen verstanden werden. Vor der endgültigen Unternehmensveröffentlichung sollen bestätigte Originalfotos eingesetzt und die Bildrechte dokumentiert werden.

Die Freigabe wird in `assets/data/business.json` dokumentiert:

```json
"media": {
  "realBusinessPhotosConfirmed": true,
  "imageRightsConfirmed": true
}
```

## Karte

- Satellitenbilder: Esri World Imagery, mit Quellenangabe direkt unter der Karte
- Straßenkarte: OpenStreetMap-Mitwirkende, ODbL
- Kartensteuerung: projektspezifische, lokale JavaScript-Implementierung ohne externe UI-Bibliothek.

## Technik

Navigation, Titelbild, Bilderdialog, Übersetzungen, Öffnungsstatus, Besuchsplaner, Preisrechner und Geschäftsdaten-Anbindung sind im Projekt selbst umgesetzt. Es werden keine Analyse- oder Werbetracker verwendet.

## Aktuelle Standortaufnahmen

- `story-location-*`: aus einer aktuellen Instagram-Story von Alba’s Streetfood, für die Website ohne App-Oberfläche zugeschnitten.
- `story-service-*`: aus einer aktuellen Instagram-Story von Alba’s Streetfood, für die Website ohne App-Oberfläche und mit reduziertem Leerraum zugeschnitten.
- Öffentliche Nutzung bleibt bis zur Bestätigung der Bildrechte und Einwilligungen als Vorschau behandelt.


## Reale Aktionskarten vom 26. Juli 2026

Fünf fotografierte Angebotskarten wurden als reale Aufnahmen vom Foodtruck integriert:

- 10 Stück Cevapcici, 10 €
- 7 Stück Cevapcici, 7 €
- 5 Stück Cevapcici, 5 €
- Cevapcici-Burger, 5 €
- Wellenschnitt-Pommes, 3 €

Die Fotos wurden ausschließlich technisch optimiert: Perspektive, Zuschnitt, Weißabgleich, Kontrast, Schärfe und Web-Komprimierung. Texte, Preise und Produktdarstellungen wurden nicht inhaltlich verändert.

Das Foto des Getränkekühlschranks wurde zwar ohne sichtbare Spiegelung der fotografierenden Person zugeschnitten, wegen weiterhin vorhandener Glasspiegelungen und nicht dauerhaft bestätigter Getränkeauswahl aber nicht in die öffentliche Website übernommen.
