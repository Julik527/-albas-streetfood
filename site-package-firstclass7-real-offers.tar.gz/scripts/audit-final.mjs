#!/usr/bin/env node
import fs from 'node:fs'; import path from 'node:path'; import {spawnSync} from 'node:child_process'; import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'); const errors=[]; const need=(c,m)=>{if(!c)errors.push(m)}; const read=(f)=>fs.readFileSync(path.join(root,f),'utf8'); const htmlFiles=fs.readdirSync(root).filter(f=>f.endsWith('.html'));
const versions=new Set(); for(const file of htmlFiles){const html=read(file);for(const m of html.matchAll(/(?:css\/style\.css|js\/(?:i18n|main|map)\.js)\?v=([^"']+)/g))versions.add(m[1]);need(!/<img\b[^>]*\bsrc=["']\s*["']/i.test(html),`${file}: leere Bildquelle`);need(!/rel=["']manifest["']/i.test(html),`${file}: PWA-Manifest noch eingebunden`);need(!/leaflet|unpkg\.com|cdn\.jsdelivr\.net/i.test(html),`${file}: externe Kartenbibliothek vorhanden`);} need(versions.size===1,`Uneinheitliche Asset-Versionen: ${[...versions].join(', ')}`);
for(const file of ['js/main.js','js/i18n.js','js/map.js']){const r=spawnSync(process.execPath,['--check',path.join(root,file)],{encoding:'utf8'});need(r.status===0,`${file}: Syntaxfehler ${r.stderr.trim()}`);} need(fs.existsSync(path.join(root,'service-worker.js')),'Service-Worker-Kill-Switch fehlt'); need(!fs.existsSync(path.join(root,'site.webmanifest')),'Manifest sollte entfernt sein');
const css=read('css/style.css'); const main=read('js/main.js'); const i18n=read('js/i18n.js'); const index=read('index.html');
need(css.split('{').length===css.split('}').length,'style.css: unausgeglichene Klammern');
need(!/\.leaflet-|L\.map\(/.test(css+read('js/map.js')),'Leaflet-Reste vorhanden');
need(fs.existsSync(path.join(root,'assets/images/foodtruck-hero-real-1600.webp')),'Reales Hero-Foto fehlt');
for (const image of [
  'offer-cevapcici-10-900.webp',
  'offer-cevapcici-7-900.webp',
  'offer-cevapcici-5-900.webp',
  'offer-cevapcici-burger-900.webp',
  'offer-wellenschnitt-pommes-900.webp'
]) need(fs.existsSync(path.join(root,'assets/images',image)),`Reale Aktionskarte fehlt: ${image}`);
need(/promotion-photo-grid/.test(index),'Fotoleiste der aktuellen Aktionskarten fehlt auf der Startseite');
need(/offer-gallery-section/.test(read('galerie.html')),'Galerieabschnitt der aktuellen Aktionskarten fehlt');
need(!fs.existsSync(path.join(root,'_headers')),'Netlify-Headerdatei sollte entfernt sein');
need(!/data-carousel|carousel-track|carouselControllers/.test(index+main),'Veraltetes Karussell noch vorhanden');
need(/<section[^>]+class=["'][^"']*hero-media[^"']*["'][^>]*>\s*<picture>/i.test(index),'Statisches echtes Titelbild fehlt');
need(!/assets\/images\/(?:foodtruck-(?:brand|night)|gallery-(?:brand|night)|hamburger-menu|home-hamburger)/i.test([...htmlFiles.map(read),css,main].join('\n')),'Nicht freigegebene oder markenfremde Medienreferenz vorhanden');
need(!/11 am to 7 pm|11:00|19:00/.test(i18n),'Veraltete Öffnungszeit in Übersetzungen vorhanden');
const sw=read('service-worker.js'); need(!/serviceWorker\.register|register\(['"]\.\/service-worker\.js/.test(main),'Aktive Service-Worker-Registrierung vorhanden'); need(/registration\.unregister\(\)/.test(sw)&&/caches\.keys\(\)/.test(sw),'Service-Worker-Kill-Switch ist unvollständig');
if(errors.length){console.error(errors.map(e=>'✗ '+e).join('\n'));process.exit(1)}console.log(`✓ ${htmlFiles.length} Seiten, lokale Karte, Medienkennzeichnung und cachefreie Architektur geprüft.`);
