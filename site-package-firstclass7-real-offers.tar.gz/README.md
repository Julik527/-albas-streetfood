# Alba’s Streetfood

Mehrseitige, responsive Unternehmenswebsite für Alba’s Streetfood in Leutkirch im Allgäu.

## Enthalten

- Startseite mit manuell bedienbarem Bildkarussell ohne automatischen Wechsel
- Speisekarte mit bestätigten Preisen, Filtern und unverbindlichem Preisrechner
- Besuchsplaner mit persönlichem Kalenderexport
- sofort sichtbare interaktive Satellitenkarte mit Straßenkarten-Umschaltung
- Über-uns-, Standort-, Galerie- und Kontaktseite
- deutsche, englische und albanische Oberfläche
- barrierearme Tastatur- und Mobilbedienung
- Offline-Fallback und Service Worker
- automatische Struktur-, Harmonie-, Karten- und Veröffentlichungsprüfung

## Lokal testen

```bash
npm run preview
```

Danach `http://localhost:8080` öffnen.

## Qualitätsprüfung

```bash
npm run audit
```

## Betreiberangaben pflegen

Veränderliche Geschäftsdaten befinden sich zentral in `assets/data/business.json`. Bestätigte Preise, Kontaktwege, Zahlungsarten und Serviceinformationen werden automatisch eingeblendet. Offene Angaben stehen in `OPERATOR_INPUT.md`.

## Bestätigte Daten statisch übernehmen

```bash
npm run sync:business
```

Solange `publishReady` nicht auf `true` steht und keine endgültige HTTPS-Domain eingetragen ist, erhalten die öffentlichen Seiten bewusst `noindex, nofollow`.

## Domain eintragen

```bash
npm run configure:domain -- https://www.beispiel-domain.de/
```

## Veröffentlichung prüfen

```bash
npm run release:check
```

Die Veröffentlichung bleibt gesperrt, solange Pflichtangaben, Bildrechte oder rechtliche Bestätigungen fehlen.


## First-Class-Härtung 26.07.2026

- Kartensteuerung vollständig lokal, nur Kartenkacheln extern
- kein Service Worker und kein PWA-Cache
- Besuchsplaner auf Datum und Uhrzeit reduziert
- echte Fotos und KI-Visualisierungen eindeutig gekennzeichnet
- reale Foodtruck-Aufnahme für die Titelkarte neu zugeschnitten


## First Class 7 – reale Aktionskarten

Die Ausgabe vom 26.07.2026 enthält fünf technisch optimierte Originalfotos der am Foodtruck ausgehängten Tagesangebote. Sie werden nur während des in `business.json` hinterlegten Aktionszeitraums angezeigt und danach automatisch ausgeblendet. Das Getränkekühlschrank-Foto wurde aus Qualitäts- und Aktualitätsgründen nicht veröffentlicht.
