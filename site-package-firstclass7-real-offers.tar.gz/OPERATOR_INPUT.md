# Freigabebogen für Durim Gashi

Die technische Website ist fertig. Für die geschäftliche Freigabe werden nur noch echte, bestätigte Angaben benötigt. Bitte jede Frage eindeutig beantworten. Unbekannte Punkte bleiben auf der Website unsichtbar.

## Bereits eingetragen

- Standort: Goldschmitt Techmobil, Kemptener Str. 54, 88299 Leutkirch im Allgäu
- Öffnungszeit: Sonntag, 10:00 bis 20:00 Uhr
- 5 Cevapcici: 7,00 €
- 7 Cevapcici: 8,50 €
- 10 Cevapcici: 10,00 €
- Hamburger: 7,00 €
- Salat: 4,50 €
- Pommes: 4,00 €
- Hamburger + Pommes + Getränk: 12,00 €
- Salat laut Karte: Gurken, Tomaten, Oliven, Zwiebeln und Weißkäse
- Cevapcici: im Brot oder auf dem Teller

## 1. Pflichtkontakt

- Geschäftliche E-Mail-Adresse:
- Telefonnummer:
- WhatsApp Business, falls vorhanden:
- Ist Kemptener Str. 54 auch die ladungsfähige Geschäftsanschrift? Ja / Nein
- Falls nein, vollständige ladungsfähige Anschrift:

## 2. Bezahlung und Betrieb

- Barzahlung möglich? Ja / Nein
- Kartenzahlung möglich? Ja / Nein
- Weitere Zahlungsarten:
- Vorbestellungen möglich? Ja / Nein
- Ablauf für Vorbestellungen:
- Regelung bei schlechtem Wetter:
- Regelung an Feiertagen und im Urlaub:
- Parkmöglichkeiten:
- Sitzmöglichkeiten:
- Barrierefreier Zugang:

## 3. Zutaten, Allergene und Zusatzstoffe

Für jedes Gericht bitte Zutaten, Allergene und kennzeichnungspflichtige Zusatzstoffe nennen:

- Cevapcici:
- Brot/Fladenbrot:
- Hamburger-Brötchen:
- Hamburger-Fleisch und Belag:
- Salat und Dressing:
- Pommes und Frittierfett:
- Soßen:
- Hamburger-Menü-Getränke:

## 4. Getränke

- Albanische Getränke, Sorte, Größe und Preis:
- Normale Softdrinks, Sorte, Größe und Preis:
- Wechseln Sorten oder Preise regelmäßig? Ja / Nein

## 5. Bilder und Marke

- Darf das bereitgestellte Logo öffentlich genutzt werden? Ja / Nein
- Darf das echte Foodtruck-Foto öffentlich genutzt werden? Ja / Nein
- Liegen Einwilligungen für erkennbare Personen auf den neuen Story-Fotos vor? Ja / Nein / Keine Personen erkennbar
- Welche Speisenbilder zeigen echte Produkte von Alba’s Streetfood?
- Neue Originalfotos vorgesehen? Ja / Nein

## 6. Recht und Veröffentlichung

- Hosting über GitHub Pages bestätigt? Ja / Nein
- Gewünschte endgültige Domain:
- Impressum geprüft? Ja / Nein
- Datenschutzerklärung geprüft? Ja / Nein
- Datum der finalen Freigabe:

Nach vollständiger Bestätigung werden die Daten in `assets/data/business.json` eingetragen. Erst danach wird `publishReady` auf `true` gesetzt.


## Zusätzliche Bildfreigabe

Bitte ausdrücklich bestätigen:

- Dürfen die fünf fotografierten Aktionskarten vom 26.07.2026 öffentlich auf der Website gezeigt werden?
- Sind die darauf sichtbaren Preise ausschließlich für den 26.07.2026 bestimmt?
- Darf die Aktionskarte des Cevapcici-Burgers mit 5 € veröffentlicht werden?
- Darf die Aktionskarte der Wellenschnitt-Pommes mit 3 € veröffentlicht werden?

Das Getränkekühlschrank-Foto wird derzeit nicht öffentlich verwendet.
