# Interaktive Karte – finale Architektur

## Aktuelle Umsetzung

- projektspezifische, lokale Kartensteuerung ohne Leaflet, iframe oder externes JavaScript
- Satellitenkacheln von Esri World Imagery
- Straßenkartenkacheln von OpenStreetMap
- Satellitenansicht wird beim Seitenaufruf unmittelbar angefordert
- zentrale Kartenkacheln werden zuerst geladen
- vorhandene Karte bleibt sichtbar, bis die neue Ansicht geladen ist
- automatische Straßenkarten-Rückfallebene nach Fehlern oder 7 Sekunden ohne geladene Kachel
- Verschieben mit Finger oder Maus ohne vollständiges Neuladen bei jeder Bewegung
- Pinch-Zoom, Mausrad, Doppelklick, Plus/Minus und Tastatursteuerung
- exakter Standortmarker und Zentrierfunktion
- keine Titel- oder Beschreibungstexte auf der Kartenfläche
- Status, Quellen und Routenaktionen ausschließlich unterhalb der Karte

Die Karte ist auf `index.html` und `standort.html` eingebunden.
