# Finale technische Abnahme

Diese Fassung wurde als zusammenhängendes, statisches HTML-, CSS- und JavaScript-System bereinigt und geprüft.

## First-Class-Verbesserungen

- ein einziges echtes, textfreies Titelbild ohne sichtbare Überlagerungen
- Social-Preview-Foto ohne Story-Text, veraltete Kontaktdaten oder fremde Markenbezeichnung
- künstliche Foodtruck-Motive und gebrandetes Getränkebild entfernt
- Speisenvisualisierungen reduziert und direkt am jeweiligen Bild gekennzeichnet
- Karussell, Service Worker, Manifest, Offline-Seite und Netlify-Artefakte entfernt
- einheitliche Asset-Version auf allen zehn HTML-Seiten
- lokale Kartensteuerung ohne externe JavaScript-Bibliothek
- Satellitenansicht mit Straßenkarten-Fallback, 7-Sekunden-Zeitüberschreitung und zentraler Kachel-Ladereihenfolge
- flüssiges Verschieben der Karte ohne neue Kachelanfrage bei jeder Fingerbewegung
- Status „geladen“ erst nach einer tatsächlich geladenen Kartenkachel
- Besuchsplaner auf Datum und Uhrzeit reduziert
- Preisrechner verhindert Teilen oder Kopieren bei leerer Auswahl
- Testfassung bleibt mit `noindex, nofollow` aus Suchmaschinen heraus

## Prüfstand

- 10 HTML-Seiten
- 0 strukturelle Blocker
- 0 technische Hinweise
- vollständige DE-, EN- und SQ-Schlüssel für alle verwendeten Inhalte
- gültige JavaScript-Syntax
- konsistente lokale Dateireferenzen

## Nicht technisch lösbare Freigabepunkte

Die geschäftliche Freigabe benötigt weiterhin echte Angaben des Inhabers: E-Mail, ladungsfähige Anschrift, Zahlungsarten, Allergene, Ausnahmeregelungen, Bildrechte und rechtliche Prüfung. Diese Daten wurden nicht erfunden.
