#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const htmlFiles = fs.readdirSync(root).filter((name) => name.endsWith('.html'));
const errors = [];
const pass = (message) => console.log(`✓ ${message}`);
const fail = (file, message) => errors.push(`${file}: ${message}`);

const css = fs.readFileSync(path.join(root, 'css/style.css'), 'utf8');
const main = fs.readFileSync(path.join(root, 'js/main.js'), 'utf8');
const i18nSource = fs.readFileSync(path.join(root, 'js/i18n.js'), 'utf8');

// Read the private translation object safely without changing the production file.
const instrumented = i18nSource.replace(
  'window.AlbasI18n = new AlbaI18n();',
  'window.__albasTranslations = translations; window.AlbasI18n = new AlbaI18n();'
);
const context = {
  window: {},
  navigator: { language: 'de-DE' },
  localStorage: { getItem: () => null, setItem: () => {} },
  document: { documentElement: {}, body: null, querySelector: () => null, querySelectorAll: () => [] },
  CustomEvent: class CustomEvent {},
};
vm.createContext(context);
vm.runInContext(instrumented, context);
const translations = context.window.__albasTranslations;
const getNested = (object, key) => key.split('.').reduce((value, part) => value?.[part], object);

const interactivePages = new Set(['index.html', 'speisekarte.html', 'ueber-uns.html', 'standort.html', 'galerie.html', 'kontakt.html']);
const allHtml = htmlFiles.map((file) => fs.readFileSync(path.join(root, file), 'utf8')).join('\n');
const usedKeys = new Set();

for (const file of htmlFiles) {
  const source = fs.readFileSync(path.join(root, file), 'utf8');
  if (/\son[a-z]+\s*=/i.test(source)) fail(file, 'Inline-Eventhandler gefunden; Interaktionen gehören in JavaScript.');
  if (/\sstyle\s*=/i.test(source)) fail(file, 'Inline-Styles gefunden; Gestaltung gehört in CSS.');

  if (interactivePages.has(file)) {
    const i18nMatch = source.match(/<script[^>]+src="js\/i18n\.js(?:\?[^"]*)?"[^>]*defer[^>]*>|<script[^>]+defer[^>]+src="js\/i18n\.js(?:\?[^"]*)?"[^>]*>/);
    const mainMatch = source.match(/<script[^>]+src="js\/main\.js(?:\?[^"]*)?"[^>]*defer[^>]*>|<script[^>]+defer[^>]+src="js\/main\.js(?:\?[^"]*)?"[^>]*>/);
    const i18nIndex = i18nMatch ? source.indexOf(i18nMatch[0]) : -1;
    const mainIndex = mainMatch ? source.indexOf(mainMatch[0]) : -1;
    if (i18nIndex < 0 || mainIndex < 0) fail(file, 'Zentrale JavaScript-Dateien fehlen oder werden nicht mit defer geladen.');
    if (i18nIndex >= 0 && mainIndex >= 0 && i18nIndex > mainIndex) fail(file, 'i18n.js muss vor main.js geladen werden.');
    const stylesheetCount = (source.match(/<link[^>]+(?:rel="stylesheet"[^>]+href="css\/style\.css(?:\?[^"]*)?"|href="css\/style\.css(?:\?[^"]*)?"[^>]+rel="stylesheet")[^>]*>/g) || []).length;
    if (stylesheetCount !== 1) fail(file, 'Zentrales Stylesheet muss genau einmal eingebunden sein.');
  }

  for (const match of source.matchAll(/data-i18n(?:-html)?=["']([^"']+)["']/g)) usedKeys.add(match[1]);
  for (const match of source.matchAll(/data-i18n-attr=["']([^"']+)["']/g)) {
    for (const pair of match[1].split(';')) {
      const key = pair.split(':').slice(1).join(':').trim();
      if (key) usedKeys.add(key);
    }
  }
}

for (const key of usedKeys) {
  for (const language of ['de', 'en', 'sq']) {
    if (typeof getNested(translations?.[language], key) !== 'string') fail('js/i18n.js', `Übersetzung fehlt: ${language}.${key}`);
  }
}

// Classes changed by JavaScript must have corresponding CSS states.
const dynamicClasses = new Set();
for (const match of main.matchAll(/classList\.(?:add|remove|toggle)\(\s*["']([^"']+)["']/g)) dynamicClasses.add(match[1]);
for (const className of dynamicClasses) {
  if (!css.includes(`.${className}`) && !allHtml.includes(`class="${className}`) && !allHtml.includes(` ${className}`)) {
    fail('js/main.js', `Dynamische Klasse ohne CSS-/HTML-Vertrag: .${className}`);
  }
}

// Important hooks queried by JavaScript must exist in HTML or be created by JavaScript.
const hookSelectors = new Set();
for (const match of main.matchAll(/qsa?\(\s*["'](#[\w-]+|\[data-[^"']+\]|\.[\w-]+)["']/g)) hookSelectors.add(match[1]);
const createdClasses = new Set([...main.matchAll(/className\s*=\s*["']([^"']+)["']/g)].flatMap((match) => match[1].split(/\s+/)));
for (const selector of hookSelectors) {
  if (selector.startsWith('#') && !allHtml.includes(`id="${selector.slice(1)}"`)) fail('js/main.js', `ID-Hook ohne HTML-Gegenstück: ${selector}`);
  if (selector.startsWith('[data-')) {
    const attr = selector.match(/^\[([^=\]]+)/)?.[1];
    if (attr && !allHtml.includes(attr) && !main.includes(`setAttribute('${attr}'`) && !main.includes(`setAttribute("${attr}"`)) fail('js/main.js', `Data-Hook ohne HTML-Gegenstück: ${selector}`);
  }
  if (selector.startsWith('.')) {
    const className = selector.slice(1);
    if (!allHtml.includes(className) && !createdClasses.has(className)) fail('js/main.js', `Klassen-Hook ohne HTML-/JS-Gegenstück: ${selector}`);
  }
}

if (!/fetch\(['"]assets\/data\/business\.json['"]/.test(main)) fail('js/main.js', 'Geschäftsdaten werden nicht zentral geladen.');
if (!/businessData\?\.openingHours/.test(main) || !/businessData\?\.address/.test(main)) fail('js/main.js', 'Öffnungszeiten und Adresse sind nicht mit business.json synchronisiert.');
if (!/prefers-reduced-motion/.test(css)) fail('CSS', 'Reduzierte Bewegung muss im Stylesheet berücksichtigt werden.');

const assetVersions = new Set();
for (const file of htmlFiles) {
  const source = fs.readFileSync(path.join(root, file), 'utf8');
  for (const match of source.matchAll(/(?:css\/style\.css|js\/(?:i18n|main|map)\.js)\?v=([^"']+)/g)) assetVersions.add(match[1]);
}
if (assetVersions.size !== 1) fail('HTML', `Uneinheitliche Cache-Versionen: ${[...assetVersions].join(', ')}`);
if (/\.(?:map-placeholder|slippy-map|map-consent-panel|map-toolbar)\b/.test(css)) fail('style.css', 'Veraltete Kartenregeln sind noch vorhanden.');


console.log('\nALBA’S STREETFOOD – HTML/CSS/JS-HARMONIEPRÜFUNG\n');
if (errors.length) {
  errors.forEach((error) => console.error(`✗ ${error}`));
  console.error(`\n${errors.length} Harmoniefehler.`);
  process.exit(1);
}
pass(`${interactivePages.size} interaktive Seiten laden CSS und JavaScript in konsistenter Reihenfolge.`);
pass(`${usedKeys.size} verwendete Übersetzungsschlüssel sind in DE, EN und SQ vollständig.`);
pass('Dynamische JavaScript-Zustände besitzen passende CSS-/HTML-Verträge.');
pass('Adresse und Öffnungszeiten stammen zentral aus business.json.');
console.log('\nHarmonieprüfung bestanden.');
