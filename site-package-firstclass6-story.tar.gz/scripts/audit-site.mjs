#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const htmlFiles=fs.readdirSync(root).filter((name)=>name.endsWith('.html'));
const errors=[]; const warnings=[]; const ok=[];
const fail=(file,msg)=>errors.push(`${file}: ${msg}`);
const warn=(file,msg)=>warnings.push(`${file}: ${msg}`);
const pass=(msg)=>ok.push(msg);
const getAttrs=(tag)=>Object.fromEntries([...tag.matchAll(/([\w:-]+)\s*=\s*["']([^"']*)["']/g)].map((m)=>[m[1],m[2]]));
const isExternal=(value)=>/^(?:https?:|mailto:|tel:|data:|#)/i.test(value);
const carouselAllowed=new Set();
const visibleImageUsage=new Map();

for (const file of htmlFiles) {
  const source=fs.readFileSync(path.join(root,file),'utf8');
  if (/data-carousel(?:=|\s|>)/i.test(source) && !carouselAllowed.has(file)) fail(file,'Bildkarussell ist auf dieser Unterseite nicht vorgesehen.');
  if (/durim-(?:am-grill|foodtruck|gashi-portrait)/i.test(source)) fail(file,'Uneinheitliche Konzept-Personenbilder dürfen nicht öffentlich verwendet werden.');
  if (/data-aos|scroll-progress|hero-grain|glassmorphism|Schulprojekt|Portfolio-Website/i.test(source)) fail(file,'Veraltete Projekt-, Template- oder Effektmarkierungen gefunden.');
  if (/data-carousel-toggle|carousel-toggle/i.test(source)) fail(file,'Play-/Pause-Steuerung ist für das Karussell nicht vorgesehen.');
  if (/data-autoplay|data-interval/i.test(source)) fail(file,'Automatischer Bildwechsel ist für das Karussell nicht vorgesehen.');
  const ids=[...source.matchAll(/\sid=["']([^"']+)["']/g)].map((m)=>m[1]);
  const duplicates=ids.filter((id,index)=>ids.indexOf(id)!==index);
  if (duplicates.length) fail(file,`doppelte IDs: ${[...new Set(duplicates)].join(', ')}`);
  const h1=(source.match(/<h1\b/gi)||[]).length;
  if (!['404.html'].includes(file) && h1!==1) fail(file,`erwartet genau eine H1, gefunden: ${h1}`);
  if (!/<html[^>]+lang=["'][a-z-]+["']/i.test(source)) fail(file,'HTML-Sprachattribut fehlt.');
  if (!/<meta[^>]+name=["']viewport["']/i.test(source)) fail(file,'Viewport-Metadatum fehlt.');
  if (!/<title>[^<]{8,}<\/title>/i.test(source)) fail(file,'aussagekräftiger Seitentitel fehlt.');
  if (!['404.html','impressum.html','datenschutz.html'].includes(file)) {
    if (!/<meta[^>]+name=["']description["']/i.test(source)) fail(file,'Meta-Description fehlt.');
    if (!/<link[^>]+rel=["']canonical["']/i.test(source)) fail(file,'Canonical-Link fehlt.');
    if (!/property=["']og:image:alt["']/i.test(source)) fail(file,'Open-Graph-Bildbeschreibung fehlt.');
  }
  for (const match of source.matchAll(/<img\b[^>]*>/gi)) {
    const attrs=getAttrs(match[0]);
    if ('src' in attrs && attrs.src === '') fail(file,'Bild mit leerem src-Attribut gefunden.');
    if (!('alt' in attrs)) fail(file,`Bild ohne alt: ${attrs.src||'(ohne src)'}`);
    if (!('width' in attrs) || !('height' in attrs)) fail(file,`Bild ohne feste Abmessungen: ${attrs.src||'(ohne src)'}`);
    if (attrs.fetchpriority==='high' && attrs.loading==='lazy') fail(file,`Hero-Bild zugleich high und lazy: ${attrs.src}`);
  }
  const mainSource=(source.match(/<main\b[^>]*>([\s\S]*?)<\/main>/i)||[])[1]||'';
  const visibleImageSources=[...mainSource.matchAll(/<img\b[^>]*>/gi)]
    .map((match)=>getAttrs(match[0]))
    .filter((attrs)=>attrs.src && !attrs.src.includes('logo-') && attrs.id!=='lightboxImage')
    .map((attrs)=>attrs.src.split(/[?#]/)[0]);
  const repeatedImages=[...new Set(visibleImageSources.filter((src,index)=>visibleImageSources.indexOf(src)!==index))];
  if (repeatedImages.length) fail(file,`sichtbare Bildmotive mehrfach verwendet: ${repeatedImages.join(', ')}`);
  visibleImageSources.forEach((src) => {
    const files = visibleImageUsage.get(src) || [];
    files.push(file);
    visibleImageUsage.set(src, files);
  });
  const allowedExternalResources = [];
  for (const match of source.matchAll(/<(script|img|source|link)\b[^>]*(?:src|href)=["'](https?:\/\/[^"']+)["'][^>]*>/gi)) {
    const tag=match[1].toLowerCase();
    const full=match[0];
    if (tag==='link' && !/rel=["'](?:stylesheet|preload|icon|manifest)["']/i.test(full)) continue;
    if (allowedExternalResources.some((pattern)=>pattern.test(match[2]))) continue;
    fail(file,`extern geladene Ressource ist nicht vorgesehen: ${match[2]}`);
  }
  for (const match of source.matchAll(/<a\b[^>]*target=["']_blank["'][^>]*>/gi)) {
    const attrs=getAttrs(match[0]);
    if (!String(attrs.rel||'').includes('noopener')) fail(file,`target=_blank ohne noopener: ${attrs.href||''}`);
  }
  for (const match of source.matchAll(/<(?:script|img|source|link|a)\b[^>]*(?:src|href|srcset)=["']([^"']+)["'][^>]*>/gi)) {
    const raw=match[1];
    const values=raw.includes(',') ? raw.split(',').map((part)=>part.trim().split(/\s+/)[0]) : [raw];
    for (const value of values) {
      if (!value || isExternal(value) || value.startsWith('javascript:')) continue;
      const clean=value.split(/[?#]/)[0];
      if (!clean || clean.endsWith('/')) continue;
      if (!fs.existsSync(path.resolve(root,clean))) fail(file,`lokale Referenz fehlt: ${clean}`);
    }
  }
  for (const match of source.matchAll(/<script[^>]+type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi)) {
    try { JSON.parse(match[1]); } catch (error) { fail(file,`ungültiges JSON-LD: ${error.message}`); }
  }
}



if (!errors.length) pass(`${htmlFiles.length} HTML-Dateien ohne strukturelle Blocker geprüft.`);
console.log('\nALBA’S STREETFOOD – QUALITÄTSAUDIT\n');
ok.forEach((m)=>console.log(`✓ ${m}`));
warnings.forEach((m)=>console.warn(`⚠ ${m}`));
if (errors.length) {
  errors.forEach((m)=>console.error(`✗ ${m}`));
  console.error(`\n${errors.length} Fehler, ${warnings.length} Hinweise.`);
  process.exit(1);
}
console.log(`\nAudit bestanden. ${warnings.length} nicht blockierende Hinweise.`);
