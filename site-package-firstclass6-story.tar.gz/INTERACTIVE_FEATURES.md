# Interaktive Funktionen

## Global

- Live-Öffnungsstatus in der Desktop-Navigation
- minutengenaue Öffnungsinformation
- responsive mobile Navigation mit Fokussteuerung
- Sprachwechsel Deutsch, Englisch und Albanisch
- Teilen über Web Share mit Zwischenablage-Fallback
- optionale Installation als Web-App
- Online- und Offline-Rückmeldung
- kein Service Worker und Offline-Seite

## Startseite

- manuell steuerbares Bildkarussell mit Tastatur und Wischgeste
- kein automatischer Wechsel, kein Play-/Pause-Button
- Besuchsplaner für den nächsten Verkaufssonntag
- dynamischer Kalenderexport als ICS-Datei
- sofort geladene Satellitenkarte mit Straßenkarten-Umschaltung
- FAQ-Akkordeon

## Speisekarte

- Filter nach Cevapcici, Hamburger, Beilagen und Getränken
- Preisrechner mit Plus- und Minussteuerung
- automatische Gesamtsumme aus `business.json`
- Auswahl kopieren, teilen und zurücksetzen
- keine Bestellung und keine Reservierung

## Weitere Seiten

- Galerie mit zugänglicher Großansicht
- Kontaktseite mit Teilen und optionaler App-Installation
- zentrale Pflege von Adresse, Öffnungszeiten und Preisen
