(() => {
  'use strict';

  const qs = (selector, scope = document) => scope.querySelector(selector);
  const qsa = (selector, scope = document) => [...scope.querySelectorAll(selector)];
  const i18n = window.AlbasI18n;
  const localeMap = { de: 'de-DE', en: 'en-GB', sq: 'sq-AL' };
  const menuToggle = qs('#menuToggle');
  const mainNav = qs('#mainNav');
  const toast = qs('#toast');
  let returnFocus = null;
  let businessData = null;
  const interactiveControllers = [];

  const focusable = (scope) => qsa('a[href],button:not([disabled]),[tabindex]:not([tabindex="-1"])', scope)
    .filter((element) => !element.hidden && element.getAttribute('aria-hidden') !== 'true');

  const showToast = (message, duration = 2600) => {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add('show');
    clearTimeout(showToast.timer);
    showToast.timer = setTimeout(() => toast.classList.remove('show'), duration);
  };

  const setMenuLabel = (open) => {
    if (!menuToggle) return;
    menuToggle.setAttribute('aria-label', i18n?.t(open ? 'menuClose' : 'menuToggle') || (open ? 'Navigation schließen' : 'Navigation öffnen'));
  };

  const closeMenu = ({ restore = true } = {}) => {
    if (!menuToggle || !mainNav) return;
    mainNav.classList.remove('open');
    document.body.classList.remove('menu-open');
    menuToggle.setAttribute('aria-expanded', 'false');
    setMenuLabel(false);
    if (restore && returnFocus) returnFocus.focus();
  };

  const openMenu = () => {
    if (!menuToggle || !mainNav) return;
    returnFocus = document.activeElement;
    mainNav.classList.add('open');
    document.body.classList.add('menu-open');
    menuToggle.setAttribute('aria-expanded', 'true');
    setMenuLabel(true);
    requestAnimationFrame(() => focusable(mainNav)[0]?.focus());
  };

  menuToggle?.addEventListener('click', () => menuToggle.getAttribute('aria-expanded') === 'true' ? closeMenu() : openMenu());
  qsa('a', mainNav || document).forEach((link) => link.addEventListener('click', () => closeMenu({ restore: false })));
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && mainNav?.classList.contains('open')) closeMenu();
    if (event.key !== 'Tab' || !mainNav?.classList.contains('open')) return;
    const items = focusable(mainNav);
    if (!items.length) return;
    const first = items[0];
    const last = items.at(-1);
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
    if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
  });
  matchMedia('(min-width:1051px)').addEventListener?.('change', (event) => { if (event.matches) closeMenu({ restore: false }); });

  const currentYear = qs('#currentYear');
  if (currentYear) currentYear.textContent = String(new Date().getFullYear());


  const progress = document.createElement('div');
  progress.className = 'scroll-progress';
  progress.setAttribute('aria-hidden', 'true');
  progress.innerHTML = '<span></span>';
  document.body.prepend(progress);
  const updateScrollProgress = () => {
    const maximum = Math.max(1, document.documentElement.scrollHeight - innerHeight);
    qs('span', progress).style.transform = `scaleX(${Math.min(1, Math.max(0, scrollY / maximum))})`;
  };
  updateScrollProgress();
  addEventListener('scroll', updateScrollProgress, { passive: true });
  addEventListener('resize', updateScrollProgress, { passive: true });

  const headerInner = qs('.header-inner');
  const headerStatus = document.createElement('a');
  headerStatus.className = 'header-live-status';
  headerStatus.href = 'standort.html';
  headerStatus.innerHTML = '<span class="status-dot" aria-hidden="true"></span><span></span>';
  headerInner?.insertBefore(headerStatus, menuToggle || mainNav || null);

  const showConnectionState = () => showToast(i18n?.t(navigator.onLine ? 'interaction.online' : 'interaction.offline') || (navigator.onLine ? 'Verbindung wiederhergestellt' : 'Du bist offline.'), 4200);
  addEventListener('online', showConnectionState);
  addEventListener('offline', showConnectionState);

  const copyText = async (value) => {
    try { await navigator.clipboard.writeText(value); return true; }
    catch {
      const field = document.createElement('textarea');
      field.value = value; field.setAttribute('readonly', ''); field.style.position = 'fixed'; field.style.opacity = '0';
      document.body.appendChild(field); field.select();
      const copied = document.execCommand('copy'); field.remove(); return copied;
    }
  };

  const sharePayload = async ({ title = document.title, text = '', url = location.href } = {}) => {
    try {
      if (navigator.share) {
        await navigator.share({ title, text, url });
        showToast(i18n?.t('interaction.shared') || 'Geteilt');
        return true;
      }
      if (!await copyText([text, url].filter(Boolean).join('\n'))) throw new Error('Copy failed');
      showToast(i18n?.t('interaction.copied') || 'Link kopiert');
      return true;
    } catch (error) {
      if (error?.name !== 'AbortError') showToast(i18n?.t('interaction.offline') || 'Teilen ist gerade nicht verfügbar.');
      return false;
    }
  };
  document.addEventListener('click', (event) => {
    const shareButton = event.target.closest('[data-share-site]');
    if (shareButton) sharePayload({ text: document.querySelector('meta[name="description"]')?.content || '' });
  });


  const mobileActionBar = qs('.mobile-action-bar');
  const updateMobileActionBar = () => mobileActionBar?.classList.toggle('is-visible', window.scrollY > 240);
  updateMobileActionBar();
  window.addEventListener('scroll', updateMobileActionBar, { passive: true });

  const dayCodes = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const businessDayMap = { Sunday: 'Sun', Monday: 'Mon', Tuesday: 'Tue', Wednesday: 'Wed', Thursday: 'Thu', Friday: 'Fri', Saturday: 'Sat' };
  const parseClock = (value, fallback) => {
    const match = String(value || '').match(/^(\d{1,2}):(\d{2})$/);
    if (!match) return fallback;
    const hours = Number(match[1]);
    const minutes = Number(match[2]);
    return hours >= 0 && hours <= 23 && minutes >= 0 && minutes <= 59 ? hours * 60 + minutes : fallback;
  };
  const openingConfig = () => ({
    day: businessDayMap[businessData?.openingHours?.day] || 'Sun',
    opens: parseClock(businessData?.openingHours?.opens, 11 * 60),
    closes: parseClock(businessData?.openingHours?.closes, 19 * 60),
    timeZone: businessData?.openingHours?.timeZone || 'Europe/Berlin'
  });
  const formattedAddress = () => {
    const address = businessData?.address;
    if (!address) return 'Kemptener Str. 54, 88299 Leutkirch im Allgäu';
    return [address.street, [address.postalCode, address.city].filter(Boolean).join(' ')].filter(Boolean).join(', ');
  };
  const zonedParts = (date = new Date()) => Object.fromEntries(
    new Intl.DateTimeFormat('en-GB', {
      timeZone: openingConfig().timeZone, weekday: 'short', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false
    }).formatToParts(date).filter((part) => part.type !== 'literal').map((part) => [part.type, part.value])
  );

  const nextOpeningDate = (now = new Date()) => {
    const parts = zonedParts(now);
    const config = openingConfig();
    const todayIndex = dayCodes.indexOf(parts.weekday);
    const targetIndex = dayCodes.indexOf(config.day);
    const minutes = Number(parts.hour) * 60 + Number(parts.minute);
    let add = (targetIndex - todayIndex + 7) % 7;
    if (add === 0 && minutes >= config.closes) add = 7;
    const base = new Date(Date.UTC(Number(parts.year), Number(parts.month) - 1, Number(parts.day), 12));
    base.setUTCDate(base.getUTCDate() + add);
    return base;
  };

  const updateOpeningStatus = () => {
    const status = qs('#openStatus');
    const next = qs('#nextSunday');
    const globalStatus = headerStatus.lastElementChild;
    const countdown = qs('#statusCountdown');
    if (!status && !next && !globalStatus && !countdown) return;
    const parts = zonedParts();
    const config = openingConfig();
    const operatingDay = parts.weekday === config.day;
    const minutes = Number(parts.hour) * 60 + Number(parts.minute);
    const open = operatingDay && minutes >= config.opens && minutes < config.closes;
    let key = 'status.next';
    if (open) key = 'status.open';
    else if (operatingDay && minutes < config.opens) key = 'status.today';
    else if (operatingDay) key = 'status.closedToday';
    if (status) {
      status.textContent = i18n?.t(key) || 'Jeden Sonntag geöffnet';
      status.closest('.status-line')?.classList.toggle('is-open', open);
    }
    if (globalStatus) {
      globalStatus.textContent = open || operatingDay ? (i18n?.t(key) || 'Jeden Sonntag geöffnet') : (i18n?.t('hero.defaultStatus') || 'Jeden Sonntag geöffnet');
      headerStatus.classList.toggle('is-open', open);
    }
    if (next) {
      const formatted = new Intl.DateTimeFormat(localeMap[i18n?.language] || 'de-DE', { weekday: 'long', day: '2-digit', month: '2-digit' }).format(nextOpeningDate());
      next.textContent = open ? '' : (i18n?.t('status.next', { date: formatted }) || `Nächster Termin: ${formatted}`);
      next.hidden = open;
    }
    if (countdown) {
      const formatDuration = (totalMinutes) => {
        const hours = Math.floor(totalMinutes / 60);
        const remaining = totalMinutes % 60;
        return [hours ? `${hours} Std.` : '', remaining ? `${remaining} Min.` : ''].filter(Boolean).join(' ');
      };
      const todayIndex = dayCodes.indexOf(parts.weekday);
      const targetIndex = dayCodes.indexOf(config.day);
      let days = (targetIndex - todayIndex + 7) % 7;
      if (open) countdown.textContent = i18n?.t('live.closesIn', { time: formatDuration(config.closes - minutes) }) || '';
      else if (operatingDay && minutes < config.opens) countdown.textContent = i18n?.t('live.todayLater', { time: formatDuration(config.opens - minutes) }) || '';
      else {
        if (days === 0) days = 7;
        countdown.textContent = days === 1 ? (i18n?.t('live.tomorrow') || '') : (i18n?.t('live.daysUntil', { count: days }) || '');
      }
    }
  };

  qs('#copyAddress')?.addEventListener('click', async () => {
    const address = formattedAddress();
    try {
      await navigator.clipboard.writeText(address);
      showToast(i18n?.t('location.copied') || 'Adresse kopiert');
    } catch {
      const field = document.createElement('textarea');
      field.value = address;
      field.style.position = 'fixed';
      field.style.opacity = '0';
      document.body.appendChild(field);
      field.select();
      document.execCommand('copy');
      field.remove();
      showToast(i18n?.t('location.copied') || 'Adresse kopiert');
    }
  });


  const storageJson = {
    get(key, fallback = {}) { try { return JSON.parse(localStorage.getItem(key) || '') || fallback; } catch { return fallback; } },
    set(key, value) { try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* Storage can be unavailable. */ } }
  };
  const formatMoney = (value, currency = 'EUR') => new Intl.NumberFormat(localeMap[i18n?.language] || 'de-DE', { style: 'currency', currency }).format(value);

  const visitPlanner = qs('#visitPlanner');
  if (visitPlanner) {
    const dateOutput = qs('#visitDate');
    const timeSelect = qs('#visitTime');
    const summary = qs('#visitPlanSummary');
    const stored = storageJson.get('albas-visit-plan', { time: '12:00' });
    let timeSignature = '';
    const createTimes = () => {
      const config = openingConfig();
      timeSignature = `${config.opens}-${config.closes}`;
      const previous = timeSelect.value || stored.time;
      const options = [];
      for (let value = config.opens; value <= config.closes - 30; value += 30) {
        const hours = String(Math.floor(value / 60)).padStart(2, '0');
        const minutes = String(value % 60).padStart(2, '0');
        options.push(`${hours}:${minutes}`);
      }
      timeSelect.replaceChildren(...options.map((value) => {
        const option = document.createElement('option'); option.value = value; option.textContent = value; return option;
      }));
      timeSelect.value = options.includes(previous) ? previous : options[0];
    };
    const plannerDate = () => nextOpeningDate();
    const refreshVisitPlanner = () => {
      const config = openingConfig();
      if (!timeSelect.options.length || timeSignature !== `${config.opens}-${config.closes}`) createTimes();
      const date = plannerDate();
      const dateText = new Intl.DateTimeFormat(localeMap[i18n?.language] || 'de-DE', { weekday: 'long', day: '2-digit', month: '2-digit', year: 'numeric' }).format(date);
      dateOutput.textContent = dateText;
      summary.textContent = i18n?.t('visitPlanner.summary', { date: dateText, time: timeSelect.value }) || `${dateText} · ${timeSelect.value}`;
    };
    const saveVisitPlan = () => {
      storageJson.set('albas-visit-plan', { time: timeSelect.value });
      refreshVisitPlanner();
    };
    timeSelect.addEventListener('change', saveVisitPlan);
    visitPlanner.addEventListener('submit', (event) => {
      event.preventDefault();
      const date = plannerDate();
      const dateCode = `${date.getUTCFullYear()}${String(date.getUTCMonth() + 1).padStart(2, '0')}${String(date.getUTCDate()).padStart(2, '0')}`;
      const [hours, minutes] = timeSelect.value.split(':').map(Number);
      const endTotal = Math.min(openingConfig().closes, hours * 60 + minutes + 60);
      const end = `${String(Math.floor(endTotal / 60)).padStart(2, '0')}${String(endTotal % 60).padStart(2, '0')}00`;
      const start = `${String(hours).padStart(2, '0')}${String(minutes).padStart(2, '0')}00`;
      const escapeIcs = (value) => String(value).replaceAll('\\', '\\\\').replaceAll(';', '\\;').replaceAll(',', '\\,').replaceAll('\n', '\\n');
      const lines = [
        'BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//Albas Streetfood//Visit Planner//DE','CALSCALE:GREGORIAN','METHOD:PUBLISH','BEGIN:VEVENT',
        `UID:${Date.now()}@albas-streetfood`, `DTSTAMP:${new Date().toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, '')}`,
        `DTSTART;TZID=${openingConfig().timeZone}:${dateCode}T${start}`, `DTEND;TZID=${openingConfig().timeZone}:${dateCode}T${end}`,
        `SUMMARY:${escapeIcs(i18n?.t('visitPlanner.eventTitle') || 'Alba’s Streetfood besuchen')}`,
        `DESCRIPTION:${escapeIcs(i18n?.t('visitPlanner.eventDescription') || '')}`,
        `LOCATION:${escapeIcs(formattedAddress())}`, 'END:VEVENT','END:VCALENDAR'
      ];
      const blob = new Blob([lines.join('\r\n')], { type: 'text/calendar;charset=utf-8' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob); link.download = `albas-streetfood-${dateCode}.ics`; link.click();
      setTimeout(() => URL.revokeObjectURL(link.href), 1000);
      showToast(i18n?.t('visitPlanner.calendarSaved') || 'Kalendereintrag wurde erstellt');
    });
    createTimes(); refreshVisitPlanner();
    interactiveControllers.push({ refresh: refreshVisitPlanner, render: refreshVisitPlanner });
  }

  qsa('.menu-filter').forEach((toolbar) => {
    const buttons = qsa('[data-menu-filter]', toolbar);
    const filterScope = toolbar.closest('.menu-section') || document;
    const items = qsa('[data-menu-category]', filterScope);
    buttons.forEach((button) => button.addEventListener('click', () => {
      const value = button.dataset.menuFilter;
      buttons.forEach((entry) => { const active = entry === button; entry.classList.toggle('is-active', active); entry.setAttribute('aria-pressed', String(active)); });
      items.forEach((item) => { item.hidden = value !== 'all' && item.dataset.menuCategory !== value; });
    }));
  });

  const menuPlanner = qs('[data-menu-planner]');
  if (menuPlanner) {
    const host = qs('[data-menu-planner-items]', menuPlanner);
    const total = qs('[data-menu-planner-total]', menuPlanner);
    const count = qs('[data-menu-planner-count]', menuPlanner);
    const copyButton = qs('[data-menu-planner-copy]', menuPlanner);
    const shareButton = qs('[data-menu-planner-share]', menuPlanner);
    let state = storageJson.get('albas-menu-selection', {});
    const menuLabel = (item) => {
      const translated = i18n?.t(`menuPlanner.items.${item.id}`);
      return translated && !translated.startsWith('menuPlanner.items.') ? translated : item.name;
    };
    const selectedItems = () => (businessData?.menu || []).filter((item) => item.confirmed && Number.isFinite(item.price) && item.price > 0 && Number(state[item.id] || 0) > 0);
    const menuSummary = () => {
      const lines = selectedItems().map((item) => `${Number(state[item.id])} × ${menuLabel(item)} · ${formatMoney(item.price * Number(state[item.id]), item.currency || 'EUR')}`);
      const sum = selectedItems().reduce((value, item) => value + item.price * Number(state[item.id]), 0);
      lines.push(i18n?.t('menuPlanner.totalLine', { total: formatMoney(sum) }) || `Gesamtsumme: ${formatMoney(sum)}`);
      return lines.join('\n');
    };
    const updatePlannerTotals = () => {
      const items = selectedItems();
      const itemCount = items.reduce((value, item) => value + Number(state[item.id]), 0);
      const sum = items.reduce((value, item) => value + item.price * Number(state[item.id]), 0);
      total.textContent = formatMoney(sum);
      count.textContent = itemCount ? (i18n?.t('menuPlanner.count', { count: itemCount }) || `${itemCount}`) : (i18n?.t('menuPlanner.empty') || '');
      if (copyButton) copyButton.disabled = itemCount === 0;
      if (shareButton) shareButton.disabled = itemCount === 0;
      storageJson.set('albas-menu-selection', state);
    };
    const renderMenuPlanner = () => {
      if (!businessData) return;
      const items = businessData.menu.filter((item) => item.confirmed && Number.isFinite(item.price) && item.price > 0);
      host.replaceChildren(...items.map((item) => {
        const article = document.createElement('article'); article.className = 'menu-planner-item';
        const copy = document.createElement('div');
        const title = document.createElement('h3'); title.textContent = menuLabel(item);
        const price = document.createElement('p'); price.textContent = formatMoney(item.price, item.currency || 'EUR');
        copy.append(title, price);
        const control = document.createElement('div'); control.className = 'quantity-control';
        const minus = document.createElement('button'); minus.type = 'button'; minus.textContent = '−'; minus.setAttribute('aria-label', i18n?.t('menuPlanner.minus', { item: menuLabel(item) }) || 'Entfernen');
        const output = document.createElement('output'); output.value = String(Number(state[item.id] || 0)); output.textContent = output.value; output.setAttribute('aria-label', i18n?.t('menuPlanner.quantity', { item: menuLabel(item) }) || 'Anzahl');
        const plus = document.createElement('button'); plus.type = 'button'; plus.textContent = '+'; plus.setAttribute('aria-label', i18n?.t('menuPlanner.plus', { item: menuLabel(item) }) || 'Hinzufügen');
        const change = (delta) => { state[item.id] = Math.max(0, Math.min(20, Number(state[item.id] || 0) + delta)); output.value = String(state[item.id]); output.textContent = output.value; updatePlannerTotals(); };
        minus.addEventListener('click', () => change(-1)); plus.addEventListener('click', () => change(1));
        control.append(minus, output, plus); article.append(copy, control); return article;
      }));
      updatePlannerTotals();
    };
    qs('[data-menu-planner-reset]', menuPlanner)?.addEventListener('click', () => { state = {}; renderMenuPlanner(); showToast(i18n?.t('menuPlanner.resetDone') || 'Auswahl wurde zurückgesetzt'); });
    qs('[data-menu-planner-copy]', menuPlanner)?.addEventListener('click', async () => { if (await copyText(menuSummary())) showToast(i18n?.t('menuPlanner.copied') || 'Auswahl wurde kopiert'); });
    qs('[data-menu-planner-share]', menuPlanner)?.addEventListener('click', () => sharePayload({ title: i18n?.t('menuPlanner.shareTitle') || document.title, text: menuSummary(), url: location.href }));
    interactiveControllers.push({ refresh: renderMenuPlanner, render: renderMenuPlanner });
  }

  qsa('.faq-list').forEach((list) => qsa('details', list).forEach((detail) => detail.addEventListener('toggle', () => {
    if (!detail.open) return;
    qsa('details', list).forEach((other) => { if (other !== detail) other.open = false; });
  })));

  const lightbox = qs('#imageLightbox');
  const lightboxImage = qs('#lightboxImage');
  const lightboxCaption = qs('#lightboxCaption');
  const lightboxItems = qsa('.js-lightbox');
  let lightboxIndex = 0;
  let lightboxReturnFocus = null;

  const renderLightbox = () => {
    const item = lightboxItems[lightboxIndex];
    if (!item || !lightboxImage) return;
    const source = item.getAttribute('href');
    const image = qs('img', item);
    lightboxImage.src = source;
    lightboxImage.alt = image?.alt || '';
    if (lightboxCaption) lightboxCaption.textContent = item.dataset.title || image?.alt || '';
  };
  const openLightbox = (index, trigger) => {
    if (!lightbox?.showModal) return;
    lightboxIndex = index;
    lightboxReturnFocus = trigger;
    renderLightbox();
    lightbox.showModal();
    qs('[data-lightbox-close]', lightbox)?.focus();
  };
  const closeLightbox = () => {
    if (!lightbox?.open) return;
    lightbox.close();
    lightboxImage?.removeAttribute('src');
    lightboxReturnFocus?.focus();
  };
  lightboxItems.forEach((item, index) => item.addEventListener('click', (event) => { event.preventDefault(); openLightbox(index, item); }));
  qs('[data-lightbox-close]', lightbox)?.addEventListener('click', closeLightbox);
  qs('[data-lightbox-prev]', lightbox)?.addEventListener('click', () => { lightboxIndex = (lightboxIndex - 1 + lightboxItems.length) % lightboxItems.length; renderLightbox(); });
  qs('[data-lightbox-next]', lightbox)?.addEventListener('click', () => { lightboxIndex = (lightboxIndex + 1) % lightboxItems.length; renderLightbox(); });
  lightbox?.addEventListener('click', (event) => { if (event.target === lightbox) closeLightbox(); });
  lightbox?.addEventListener('keydown', (event) => {
    if (event.key === 'ArrowLeft' && lightboxItems.length > 1) { event.preventDefault(); lightboxIndex = (lightboxIndex - 1 + lightboxItems.length) % lightboxItems.length; renderLightbox(); }
    if (event.key === 'ArrowRight' && lightboxItems.length > 1) { event.preventDefault(); lightboxIndex = (lightboxIndex + 1) % lightboxItems.length; renderLightbox(); }
  });

  const businessLabels = {
    de: { payment: 'Zahlungsarten', preorder: 'Vorbestellung', parking: 'Parken', seating: 'Sitzmöglichkeiten', access: 'Barrierefreiheit', weather: 'Bei schlechtem Wetter', holiday: 'Feiertage & Urlaub', verified: 'Angaben zuletzt bestätigt', phone: 'Telefon', email: 'E-Mail', whatsapp: 'WhatsApp' },
    en: { payment: 'Payment methods', preorder: 'Pre-orders', parking: 'Parking', seating: 'Seating', access: 'Accessibility', weather: 'Bad weather', holiday: 'Holidays & leave', verified: 'Details last verified', phone: 'Phone', email: 'Email', whatsapp: 'WhatsApp' },
    sq: { payment: 'Mënyrat e pagesës', preorder: 'Porositë paraprake', parking: 'Parkimi', seating: 'Vendet për ulje', access: 'Qasshmëria', weather: 'Në mot të keq', holiday: 'Festat & pushimet', verified: 'Të dhënat e konfirmuara', phone: 'Telefoni', email: 'E-mail', whatsapp: 'WhatsApp' }
  };
  const currentBusinessLabels = () => businessLabels[i18n?.language] || businessLabels.de;
  const safeContactLink = (type, value) => {
    if (!value) return '';
    if (type === 'email') return `mailto:${value}`;
    if (type === 'phone') return `tel:${String(value).replace(/[^+\d]/g, '')}`;
    if (type === 'whatsapp') return `https://wa.me/${String(value).replace(/\D/g, '')}`;
    return '';
  };


  const activePromotion = () => {
    const now = Date.now();
    return (businessData?.promotions || []).find((promotion) => {
      if (promotion?.confirmed !== true) return false;
      const starts = Date.parse(promotion.startsAt || '');
      const ends = Date.parse(promotion.endsAt || '');
      return Number.isFinite(starts) && Number.isFinite(ends) && now >= starts && now <= ends;
    }) || null;
  };

  const renderPromotions = () => {
    const promotion = activePromotion();
    const locale = localeMap[i18n?.language] || 'de-DE';
    qsa('[data-promotion-slot]').forEach((slot) => {
      if (!promotion) { slot.hidden = true; return; }
      const date = new Intl.DateTimeFormat(locale, { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', timeZone: businessData?.openingHours?.timeZone || 'Europe/Berlin' }).format(new Date(`${promotion.eventDate}T12:00:00+02:00`));
      const dateShort = new Intl.DateTimeFormat(locale, { day: 'numeric', month: 'long', year: 'numeric', timeZone: businessData?.openingHours?.timeZone || 'Europe/Berlin' }).format(new Date(`${promotion.eventDate}T12:00:00+02:00`));
      const dateLine = qs('[data-promotion-date]', slot);
      const locationLine = qs('[data-promotion-location]', slot);
      const note = qs('[data-promotion-note]', slot);
      const pricesHost = qs('[data-promotion-prices]', slot);
      if (dateLine) dateLine.textContent = i18n?.t('promotion.dateLine', { date }) || `${date} · 10:00–20:00 Uhr`;
      if (locationLine) locationLine.textContent = i18n?.t('promotion.locationLine') || promotion.location || '';
      if (note) note.textContent = i18n?.t('promotion.note', { date: dateShort }) || `Nur am ${dateShort}.`;
      if (pricesHost) {
        const cards = (promotion.items || []).map((offer) => {
          const regular = (businessData.menu || []).find((item) => item.id === offer.menuId);
          const currency = offer.currency || regular?.currency || 'EUR';
          const format = (value) => new Intl.NumberFormat(locale, { style: 'currency', currency }).format(value);
          const article = document.createElement('article');
          article.className = 'promotion-price';
          article.setAttribute('role', 'listitem');
          const name = document.createElement('span');
          name.textContent = i18n?.t(offer.labelKey) || regular?.name || '';
          const priceWrap = document.createElement('div');
          if (Number.isFinite(regular?.price) && regular.price > offer.price) {
            const old = document.createElement('s');
            const oldFormatted = format(regular.price);
            old.textContent = oldFormatted;
            old.setAttribute('aria-label', i18n?.t('promotion.regularPrice', { price: oldFormatted }) || `Regulär ${oldFormatted}`);
            priceWrap.appendChild(old);
          }
          const special = document.createElement('strong');
          const specialFormatted = format(offer.price);
          special.textContent = specialFormatted;
          special.setAttribute('aria-label', i18n?.t('promotion.specialPrice', { price: specialFormatted }) || `Aktionspreis ${specialFormatted}`);
          priceWrap.appendChild(special);
          article.append(name, priceWrap);
          return article;
        });
        pricesHost.replaceChildren(...cards);
      }
      slot.hidden = false;
    });
  };

  const updateStructuredBusinessData = () => {
    if (!businessData) return;
    qsa('script[type="application/ld+json"]').forEach((script) => {
      try {
        const data = JSON.parse(script.textContent);
        const types = Array.isArray(data['@type']) ? data['@type'] : [data['@type']];
        if (!types.includes('FoodEstablishment') && !types.includes('LocalBusiness')) return;
        const contactEmail = businessData.contact?.email || businessData.legal?.businessEmail || '';
        const phone = businessData.contact?.phone || '';
        const prices = (businessData.menu || []).filter((item) => item.confirmed && Number.isFinite(item.price) && item.price > 0).map((item) => item.price);
        data.name = businessData.name || data.name;
        data.founder = { '@type': 'Person', name: businessData.owner || 'Durim Gashi' };
        data.address = {
          '@type': 'PostalAddress',
          streetAddress: businessData.address?.street || '',
          postalCode: businessData.address?.postalCode || '',
          addressLocality: businessData.address?.city || '',
          addressCountry: businessData.address?.country === 'Deutschland' ? 'DE' : businessData.address?.country || 'DE'
        };
        data.openingHoursSpecification = [{
          '@type': 'OpeningHoursSpecification',
          dayOfWeek: 'https://schema.org/Sunday',
          opens: businessData.openingHours?.opens || '10:00',
          closes: businessData.openingHours?.closes || '20:00'
        }];
        data.sameAs = [businessData.contact?.instagram].filter(Boolean);
        data.menu = new URL('speisekarte.html', document.baseURI).href;
        if (contactEmail) data.email = contactEmail; else delete data.email;
        if (phone) data.telephone = phone; else delete data.telephone;
        if ((businessData.operations?.paymentMethods || []).length) data.paymentAccepted = businessData.operations.paymentMethods.join(', '); else delete data.paymentAccepted;
        if (prices.length) {
          const min = Math.min(...prices);
          const max = Math.max(...prices);
          data.priceRange = min === max ? `${min.toFixed(2)} EUR` : `${min.toFixed(2)}–${max.toFixed(2)} EUR`;
        } else delete data.priceRange;
        script.textContent = JSON.stringify(data);
      } catch { /* Static JSON-LD remains available. */ }
    });
  };

  const renderBusinessData = () => {
    if (!businessData) return;
    updateStructuredBusinessData();
    renderPromotions();
    const labels = currentBusinessLabels();
    const locale = localeMap[i18n?.language] || 'de-DE';
    const banner = qs('[data-preview-banner]');
    if (banner) banner.hidden = businessData.publishReady === true;

    qsa('[data-menu-price]').forEach((element) => {
      const item = (businessData.menu || []).find((entry) => entry.id === element.dataset.menuPrice);
      if (item?.confirmed === true && Number.isFinite(item.price) && item.price > 0) {
        element.removeAttribute('data-i18n');
        element.textContent = new Intl.NumberFormat(locale, { style: 'currency', currency: item.currency || 'EUR' }).format(item.price);
        element.classList.add('is-confirmed');
      }
    });

    interactiveControllers.forEach((controller) => controller.render?.());

    qsa('[data-business-last-verified]').forEach((element) => {
      if (!businessData.lastVerified) { element.hidden = true; return; }
      const parsed = new Date(`${businessData.lastVerified}T12:00:00`);
      const formatted = Number.isNaN(parsed.getTime())
        ? businessData.lastVerified
        : new Intl.DateTimeFormat(locale, { day: '2-digit', month: '2-digit', year: 'numeric' }).format(parsed);
      element.textContent = i18n?.t('menuPrices.verifiedDate', { date: formatted }) || `Stand der Preise: ${formatted}`;
      element.hidden = false;
    });

    qsa('[data-business-contact-links]').forEach((container) => {
      const links = [];
      ['phone', 'email', 'whatsapp'].forEach((type) => {
        const value = businessData.contact?.[type] || (type === 'email' ? businessData.legal?.businessEmail : '');
        const href = safeContactLink(type, value);
        if (!value || !href) return;
        const link = document.createElement('a');
        link.href = href;
        link.textContent = `${labels[type]}: ${value}`;
        if (type === 'whatsapp') { link.target = '_blank'; link.rel = 'noopener noreferrer'; }
        links.push(link);
      });
      container.replaceChildren(...links);
      container.hidden = links.length === 0;
    });

    const section = qs('#verifiedBusinessDetails');
    const grid = qs('#verifiedDetailsGrid');
    const date = qs('#verifiedDate');
    if (!section || !grid) return;
    const values = [];
    const add = (label, value) => { if (value !== null && value !== undefined && String(value).trim()) values.push([label, String(value)]); };
    const operations = businessData.operations || {};
    if ((operations.paymentMethods || []).length) add(labels.payment, operations.paymentMethods.join(' · '));
    if (operations.preorders === true) add(labels.preorder, i18n?.language === 'sq' ? 'E mundur' : i18n?.language === 'en' ? 'Available' : 'Möglich');
    if (operations.preorders === false) add(labels.preorder, i18n?.language === 'sq' ? 'Nuk ofrohet' : i18n?.language === 'en' ? 'Not offered' : 'Nicht angeboten');
    add(labels.parking, operations.parking);
    add(labels.seating, operations.seating);
    add(labels.access, operations.accessibility);
    add(labels.weather, operations.weatherPolicy);
    add(labels.holiday, operations.holidayPolicy);
    grid.replaceChildren(...values.map(([label, value]) => {
      const article = document.createElement('article');
      article.className = 'verified-detail-card';
      const small = document.createElement('small'); small.textContent = label;
      const strong = document.createElement('strong'); strong.textContent = value;
      article.append(small, strong);
      return article;
    }));
    section.hidden = values.length === 0;
    if (date && businessData.lastVerified) { date.textContent = `${labels.verified}: ${businessData.lastVerified}`; date.hidden = false; }
  };

  const loadBusinessData = async () => {
    try {
      const response = await fetch('assets/data/business.json', { cache: 'no-store' });
      if (!response.ok) throw new Error('Business data unavailable');
      businessData = await response.json();
      renderBusinessData();
      updateOpeningStatus();
    } catch {
      qs('[data-preview-banner]')?.removeAttribute('hidden');
    }
  };

  const syncLiveUrl = () => {
    if (!location.protocol.startsWith('http') || ['localhost', '127.0.0.1'].includes(location.hostname)) return;
    const cleanUrl = `${location.origin}${location.pathname}`;
    qs('link[rel="canonical"]')?.setAttribute('href', cleanUrl);
    qs('meta[property="og:url"]')?.setAttribute('content', cleanUrl);
    qsa('script[type="application/ld+json"]').forEach((script) => {
      try {
        const data = JSON.parse(script.textContent);
        if (data.url) data.url = cleanUrl;
        if (data.image && String(data.image).includes('/assets/')) data.image = `${location.origin}${location.pathname.replace(/[^/]*$/, '')}assets/images/og-cover.jpg`;
        script.textContent = JSON.stringify(data);
      } catch { /* Keep valid static JSON-LD. */ }
    });
  };

  const applyLanguage = () => {
    i18n?.apply();
    setMenuLabel(menuToggle?.getAttribute('aria-expanded') === 'true');
    updateOpeningStatus();
    renderBusinessData();
    interactiveControllers.forEach((controller) => controller.refresh?.());
  };

  qsa('[data-lang]').forEach((button) => button.addEventListener('click', () => i18n?.setLanguage(button.dataset.lang)));
  window.addEventListener('albas:languagechange', applyLanguage);
  syncLiveUrl();
  applyLanguage();
  loadBusinessData();
  setInterval(() => { updateOpeningStatus(); renderPromotions(); }, 60_000);

})();


// First-Class migration: remove legacy PWA caches and registrations from older releases.
async function cleanupLegacyOfflineState() {
  try {
    if ('caches' in window) {
      const keys = await caches.keys();
      await Promise.all(keys.map((key) => caches.delete(key)));
    }
    if ('serviceWorker' in navigator) {
      const registrations = await navigator.serviceWorker.getRegistrations();
      await Promise.all(registrations.map((registration) => registration.unregister()));
    }
  } catch (error) {
    console.warn('Legacy cache cleanup skipped:', error);
  }
}
window.addEventListener('load', cleanupLegacyOfflineState, { once: true });
