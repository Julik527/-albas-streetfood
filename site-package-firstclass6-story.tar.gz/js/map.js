(() => {
  'use strict';

  const TILE_SIZE = 256;
  const MIN_ZOOM = 3;
  const MAX_ZOOM = 19;
  const TILE_TIMEOUT_MS = 7000;
  const DEFAULTS = { latitude: 47.8225, longitude: 10.03821, zoom: 18, layer: 'satellite' };
  const TILE_SOURCES = {
    satellite: {
      url: (z, x, y) => `https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/${z}/${y}/${x}`,
      attribution: 'Satellitenbilder: Esri, Maxar, Earthstar Geographics und weitere Anbieter'
    },
    street: {
      url: (z, x, y) => `https://tile.openstreetmap.org/${z}/${x}/${y}.png`,
      attribution: 'Kartendaten: © OpenStreetMap-Mitwirkende'
    }
  };
  const i18n = window.AlbasI18n;
  const instances = [];
  const clamp = (value, min, max) => Math.min(max, Math.max(min, value));
  const t = (key, fallback) => {
    const value = i18n?.t?.(key);
    return value && value !== key ? value : fallback;
  };

  const lonToWorldX = (lon, zoom) => ((lon + 180) / 360) * TILE_SIZE * 2 ** zoom;
  const latToWorldY = (lat, zoom) => {
    const sin = Math.sin(clamp(lat, -85.05112878, 85.05112878) * Math.PI / 180);
    return (0.5 - Math.log((1 + sin) / (1 - sin)) / (4 * Math.PI)) * TILE_SIZE * 2 ** zoom;
  };
  const worldXToLon = (x, zoom) => x / (TILE_SIZE * 2 ** zoom) * 360 - 180;
  const worldYToLat = (y, zoom) => {
    const n = Math.PI - 2 * Math.PI * y / (TILE_SIZE * 2 ** zoom);
    return 180 / Math.PI * Math.atan(Math.sinh(n));
  };

  const loadConfig = async () => {
    try {
      const response = await fetch('assets/data/business.json', { cache: 'no-store' });
      if (!response.ok) throw new Error('configuration unavailable');
      const data = await response.json();
      return {
        latitude: Number(data?.map?.latitude) || DEFAULTS.latitude,
        longitude: Number(data?.map?.longitude) || DEFAULTS.longitude,
        zoom: clamp(Number(data?.map?.zoom) || DEFAULTS.zoom, 14, MAX_ZOOM),
        layer: data?.map?.layer === 'street' || data?.map?.layer === 'map' ? 'street' : 'satellite'
      };
    } catch {
      return { ...DEFAULTS };
    }
  };

  class TileMap {
    constructor(container, config) {
      this.container = container;
      this.canvas = container.querySelector('[data-map-canvas]');
      this.status = container.querySelector('[data-map-status]');
      this.attribution = container.querySelector('[data-map-attribution]');
      this.layerButtons = [...container.querySelectorAll('[data-map-layer]')];
      this.recenterButton = container.querySelector('[data-map-recenter]');
      this.largeLink = container.querySelector('[data-map-large]');
      this.routeLink = container.querySelector('[data-map-route]');
      this.config = config;
      this.layer = config.layer;
      this.zoom = config.zoom;
      this.centerLat = config.latitude;
      this.centerLon = config.longitude;
      this.pointers = new Map();
      this.dragStart = null;
      this.pinchDistance = 0;
      this.renderFrame = 0;
      this.tileGeneration = 0;
      this.failedTiles = 0;
      this.loadedTiles = 0;
      this.fallbackUsed = false;
      this.pendingPane = null;
      this.tileTimeout = 0;
      this.init();
    }

    init() {
      this.canvas.classList.add('albas-tile-map');
      this.canvas.setAttribute('role', 'application');
      this.canvas.setAttribute('aria-label', t('map.panHint', 'Interaktive Karte. Ziehen zum Verschieben, Plus oder Minus zum Zoomen.'));
      this.canvas.innerHTML = `
        <div class="albas-map-viewport" aria-hidden="true">
          <div class="albas-map-tiles is-visible"></div>
          <span class="albas-map-marker-shell"><span class="albas-map-marker"><i></i></span></span>
        </div>
        <div class="albas-map-zoom" role="group" aria-label="${t('map.controlsAria', 'Kartensteuerung')}">
          <button type="button" data-map-zoom-in aria-label="${t('map.zoomIn', 'Vergrößern')}">+</button>
          <button type="button" data-map-zoom-out aria-label="${t('map.zoomOut', 'Verkleinern')}">−</button>
        </div>`;
      this.viewport = this.canvas.querySelector('.albas-map-viewport');
      this.tilePane = this.canvas.querySelector('.albas-map-tiles');
      this.marker = this.canvas.querySelector('.albas-map-marker-shell');
      this.zoomInButton = this.canvas.querySelector('[data-map-zoom-in]');
      this.zoomOutButton = this.canvas.querySelector('[data-map-zoom-out]');
      this.bindControls();
      this.updateLinks();
      this.updateLayerControls();
      this.refreshLabels();
      this.scheduleRender();
      this.resizeObserver = new ResizeObserver(() => this.scheduleRender());
      this.resizeObserver.observe(this.canvas);
    }

    startDrag(point) {
      this.dragStart = {
        x: point.x,
        y: point.y,
        centerX: lonToWorldX(this.centerLon, this.zoom),
        centerY: latToWorldY(this.centerLat, this.zoom)
      };
      this.canvas.classList.add('is-dragging');
    }

    commitDrag(point) {
      if (!this.dragStart || !point) return;
      const dx = point.x - this.dragStart.x;
      const dy = point.y - this.dragStart.y;
      this.viewport.style.transform = '';
      if (Math.abs(dx) + Math.abs(dy) > 1) {
        const worldSize = TILE_SIZE * 2 ** this.zoom;
        const x = (this.dragStart.centerX - dx + worldSize) % worldSize;
        const y = clamp(this.dragStart.centerY - dy, 0, worldSize);
        this.centerLon = worldXToLon(x, this.zoom);
        this.centerLat = worldYToLat(y, this.zoom);
        this.scheduleRender();
      }
      this.dragStart = null;
    }

    bindControls() {
      this.layerButtons.forEach((button) => button.addEventListener('click', () => this.switchLayer(button.dataset.mapLayer)));
      this.recenterButton?.addEventListener('click', () => this.recenter());
      this.zoomInButton.addEventListener('click', () => this.setZoom(this.zoom + 1));
      this.zoomOutButton.addEventListener('click', () => this.setZoom(this.zoom - 1));
      this.canvas.addEventListener('dblclick', (event) => { event.preventDefault(); this.setZoom(this.zoom + 1); });
      this.canvas.addEventListener('wheel', (event) => {
        event.preventDefault();
        this.setZoom(this.zoom + (event.deltaY < 0 ? 1 : -1));
      }, { passive: false });
      this.canvas.addEventListener('keydown', (event) => {
        const step = event.shiftKey ? 220 : 90;
        if (event.key === '+' || event.key === '=') { event.preventDefault(); this.setZoom(this.zoom + 1); }
        else if (event.key === '-' || event.key === '_') { event.preventDefault(); this.setZoom(this.zoom - 1); }
        else if (event.key === 'ArrowLeft') { event.preventDefault(); this.panBy(-step, 0); }
        else if (event.key === 'ArrowRight') { event.preventDefault(); this.panBy(step, 0); }
        else if (event.key === 'ArrowUp') { event.preventDefault(); this.panBy(0, -step); }
        else if (event.key === 'ArrowDown') { event.preventDefault(); this.panBy(0, step); }
        else if (event.key === 'Home') { event.preventDefault(); this.recenter(); }
      });

      this.canvas.addEventListener('pointerdown', (event) => {
        try { this.canvas.setPointerCapture(event.pointerId); } catch { /* Safari may already own capture. */ }
        this.pointers.set(event.pointerId, { x: event.clientX, y: event.clientY });
        if (this.pointers.size === 1) {
          this.startDrag({ x: event.clientX, y: event.clientY });
        } else if (this.pointers.size === 2) {
          const points = [...this.pointers.values()];
          if (this.dragStart) this.commitDrag(points[0]);
          this.pinchDistance = Math.hypot(points[0].x - points[1].x, points[0].y - points[1].y);
          this.canvas.classList.add('is-dragging');
        }
      });

      this.canvas.addEventListener('pointermove', (event) => {
        if (!this.pointers.has(event.pointerId)) return;
        this.pointers.set(event.pointerId, { x: event.clientX, y: event.clientY });
        if (this.pointers.size === 1 && this.dragStart) {
          const dx = event.clientX - this.dragStart.x;
          const dy = event.clientY - this.dragStart.y;
          this.viewport.style.transform = `translate3d(${dx}px,${dy}px,0)`;
        } else if (this.pointers.size === 2) {
          const points = [...this.pointers.values()];
          const distance = Math.hypot(points[0].x - points[1].x, points[0].y - points[1].y);
          if (this.pinchDistance && distance / this.pinchDistance > 1.35) { this.setZoom(this.zoom + 1); this.pinchDistance = distance; }
          if (this.pinchDistance && distance / this.pinchDistance < 0.74) { this.setZoom(this.zoom - 1); this.pinchDistance = distance; }
        }
      });

      const endPointer = (event) => {
        const point = this.pointers.get(event.pointerId);
        if (this.pointers.size === 1 && this.dragStart) this.commitDrag(point);
        this.pointers.delete(event.pointerId);
        if (this.pointers.size < 2) this.pinchDistance = 0;
        if (this.pointers.size === 1) {
          const remaining = [...this.pointers.values()][0];
          this.startDrag(remaining);
        } else if (!this.pointers.size) {
          this.dragStart = null;
          this.viewport.style.transform = '';
          this.canvas.classList.remove('is-dragging');
        }
      };
      this.canvas.addEventListener('pointerup', endPointer);
      this.canvas.addEventListener('pointercancel', endPointer);
    }

    setZoom(nextZoom) {
      const value = clamp(nextZoom, MIN_ZOOM, MAX_ZOOM);
      if (value === this.zoom) return;
      this.viewport.style.transform = '';
      this.dragStart = null;
      this.zoom = value;
      this.zoomInButton.disabled = this.zoom >= MAX_ZOOM;
      this.zoomOutButton.disabled = this.zoom <= MIN_ZOOM;
      this.scheduleRender();
    }

    panBy(dx, dy) {
      const worldSize = TILE_SIZE * 2 ** this.zoom;
      const x = (lonToWorldX(this.centerLon, this.zoom) + dx + worldSize) % worldSize;
      const y = clamp(latToWorldY(this.centerLat, this.zoom) + dy, 0, worldSize);
      this.centerLon = worldXToLon(x, this.zoom);
      this.centerLat = worldYToLat(y, this.zoom);
      this.scheduleRender();
    }

    recenter() {
      this.centerLat = this.config.latitude;
      this.centerLon = this.config.longitude;
      this.zoom = this.config.zoom;
      this.fallbackUsed = false;
      this.scheduleRender();
    }

    switchLayer(nextLayer, fallback = false) {
      if (!TILE_SOURCES[nextLayer] || nextLayer === this.layer) return;
      clearTimeout(this.tileTimeout);
      this.layer = nextLayer;
      this.fallbackUsed = fallback;
      this.updateLayerControls();
      this.scheduleRender();
    }

    scheduleRender() {
      cancelAnimationFrame(this.renderFrame);
      this.renderFrame = requestAnimationFrame(() => this.render());
    }

    render() {
      const rect = this.canvas.getBoundingClientRect();
      if (rect.width < 40 || rect.height < 40) return;
      const generation = ++this.tileGeneration;
      const centerX = lonToWorldX(this.centerLon, this.zoom);
      const centerY = latToWorldY(this.centerLat, this.zoom);
      const left = centerX - rect.width / 2;
      const top = centerY - rect.height / 2;
      const startX = Math.floor(left / TILE_SIZE) - 1;
      const endX = Math.floor((left + rect.width) / TILE_SIZE) + 1;
      const startY = Math.max(0, Math.floor(top / TILE_SIZE) - 1);
      const maxTile = 2 ** this.zoom - 1;
      const endY = Math.min(maxTile, Math.floor((top + rect.height) / TILE_SIZE) + 1);
      const centerTileX = centerX / TILE_SIZE;
      const centerTileY = centerY / TILE_SIZE;
      const descriptors = [];
      for (let ty = startY; ty <= endY; ty += 1) {
        for (let tx = startX; tx <= endX; tx += 1) {
          descriptors.push({ tx, ty, distance: (tx + 0.5 - centerTileX) ** 2 + (ty + 0.5 - centerTileY) ** 2 });
        }
      }
      descriptors.sort((a, b) => a.distance - b.distance);

      clearTimeout(this.tileTimeout);
      this.pendingPane?.remove();
      const oldPane = this.tilePane;
      const nextPane = document.createElement('div');
      nextPane.className = 'albas-map-tiles is-pending';
      this.viewport.insertBefore(nextPane, this.marker);
      this.pendingPane = nextPane;
      this.loadedTiles = 0;
      this.failedTiles = 0;
      this.setStatus('loading');
      let revealed = false;

      const reveal = () => {
        if (revealed || generation !== this.tileGeneration) return;
        revealed = true;
        clearTimeout(this.tileTimeout);
        nextPane.classList.remove('is-pending');
        nextPane.classList.add('is-visible');
        oldPane?.remove();
        this.tilePane = nextPane;
        this.pendingPane = null;
        this.container.classList.add('is-map-ready');
      };

      descriptors.forEach(({ tx, ty }) => {
        const wrappedX = ((tx % (maxTile + 1)) + maxTile + 1) % (maxTile + 1);
        const image = new Image();
        image.alt = '';
        image.decoding = 'async';
        image.draggable = false;
        image.referrerPolicy = 'no-referrer';
        image.className = 'albas-map-tile';
        image.style.left = `${tx * TILE_SIZE - left}px`;
        image.style.top = `${ty * TILE_SIZE - top}px`;
        image.addEventListener('load', () => {
          if (generation !== this.tileGeneration) return;
          this.loadedTiles += 1;
          reveal();
          this.setStatus(this.layer === 'satellite' ? 'satellite' : (this.fallbackUsed ? 'satelliteFallback' : 'street'));
        }, { once: true });
        image.addEventListener('error', () => {
          if (generation !== this.tileGeneration) return;
          this.failedTiles += 1;
          image.remove();
          if (this.layer === 'satellite' && this.loadedTiles === 0 && this.failedTiles >= 4) this.switchLayer('street', true);
          else if (this.layer === 'street' && this.loadedTiles === 0 && this.failedTiles >= 4) this.setStatus('streetError');
        }, { once: true });
        image.src = TILE_SOURCES[this.layer].url(this.zoom, wrappedX, ty);
        nextPane.append(image);
      });

      this.tileTimeout = window.setTimeout(() => {
        if (generation !== this.tileGeneration || this.loadedTiles > 0) return;
        if (this.layer === 'satellite') this.switchLayer('street', true);
        else this.setStatus('streetError');
      }, TILE_TIMEOUT_MS);

      const markerX = lonToWorldX(this.config.longitude, this.zoom) - left;
      const markerY = latToWorldY(this.config.latitude, this.zoom) - top;
      this.marker.style.transform = `translate3d(${markerX}px,${markerY}px,0)`;
      this.zoomInButton.disabled = this.zoom >= MAX_ZOOM;
      this.zoomOutButton.disabled = this.zoom <= MIN_ZOOM;
      this.refreshAttribution();
    }

    setStatus(state) {
      if (!this.status) return;
      const labels = {
        loading: ['map.loading', 'Karte wird geladen …'],
        satellite: ['map.readySatellite', 'Satellitenansicht aktiv'],
        street: ['map.readyRoadmap', 'Straßenkarte aktiv'],
        satelliteFallback: ['map.satelliteFallback', 'Satellitenbilder nicht erreichbar. Straßenkarte aktiv.'],
        streetError: ['map.degraded', 'Kartendaten sind derzeit nicht erreichbar']
      };
      const [key, fallback] = labels[state] || labels.loading;
      this.status.dataset.state = state;
      this.status.textContent = t(key, fallback);
    }

    updateLayerControls() {
      this.layerButtons.forEach((button) => {
        const active = button.dataset.mapLayer === this.layer;
        button.classList.toggle('active', active);
        button.setAttribute('aria-pressed', String(active));
      });
    }

    refreshAttribution() {
      if (this.attribution) this.attribution.textContent = TILE_SOURCES[this.layer].attribution;
    }

    updateLinks() {
      const coordinates = `${this.config.latitude},${this.config.longitude}`;
      if (this.largeLink) this.largeLink.href = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(coordinates)}`;
      if (this.routeLink) this.routeLink.href = `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(coordinates)}`;
    }

    refreshLabels() {
      this.layerButtons.forEach((button) => {
        button.textContent = button.dataset.mapLayer === 'satellite' ? t('map.satellite', 'Satellit') : t('map.roadmap', 'Straße');
      });
      if (this.recenterButton) this.recenterButton.textContent = t('map.recenter', 'Standort zentrieren');
      if (this.largeLink) this.largeLink.textContent = t('map.large', 'Große Karte öffnen');
      if (this.routeLink) this.routeLink.textContent = t('map.route', 'Route direkt öffnen');
      this.canvas.setAttribute('aria-label', t('map.panHint', 'Interaktive Karte. Ziehen zum Verschieben, Plus oder Minus zum Zoomen.'));
      this.zoomInButton?.setAttribute('aria-label', t('map.zoomIn', 'Vergrößern'));
      this.zoomOutButton?.setAttribute('aria-label', t('map.zoomOut', 'Verkleinern'));
      this.setStatus(this.loadedTiles ? (this.layer === 'satellite' ? 'satellite' : (this.fallbackUsed ? 'satelliteFallback' : 'street')) : 'loading');
      this.refreshAttribution();
    }
  }

  const init = async () => {
    const containers = [...document.querySelectorAll('[data-live-map]')];
    if (!containers.length) return;
    const config = await loadConfig();
    containers.forEach((container) => instances.push(new TileMap(container, config)));
  };
  window.addEventListener('albas:languagechange', () => instances.forEach((instance) => instance.refreshLabels()));
  document.readyState === 'loading' ? document.addEventListener('DOMContentLoaded', init, { once: true }) : init();
})();
