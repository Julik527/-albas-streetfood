# Technische Abnahme

## Struktur

- 10 HTML-Seiten
- ein zentrales Stylesheet
- lokale JavaScript-Dateien für Übersetzung, Interaktion und Karte
- zentrale Geschäftsdaten in `assets/data/business.json`
- kein Service Worker, Manifest, Offline-Fallback oder Netlify-spezifischer Header

## Karte

- Satellitenansicht als unmittelbare Startansicht
- Straßenkarten-Umschaltung
- vollständig lokale Kartensteuerung ohne externe JavaScript-Bibliothek
- zentrale Kacheln werden zuerst angefordert
- flüssige Touch- und Mausbewegung durch visuelles Verschieben während des Ziehens
- 7-Sekunden-Zeitüberschreitung und automatische Rückfallebene
- keine iframe- oder Zwei-Klick-Logik
- keine Textüberlagerung auf der Kartenfläche

## Bedienung

- responsive Navigation
- Tastaturfokus und Fokusbegrenzung im Mobilmenü
- statisches, echtes Titelbild statt Karussell
- zugänglicher Bilderdialog
- reduzierter Besuchsplaner und Preisrechner
- reduzierte Bewegung wird im Stylesheet berücksichtigt

## Veröffentlichung

Die technische Vorschau ist veröffentlichbar. Die Suchmaschinen- und Unternehmensfreigabe bleibt bis zur Bestätigung der realen Betreiber-, Medien- und Rechtsangaben deaktiviert.
